﻿namespace Saddams_Shawarma
{
    partial class Manage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bttn_add = new System.Windows.Forms.Button();
            this.bttn_records = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.bttn_supp = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(82, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 12;
            this.label1.Text = "Saddams Shawarma";
            // 
            // bttn_add
            // 
            this.bttn_add.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_add.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_add.Image = global::Saddams_Shawarma.Properties.Resources.add___Copy;
            this.bttn_add.Location = new System.Drawing.Point(241, 198);
            this.bttn_add.Name = "bttn_add";
            this.bttn_add.Size = new System.Drawing.Size(168, 143);
            this.bttn_add.TabIndex = 14;
            this.bttn_add.Text = "Food";
            this.bttn_add.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_add.UseVisualStyleBackColor = true;
            this.bttn_add.Click += new System.EventHandler(this.bttn_add_Click);
            // 
            // bttn_records
            // 
            this.bttn_records.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_records.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_records.Image = global::Saddams_Shawarma.Properties.Resources.Recors___Copy;
            this.bttn_records.Location = new System.Drawing.Point(57, 198);
            this.bttn_records.Name = "bttn_records";
            this.bttn_records.Size = new System.Drawing.Size(168, 143);
            this.bttn_records.TabIndex = 13;
            this.bttn_records.Text = "Sales Records";
            this.bttn_records.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_records.UseVisualStyleBackColor = true;
            this.bttn_records.Click += new System.EventHandler(this.bttn_records_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Saddams_Shawarma.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(149, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 153);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(57, 347);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(168, 143);
            this.button1.TabIndex = 15;
            this.button1.Text = "Members";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bttn_supp
            // 
            this.bttn_supp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_supp.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_supp.Location = new System.Drawing.Point(241, 347);
            this.bttn_supp.Name = "bttn_supp";
            this.bttn_supp.Size = new System.Drawing.Size(168, 143);
            this.bttn_supp.TabIndex = 16;
            this.bttn_supp.Text = "Suppliers List";
            this.bttn_supp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_supp.UseVisualStyleBackColor = true;
            this.bttn_supp.Click += new System.EventHandler(this.bttn_supp_Click);
            // 
            // Manage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(471, 514);
            this.ControlBox = false;
            this.Controls.Add(this.bttn_supp);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.bttn_add);
            this.Controls.Add(this.bttn_records);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Manage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bttn_records;
        private System.Windows.Forms.Button bttn_add;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bttn_supp;
    }
}