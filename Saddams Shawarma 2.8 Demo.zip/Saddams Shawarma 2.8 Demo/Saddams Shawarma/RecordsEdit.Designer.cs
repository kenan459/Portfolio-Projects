﻿namespace Saddams_Shawarma
{
    partial class RecordsEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_quantity = new System.Windows.Forms.Label();
            this.txt_totalAmount = new System.Windows.Forms.Label();
            this.txt_Food = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.Label();
            this.txt_orderID = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bttn_cancel = new System.Windows.Forms.Button();
            this.bttn_save = new System.Windows.Forms.Button();
            this.tb_quantity = new System.Windows.Forms.TextBox();
            this.tb_totalAmount = new System.Windows.Forms.TextBox();
            this.tb_Food = new System.Windows.Forms.TextBox();
            this.tb_orderID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_quantity
            // 
            this.txt_quantity.AutoSize = true;
            this.txt_quantity.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_quantity.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_quantity.Location = new System.Drawing.Point(13, 126);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.Size = new System.Drawing.Size(76, 20);
            this.txt_quantity.TabIndex = 57;
            this.txt_quantity.Text = "Quantity:";
            // 
            // txt_totalAmount
            // 
            this.txt_totalAmount.AutoSize = true;
            this.txt_totalAmount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_totalAmount.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_totalAmount.Location = new System.Drawing.Point(13, 100);
            this.txt_totalAmount.Name = "txt_totalAmount";
            this.txt_totalAmount.Size = new System.Drawing.Size(110, 20);
            this.txt_totalAmount.TabIndex = 56;
            this.txt_totalAmount.Text = "Total Amount:";
            // 
            // txt_Food
            // 
            this.txt_Food.AutoSize = true;
            this.txt_Food.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Food.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_Food.Location = new System.Drawing.Point(14, 74);
            this.txt_Food.Name = "txt_Food";
            this.txt_Food.Size = new System.Drawing.Size(49, 20);
            this.txt_Food.TabIndex = 54;
            this.txt_Food.Text = "Food:";
            // 
            // txt_id
            // 
            this.txt_id.AutoSize = true;
            this.txt_id.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_id.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_id.Location = new System.Drawing.Point(14, 15);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(29, 20);
            this.txt_id.TabIndex = 55;
            this.txt_id.Text = "ID:";
            // 
            // txt_orderID
            // 
            this.txt_orderID.AutoSize = true;
            this.txt_orderID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_orderID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_orderID.Location = new System.Drawing.Point(13, 46);
            this.txt_orderID.Name = "txt_orderID";
            this.txt_orderID.Size = new System.Drawing.Size(75, 20);
            this.txt_orderID.TabIndex = 53;
            this.txt_orderID.Text = "Order ID:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.ForestGreen;
            this.panel1.Controls.Add(this.bttn_cancel);
            this.panel1.Controls.Add(this.bttn_save);
            this.panel1.Controls.Add(this.tb_quantity);
            this.panel1.Controls.Add(this.tb_totalAmount);
            this.panel1.Controls.Add(this.tb_Food);
            this.panel1.Controls.Add(this.tb_orderID);
            this.panel1.Controls.Add(this.txt_quantity);
            this.panel1.Controls.Add(this.txt_totalAmount);
            this.panel1.Controls.Add(this.txt_Food);
            this.panel1.Controls.Add(this.txt_id);
            this.panel1.Controls.Add(this.txt_orderID);
            this.panel1.Location = new System.Drawing.Point(35, 102);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(311, 205);
            this.panel1.TabIndex = 58;
            // 
            // bttn_cancel
            // 
            this.bttn_cancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_cancel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_cancel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_cancel.Location = new System.Drawing.Point(183, 160);
            this.bttn_cancel.Name = "bttn_cancel";
            this.bttn_cancel.Size = new System.Drawing.Size(91, 33);
            this.bttn_cancel.TabIndex = 63;
            this.bttn_cancel.Text = "Cancel";
            this.bttn_cancel.UseVisualStyleBackColor = false;
            this.bttn_cancel.Click += new System.EventHandler(this.bttn_cancel_Click);
            // 
            // bttn_save
            // 
            this.bttn_save.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_save.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_save.Location = new System.Drawing.Point(73, 160);
            this.bttn_save.Name = "bttn_save";
            this.bttn_save.Size = new System.Drawing.Size(91, 33);
            this.bttn_save.TabIndex = 62;
            this.bttn_save.Text = "Save";
            this.bttn_save.UseVisualStyleBackColor = false;
            this.bttn_save.Click += new System.EventHandler(this.bttn_save_Click);
            // 
            // tb_quantity
            // 
            this.tb_quantity.Location = new System.Drawing.Point(130, 126);
            this.tb_quantity.Name = "tb_quantity";
            this.tb_quantity.Size = new System.Drawing.Size(100, 20);
            this.tb_quantity.TabIndex = 61;
            // 
            // tb_totalAmount
            // 
            this.tb_totalAmount.Location = new System.Drawing.Point(130, 100);
            this.tb_totalAmount.Name = "tb_totalAmount";
            this.tb_totalAmount.Size = new System.Drawing.Size(100, 20);
            this.tb_totalAmount.TabIndex = 60;
            // 
            // tb_Food
            // 
            this.tb_Food.Location = new System.Drawing.Point(130, 74);
            this.tb_Food.Name = "tb_Food";
            this.tb_Food.Size = new System.Drawing.Size(100, 20);
            this.tb_Food.TabIndex = 59;
            // 
            // tb_orderID
            // 
            this.tb_orderID.Location = new System.Drawing.Point(130, 48);
            this.tb_orderID.Name = "tb_orderID";
            this.tb_orderID.Size = new System.Drawing.Size(100, 20);
            this.tb_orderID.TabIndex = 58;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(54, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 59;
            this.label1.Text = "Saddams Shawarma";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SeaGreen;
            this.label2.Location = new System.Drawing.Point(85, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 35);
            this.label2.TabIndex = 60;
            this.label2.Text = "Edit Record";
            // 
            // RecordsEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(407, 319);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "RecordsEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RecordsEdit";
            this.Load += new System.EventHandler(this.RecordsEdit_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txt_quantity;
        private System.Windows.Forms.Label txt_totalAmount;
        private System.Windows.Forms.Label txt_Food;
        private System.Windows.Forms.Label txt_id;
        private System.Windows.Forms.Label txt_orderID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_totalAmount;
        private System.Windows.Forms.TextBox tb_Food;
        private System.Windows.Forms.TextBox tb_orderID;
        private System.Windows.Forms.TextBox tb_quantity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bttn_save;
        private System.Windows.Forms.Button bttn_cancel;
    }
}