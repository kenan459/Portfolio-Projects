﻿namespace Saddams_Shawarma
{
    partial class Reciept
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txt_cash = new System.Windows.Forms.Label();
            this.txt_change = new System.Windows.Forms.Label();
            this.txt_item0 = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.Label();
            this.txt_date = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_orderID = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MediumOrchid;
            this.label1.Location = new System.Drawing.Point(136, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 17);
            this.label1.TabIndex = 56;
            this.label1.Text = "Saddams Shawarma";
            // 
            // txt_cash
            // 
            this.txt_cash.AutoSize = true;
            this.txt_cash.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cash.ForeColor = System.Drawing.Color.MediumOrchid;
            this.txt_cash.Location = new System.Drawing.Point(12, 362);
            this.txt_cash.Name = "txt_cash";
            this.txt_cash.Size = new System.Drawing.Size(50, 17);
            this.txt_cash.TabIndex = 57;
            this.txt_cash.Text = "Cash:";
            // 
            // txt_change
            // 
            this.txt_change.AutoSize = true;
            this.txt_change.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_change.ForeColor = System.Drawing.Color.MediumOrchid;
            this.txt_change.Location = new System.Drawing.Point(12, 382);
            this.txt_change.Name = "txt_change";
            this.txt_change.Size = new System.Drawing.Size(69, 17);
            this.txt_change.TabIndex = 58;
            this.txt_change.Text = "Change:";
            // 
            // txt_item0
            // 
            this.txt_item0.AutoSize = true;
            this.txt_item0.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_item0.ForeColor = System.Drawing.Color.MediumOrchid;
            this.txt_item0.Location = new System.Drawing.Point(29, 83);
            this.txt_item0.Name = "txt_item0";
            this.txt_item0.Size = new System.Drawing.Size(36, 17);
            this.txt_item0.TabIndex = 59;
            this.txt_item0.Text = "List";
            // 
            // txt_total
            // 
            this.txt_total.AutoSize = true;
            this.txt_total.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total.ForeColor = System.Drawing.Color.MediumOrchid;
            this.txt_total.Location = new System.Drawing.Point(12, 342);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(51, 17);
            this.txt_total.TabIndex = 64;
            this.txt_total.Text = "Total:";
            // 
            // txt_date
            // 
            this.txt_date.AutoSize = true;
            this.txt_date.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_date.ForeColor = System.Drawing.Color.MediumOrchid;
            this.txt_date.Location = new System.Drawing.Point(194, 39);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(98, 17);
            this.txt_date.TabIndex = 65;
            this.txt_date.Text = "Date Today:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MediumOrchid;
            this.label2.Location = new System.Drawing.Point(29, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 17);
            this.label2.TabIndex = 66;
            this.label2.Text = "Items:";
            // 
            // txt_orderID
            // 
            this.txt_orderID.AutoSize = true;
            this.txt_orderID.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_orderID.ForeColor = System.Drawing.Color.MediumOrchid;
            this.txt_orderID.Location = new System.Drawing.Point(12, 39);
            this.txt_orderID.Name = "txt_orderID";
            this.txt_orderID.Size = new System.Drawing.Size(79, 17);
            this.txt_orderID.TabIndex = 67;
            this.txt_orderID.Text = "Order ID:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Fax", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MediumOrchid;
            this.label3.Location = new System.Drawing.Point(136, 425);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 51);
            this.label3.TabIndex = 68;
            this.label3.Text = "Bob\'s Courtyard,\r\nLa Salle Avenue,\r\nBacolod City";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Reciept
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(439, 509);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_orderID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.txt_total);
            this.Controls.Add(this.txt_item0);
            this.Controls.Add(this.txt_change);
            this.Controls.Add(this.txt_cash);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Reciept";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reciept";
            this.Load += new System.EventHandler(this.Reciept_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txt_cash;
        private System.Windows.Forms.Label txt_change;
        private System.Windows.Forms.Label txt_item0;
        private System.Windows.Forms.Label txt_total;
        private System.Windows.Forms.Label txt_date;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txt_orderID;
        private System.Windows.Forms.Label label3;
    }
}