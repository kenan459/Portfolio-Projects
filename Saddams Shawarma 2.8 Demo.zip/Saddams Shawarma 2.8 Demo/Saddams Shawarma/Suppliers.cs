﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Suppliers : Form
    {
        int e_id;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        DataTable datatable;

        int currec = 0;
        int totalrec = 0;

        int id = 0;

        public Suppliers()
        {
            InitializeComponent();
        }

        private void Suppliers_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblSuppliers ";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;

            if (i > 0)
            {
                DataGridViewRow r = dataGridView1.Rows[i];

                id = Convert.ToInt32(r.Cells[0].Value);

                currec = 0;

                RetrieveData();
            }
        }

        private void RetrieveData()
        {
            string commandString = "Select * from tblSuppliers where  ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            txt_id.Text = datatable.Rows[currec]["ID"].ToString();
            tb_name.Text = datatable.Rows[currec]["Company_Name"].ToString();
            tb_email.Text = datatable.Rows[currec]["Email_Address"].ToString();
            tb_contact.Text = datatable.Rows[currec]["Contact_Number"].ToString();
            tb_address.Text = datatable.Rows[currec]["Address"].ToString();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Manage back = new Manage(e_id);
            back.Show();
            this.Hide();
        }

        private void bttn_delete_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "DELETE FROM tblSuppliers Where ID = " +txt_id.Text;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Contact Deleted");

            conn.Close();

            this.Hide();
            Suppliers refresh = new Suppliers();
            refresh.Show();
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "Update tblSuppliers Set Company_Name = '" + tb_name.Text + "', Email_Address = '" + tb_email.Text + "', Contact_Number = '" + Convert.ToInt32(tb_contact.Text) + "', Address = '" + tb_address.Text + "' Where ID = "+txt_id.Text ;
            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Item Updated");

            conn.Close();

            this.Hide();
            Suppliers refresh = new Suppliers();
            refresh.Show();
        }

        private void bttn_new_Click(object sender, EventArgs e)
        {
            New_Supplier create = new New_Supplier();
            create.Show();
            this.Hide();
        }
    }
}
