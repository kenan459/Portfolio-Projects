﻿namespace Saddams_Shawarma
{
    partial class Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txt_stock = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.bttn_add = new System.Windows.Forms.Button();
            this.tb_quantity = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_price = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txt_stock2 = new System.Windows.Forms.Label();
            this.bttn_add2 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_quantity2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_price2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_name2 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_date = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_OID = new System.Windows.Forms.Label();
            this.bttn_clear = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Item_List = new System.Windows.Forms.ListBox();
            this.bttn_confirm = new System.Windows.Forms.Button();
            this.bttn_compute = new System.Windows.Forms.Button();
            this.txt_change = new System.Windows.Forms.Label();
            this.tb_cash = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_total = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.bttn_back = new System.Windows.Forms.Button();
            this.dp_time = new System.Windows.Forms.DateTimePicker();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Tw Cen MT", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(12, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(565, 428);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.ForestGreen;
            this.tabPage1.Controls.Add(this.txt_stock);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.bttn_add);
            this.tabPage1.Controls.Add(this.tb_quantity);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txt_price);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txt_name);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(557, 398);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Food";
            // 
            // txt_stock
            // 
            this.txt_stock.AutoSize = true;
            this.txt_stock.BackColor = System.Drawing.Color.Chartreuse;
            this.txt_stock.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_stock.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_stock.Location = new System.Drawing.Point(221, 275);
            this.txt_stock.Name = "txt_stock";
            this.txt_stock.Size = new System.Drawing.Size(35, 20);
            this.txt_stock.TabIndex = 46;
            this.txt_stock.Text = "N/A";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(171, 275);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 20);
            this.label13.TabIndex = 45;
            this.label13.Text = "Stock:";
            // 
            // bttn_add
            // 
            this.bttn_add.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_add.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.bttn_add.Location = new System.Drawing.Point(12, 345);
            this.bttn_add.Name = "bttn_add";
            this.bttn_add.Size = new System.Drawing.Size(75, 23);
            this.bttn_add.TabIndex = 44;
            this.bttn_add.Text = "Add";
            this.bttn_add.UseVisualStyleBackColor = false;
            this.bttn_add.Click += new System.EventHandler(this.bttn_add_Click);
            // 
            // tb_quantity
            // 
            this.tb_quantity.Location = new System.Drawing.Point(83, 315);
            this.tb_quantity.Name = "tb_quantity";
            this.tb_quantity.Size = new System.Drawing.Size(43, 24);
            this.tb_quantity.TabIndex = 36;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(11, 315);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 20);
            this.label5.TabIndex = 35;
            this.label5.Text = "Quantity:";
            // 
            // txt_price
            // 
            this.txt_price.AutoSize = true;
            this.txt_price.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_price.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_price.Location = new System.Drawing.Point(61, 295);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(35, 20);
            this.txt_price.TabIndex = 34;
            this.txt_price.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(11, 295);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 33;
            this.label4.Text = "Price:";
            // 
            // txt_name
            // 
            this.txt_name.AutoSize = true;
            this.txt_name.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_name.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_name.Location = new System.Drawing.Point(61, 275);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(35, 20);
            this.txt_name.TabIndex = 32;
            this.txt_name.Text = "N/A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(11, 275);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(11, 275);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 31;
            this.label3.Text = "Name:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 5);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(522, 267);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.ForestGreen;
            this.tabPage2.Controls.Add(this.txt_stock2);
            this.tabPage2.Controls.Add(this.bttn_add2);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.tb_quantity2);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.txt_price2);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.txt_name2);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(557, 398);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Drinks";
            // 
            // txt_stock2
            // 
            this.txt_stock2.AutoSize = true;
            this.txt_stock2.BackColor = System.Drawing.Color.Chartreuse;
            this.txt_stock2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_stock2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_stock2.Location = new System.Drawing.Point(223, 275);
            this.txt_stock2.Name = "txt_stock2";
            this.txt_stock2.Size = new System.Drawing.Size(35, 20);
            this.txt_stock2.TabIndex = 46;
            this.txt_stock2.Text = "N/A";
            // 
            // bttn_add2
            // 
            this.bttn_add2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_add2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_add2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.bttn_add2.Location = new System.Drawing.Point(12, 345);
            this.bttn_add2.Name = "bttn_add2";
            this.bttn_add2.Size = new System.Drawing.Size(75, 23);
            this.bttn_add2.TabIndex = 52;
            this.bttn_add2.Text = "Add";
            this.bttn_add2.UseVisualStyleBackColor = false;
            this.bttn_add2.Click += new System.EventHandler(this.bttn_add2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(173, 275);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 20);
            this.label11.TabIndex = 45;
            this.label11.Text = "Stock:";
            // 
            // tb_quantity2
            // 
            this.tb_quantity2.Location = new System.Drawing.Point(83, 315);
            this.tb_quantity2.Name = "tb_quantity2";
            this.tb_quantity2.Size = new System.Drawing.Size(43, 24);
            this.tb_quantity2.TabIndex = 51;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label10.Location = new System.Drawing.Point(11, 315);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 20);
            this.label10.TabIndex = 50;
            this.label10.Text = "Quantity:";
            // 
            // txt_price2
            // 
            this.txt_price2.AutoSize = true;
            this.txt_price2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_price2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_price2.Location = new System.Drawing.Point(61, 295);
            this.txt_price2.Name = "txt_price2";
            this.txt_price2.Size = new System.Drawing.Size(35, 20);
            this.txt_price2.TabIndex = 49;
            this.txt_price2.Text = "N/A";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(11, 295);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 20);
            this.label12.TabIndex = 48;
            this.label12.Text = "Price:";
            // 
            // txt_name2
            // 
            this.txt_name2.AutoSize = true;
            this.txt_name2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_name2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_name2.Location = new System.Drawing.Point(61, 275);
            this.txt_name2.Name = "txt_name2";
            this.txt_name2.Size = new System.Drawing.Size(35, 20);
            this.txt_name2.TabIndex = 47;
            this.txt_name2.Text = "N/A";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(11, 275);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 20);
            this.label14.TabIndex = 45;
            this.label14.Text = "Name:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Location = new System.Drawing.Point(11, 275);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 20);
            this.label15.TabIndex = 46;
            this.label15.Text = "Name:";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(528, 267);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.ForestGreen;
            this.panel1.Controls.Add(this.txt_date);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.txt_OID);
            this.panel1.Controls.Add(this.bttn_clear);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.Item_List);
            this.panel1.Controls.Add(this.bttn_confirm);
            this.panel1.Controls.Add(this.bttn_compute);
            this.panel1.Controls.Add(this.txt_change);
            this.panel1.Controls.Add(this.tb_cash);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txt_total);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(583, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(432, 456);
            this.panel1.TabIndex = 1;
            // 
            // txt_date
            // 
            this.txt_date.AutoSize = true;
            this.txt_date.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_date.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_date.Location = new System.Drawing.Point(215, 255);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(93, 20);
            this.txt_date.TabIndex = 51;
            this.txt_date.Text = "00/00/0000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(170, 255);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 20);
            this.label9.TabIndex = 50;
            this.label9.Text = "Date:";
            // 
            // txt_OID
            // 
            this.txt_OID.AutoSize = true;
            this.txt_OID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_OID.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_OID.Location = new System.Drawing.Point(86, 255);
            this.txt_OID.Name = "txt_OID";
            this.txt_OID.Size = new System.Drawing.Size(35, 20);
            this.txt_OID.TabIndex = 49;
            this.txt_OID.Text = "N/A";
            // 
            // bttn_clear
            // 
            this.bttn_clear.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_clear.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.bttn_clear.ForeColor = System.Drawing.Color.DarkRed;
            this.bttn_clear.Location = new System.Drawing.Point(22, 212);
            this.bttn_clear.Name = "bttn_clear";
            this.bttn_clear.Size = new System.Drawing.Size(117, 40);
            this.bttn_clear.TabIndex = 45;
            this.bttn_clear.Text = "Clear Order";
            this.bttn_clear.UseVisualStyleBackColor = false;
            this.bttn_clear.Click += new System.EventHandler(this.bttn_clear_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(15, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 20);
            this.label2.TabIndex = 48;
            this.label2.Text = "Order ID:";
            // 
            // Item_List
            // 
            this.Item_List.AccessibleDescription = "";
            this.Item_List.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Item_List.FormattingEnabled = true;
            this.Item_List.ItemHeight = 14;
            this.Item_List.Location = new System.Drawing.Point(19, 20);
            this.Item_List.Name = "Item_List";
            this.Item_List.Size = new System.Drawing.Size(384, 186);
            this.Item_List.TabIndex = 47;
            // 
            // bttn_confirm
            // 
            this.bttn_confirm.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_confirm.Enabled = false;
            this.bttn_confirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_confirm.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.bttn_confirm.Location = new System.Drawing.Point(19, 359);
            this.bttn_confirm.Name = "bttn_confirm";
            this.bttn_confirm.Size = new System.Drawing.Size(75, 37);
            this.bttn_confirm.TabIndex = 46;
            this.bttn_confirm.Text = "Confirm";
            this.bttn_confirm.UseVisualStyleBackColor = false;
            this.bttn_confirm.Click += new System.EventHandler(this.bttn_confirm_Click);
            // 
            // bttn_compute
            // 
            this.bttn_compute.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_compute.Enabled = false;
            this.bttn_compute.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_compute.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.bttn_compute.Location = new System.Drawing.Point(145, 305);
            this.bttn_compute.Name = "bttn_compute";
            this.bttn_compute.Size = new System.Drawing.Size(75, 23);
            this.bttn_compute.TabIndex = 45;
            this.bttn_compute.Text = "Compute";
            this.bttn_compute.UseVisualStyleBackColor = false;
            this.bttn_compute.Click += new System.EventHandler(this.bttn_compute_Click);
            // 
            // txt_change
            // 
            this.txt_change.AutoSize = true;
            this.txt_change.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_change.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_change.Location = new System.Drawing.Point(77, 335);
            this.txt_change.Name = "txt_change";
            this.txt_change.Size = new System.Drawing.Size(35, 20);
            this.txt_change.TabIndex = 42;
            this.txt_change.Text = "N/A";
            // 
            // tb_cash
            // 
            this.tb_cash.Location = new System.Drawing.Point(64, 305);
            this.tb_cash.Name = "tb_cash";
            this.tb_cash.Size = new System.Drawing.Size(75, 20);
            this.tb_cash.TabIndex = 41;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(15, 335);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 20);
            this.label8.TabIndex = 40;
            this.label8.Text = "Change:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(15, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 20);
            this.label7.TabIndex = 39;
            this.label7.Text = "Cash:";
            // 
            // txt_total
            // 
            this.txt_total.AutoSize = true;
            this.txt_total.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_total.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_total.Location = new System.Drawing.Point(65, 275);
            this.txt_total.Name = "txt_total";
            this.txt_total.Size = new System.Drawing.Size(35, 20);
            this.txt_total.TabIndex = 38;
            this.txt_total.Text = "N/A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(15, 275);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 20);
            this.label6.TabIndex = 37;
            this.label6.Text = "Total:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Checked = false;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(504, 21);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(93, 20);
            this.dateTimePicker1.TabIndex = 50;
            this.dateTimePicker1.Value = new System.DateTime(2015, 12, 10, 21, 30, 30, 0);
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(22, 458);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 51;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // dp_time
            // 
            this.dp_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dp_time.Location = new System.Drawing.Point(605, 21);
            this.dp_time.Name = "dp_time";
            this.dp_time.Size = new System.Drawing.Size(117, 20);
            this.dp_time.TabIndex = 52;
            // 
            // Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1027, 523);
            this.ControlBox = false;
            this.Controls.Add(this.dp_time);
            this.Controls.Add(this.bttn_back);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Order";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Order";
            this.Load += new System.EventHandler(this.Order_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label txt_name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label txt_price;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_quantity;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txt_total;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_cash;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label txt_change;
        private System.Windows.Forms.Button bttn_add;
        private System.Windows.Forms.Button bttn_compute;
        private System.Windows.Forms.Button bttn_confirm;
        private System.Windows.Forms.ListBox Item_List;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label txt_OID;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label txt_date;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Button bttn_add2;
        private System.Windows.Forms.TextBox tb_quantity2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label txt_price2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label txt_name2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button bttn_clear;
        private System.Windows.Forms.Label txt_stock;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label txt_stock2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dp_time;
    }
}