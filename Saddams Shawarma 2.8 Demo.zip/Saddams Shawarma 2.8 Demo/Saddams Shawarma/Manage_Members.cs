﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Manage_Members : Form
    {
        int e_id;

        DataTable datatable;
        int totalrec = 0;
        int currec = 0;
        int id = 0;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Users.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Manage_Members(int emp_id)
        {
            InitializeComponent();
            e_id = emp_id;
        }

        private void Manage_Members_Load(object sender, EventArgs e)
        {
            Retrieve();
        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblUsers";
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        private void RetrieveData()
        {
            
            string commandString = "Select * from tblUsers where  ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            txt_id.Text = datatable.Rows[currec]["ID"].ToString();
            tb_name.Text = datatable.Rows[currec]["First_Name"].ToString();
            cb_pos.Text = datatable.Rows[currec]["Acct_Position"].ToString();
            tb_salary.Text = datatable.Rows[currec]["Salary"].ToString();
            txt_activated.Text = datatable.Rows[currec]["Activated"].ToString();
            txt_author.Text = datatable.Rows[currec]["Authorized"].ToString();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Manage back = new Manage(e_id);
            back.Show();
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i >= 0)
            {

                DataGridViewRow r = dataGridView1.Rows[i];

                id = Convert.ToInt32(r.Cells[0].Value);

                currec = 0;

                RetrieveData();
            }
        }

        private void txt_status_Click(object sender, EventArgs e)
        {
            if (txt_activated.Text == "Yes")
            {
                txt_activated.Text = "No";
            }

            else if (txt_activated.Text == "No")
            {
                txt_activated.Text = "Yes";
            }
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "Update tblUsers Set Acct_Position = '" + cb_pos.Text + "', Salary = '" + tb_salary.Text + "', Activated = '" + txt_activated.Text + "', Authorized = '" + txt_author.Text + "' Where ID = " + txt_id.Text;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Member Updated");

            conn.Close();

            this.Hide();
            Manage_Members refresh = new Manage_Members(e_id);
            refresh.Show();
        }

        private void bttn_delete_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "DELETE FROM tblUsers Where ID = " + txt_id.Text;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Member Deleted");

            conn.Close();

            this.Hide();
            Manage_Members refresh = new Manage_Members(e_id);
            refresh.Show();
        }

        private void txt_author_Click(object sender, EventArgs e)
        {
            if (txt_author.Text == "Yes")
            {
                txt_author.Text = "No";
            }

            else if (txt_author.Text == "No")
            {
                txt_author.Text = "Yes";
            }
        }

        private void Btn_NewUser_Click(object sender, EventArgs e)
        {
            Account_Creation create = new Account_Creation(e_id);
            create.Show();
            this.Hide();
        }
    }
}
