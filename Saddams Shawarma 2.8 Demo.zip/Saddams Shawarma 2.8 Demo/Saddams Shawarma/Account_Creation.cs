﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Account_Creation : Form
    {

        int emp_id;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Users.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Account_Creation(int e_id)
        {
            emp_id = e_id;
            InitializeComponent();
        }

        private void bttn_submit_Click(object sender, EventArgs e)
        {
            if (tb_user.Text == "")
            {
                MessageBox.Show("Username Field Cannot Be empty");
            }

            else if (tb_pass.Text == "")
            {
                MessageBox.Show("Password Field Cannot be Empty");
            }
            else if (tb_fname.Text == "")
            {
                MessageBox.Show("Name Field Cannot be Empty");
            }
            else if (cb_pos.Text != "")
            {
                submit();
            }
            else
                MessageBox.Show("Position Cannot be empty");
        }

        private void submit()
        {
            conn.Open();

            string commandString = "insert into tblUsers (Username, Acct_Password, Email, Acct_Position, First_Name, Last_Name, Address, Contact_Number, Activated, Authorized, Date_Joined) "
            + "Values ('" + tb_user.Text + "','" + tb_pass.Text + "','" + tb_email.Text + "','" + cb_pos.Text 
            + "','" + tb_fname.Text + "','" +tb_lname.Text + "','" +tb_address.Text + "','" + tb_contact.Text + "','" + activated_txt.Text + "','" + activated_txt.Text + "','" + dp_date.Text +"')";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            MessageBox.Show("Account Succesfully Created");
            conn.Close();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Manage_Members back = new Manage_Members(emp_id);
            back.Show();
            this.Hide();
        }

        private void Account_Creation_Load(object sender, EventArgs e)
        {
            dp_date.Enabled = false;
            dp_time.Enabled = false;
        }


    }
}
