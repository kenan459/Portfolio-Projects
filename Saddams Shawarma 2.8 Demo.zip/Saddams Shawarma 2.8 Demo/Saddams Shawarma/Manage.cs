﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Saddams_Shawarma
{
    public partial class Manage : Form
    {
        int emp_id;
        public Manage(int e_id)
        {
            InitializeComponent();
            emp_id = e_id;
        }

        private void bttn_records_Click(object sender, EventArgs e)
        {
            Records_View records = new Records_View(emp_id);
            records.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Form1 home = new Form1(emp_id);
            //home.Show();
            this.Hide();
        }

        private void bttn_add_Click(object sender, EventArgs e)
        {
            Food foodMenu = new Food();
            foodMenu.Show();
            this.Hide();
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Manage_Members members = new Manage_Members(emp_id);
            members.Show();
            this.Hide();
        }

        private void bttn_supp_Click(object sender, EventArgs e)
        {
            Suppliers supply = new Suppliers();
            supply.Show();
            this.Hide();
        }

        
    }
}
