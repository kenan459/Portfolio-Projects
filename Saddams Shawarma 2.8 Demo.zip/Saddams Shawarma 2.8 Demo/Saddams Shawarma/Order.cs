﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Order : Form
    {
        DataTable datatable;
        int totalrec = 0;
        int currec = 0;

        
        int stock_new = 0;

        String[] orderID = new String [100];
        String[] food = new String[100];
        String[] stock = new String[100];
        String[] aquantity = new String[100];
        String[] totalAmount = new String[100];
        String[] datePurchased = new String[100];
        String[] timePurchased = new string[100];

        int emp_id;
        String type;
        String getOID;
        int newOrderID;
        int x = 0;

        double total = 0;
        int id = 0;
        int id2 = 0;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Order(int e_id)
        {
            InitializeComponent();

            emp_id = e_id;
        }

        private void Order_Load(object sender, EventArgs e)
        {
            CountRecords();
            Retrieve1();
            Retrieve2();

            String dateToday = dateTimePicker1.Text;
            txt_date.Text = dateToday;
            dateTimePicker1.Visible = false;
            dp_time.Visible = false;
        }

        private void CountRecords()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblRecords";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            getOID = datatable.Rows[totalrec-1]["Order_ID"].ToString();
            newOrderID = Convert.ToInt32(getOID) + 1;
            txt_OID.Text = getOID;
            txt_OID.Text = Convert.ToString(newOrderID);
            
        }

        private void Retrieve1()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblMenu Where Category = 'Food'";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;

        }

        private void Retrieve2()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblMenu Where Category = 'Drinks'";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView2.DataSource = datatable;
        }

        private void bttn_clear_Click(object sender, EventArgs e)
        {
            this.Hide();
            Order refresh = new Order(emp_id);
            refresh.Show();
        }

        private void RetrieveFood()
        {
            string commandString = "Select * from tblMenu where  ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            if (type == "food")
            {
                txt_name.Text = datatable.Rows[currec]["Product_Name"].ToString();
                txt_price.Text = datatable.Rows[currec]["Price"].ToString();
                txt_stock.Text = datatable.Rows[currec]["In_Stock"].ToString();
            }
            else if (type == "drinks")
            {
                txt_name2.Text = datatable.Rows[currec]["Product_Name"].ToString();
                txt_price2.Text = datatable.Rows[currec]["Price"].ToString();
                txt_stock2.Text = datatable.Rows[currec]["In_Stock"].ToString();
            }

            //stock_get = Convert.ToInt32(datatable.Rows[currec]["In_Stock"].ToString());
            //MessageBox.Show("In Stock: "+Convert.ToString(stock_get));
        }

        private void addCompute()
        {
            double subtotal = 0, price = 0, quantity = 0;
            String item;

            price = Convert.ToDouble(txt_price.Text);
            quantity = Convert.ToDouble(tb_quantity.Text);
            subtotal = price * quantity;

            total = total + subtotal;
            txt_total.Text = Convert.ToString(total);

            tb_quantity.Text = "";
            item = txt_name.Text + " || Quantity:" + Convert.ToString(quantity) + " || Amount:" + Convert.ToString(subtotal);
            Item_List.Items.Add(item);
            
            orderID[x] = Convert.ToString(txt_OID.Text);
            food[x] = Convert.ToString(txt_name.Text);
            stock[x] = Convert.ToString(txt_stock.Text);
            aquantity[x] = Convert.ToString(quantity);
            totalAmount[x] = Convert.ToString(subtotal);
            datePurchased[x] = Convert.ToString(txt_date.Text);
            timePurchased[x] = Convert.ToString(dp_time.Text);

            x = x + 1;
            
        }

        private void addCompute2()
        {
            double subtotal = 0, price = 0, quantity = 0;
            String item;

            price = Convert.ToDouble(txt_price2.Text);
            quantity = Convert.ToDouble(tb_quantity2.Text);
            subtotal = price * quantity;

            total = total + subtotal;
            txt_total.Text = Convert.ToString(total);

            tb_quantity2.Text = "";
            item = txt_name2.Text + " || Quantity:" + Convert.ToString(quantity) + " || Amount:" + Convert.ToString(subtotal);
            Item_List.Items.Add(item);

            orderID[x] = Convert.ToString(txt_OID.Text);
            food[x] = Convert.ToString(txt_name2.Text);
            stock[x] = Convert.ToString(txt_stock2.Text);
            aquantity[x] = Convert.ToString(quantity);
            totalAmount[x] = Convert.ToString(subtotal);
            datePurchased[x] = Convert.ToString(txt_date.Text);
            timePurchased[x] = Convert.ToString(dp_time.Text);

            x = x + 1;
        }

        private void changeCompute()
        {
            double cash = 0, change = 0;

            cash = Convert.ToDouble(tb_cash.Text);
            change = cash - total;
            txt_change.Text = Convert.ToString(change);
        }

        private void Confirm()
        {
            

            for (int i = 0; i < x; i++)
            {

                conn.Open();

                //MessageBox.Show(food[i]);
                //MessageBox.Show("current Stock: " + stock[i]);
                stock_new = Convert.ToInt32(stock[i]) - Convert.ToInt32(aquantity[i]);
               // MessageBox.Show(Convert.ToString(stock_new));

                string stockUpdate = "Update tblMenu Set In_Stock = '" + stock_new + "' where Product_Name = '" + food[i] + "'";

                OleDbDataAdapter dataAdapters = new OleDbDataAdapter(stockUpdate, conn);
                DataSet dss = new DataSet();
                dataAdapters.Fill(dss, "prog");


                string commandString = "insert into tblRecords (Order_ID, Product, Quantity, Total_Amount, Date_Purchased, Time_Purchased) "
                + "Values ('" + orderID[i] + "','" + food[i] + "','" + aquantity[i] + "','" + totalAmount[i] + "','" + datePurchased[i] + "','" + timePurchased[i] + "')";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
                DataSet ds = new DataSet();
                dataAdapter.Fill(ds, "prog");

               
                conn.Close();

                
            }
            MessageBox.Show("Transaction Added to Database");
            
            this.Hide();
            Order refresh = new Order(emp_id);
            refresh.Show();     
        }

        private void bttn_add_Click(object sender, EventArgs e)
        {
            if (tb_quantity.Text != "")
            {
                if (Convert.ToInt32(txt_stock.Text) >= Convert.ToInt32(tb_quantity.Text))
                {
                    addCompute();
                    bttn_compute.Enabled = true;
                }
                else
                    MessageBox.Show("Item is Almost out of Stock!");
            }
            else
                MessageBox.Show("Quantity Cannot be Empty!");
        }

        private void bttn_add2_Click(object sender, EventArgs e)
        {
            addCompute2();
            bttn_compute.Enabled = true;
        }



        private void bttn_compute_Click(object sender, EventArgs e)
        {
            if (tb_cash.Text != "")
            {
                if (Convert.ToDouble(tb_cash.Text) < Convert.ToDouble(txt_total.Text))
                    MessageBox.Show("Insufficient Cash");
                else
                {
                    changeCompute();
                    bttn_confirm.Enabled = true;
                }
            }
            else
                MessageBox.Show("Cash Field is Empty!");
        }

        private void bttn_confirm_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Confirm Order?", "Order Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (result == DialogResult.OK)
            {
                Confirm();

                Reciept recibo = new Reciept(orderID[0], txt_total.Text, tb_cash.Text, txt_change.Text, txt_date.Text);
                recibo.Show();

            } 
            
            

        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1(emp_id);
            back.Show();
            this.Close();
        }

        
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;

            if (i >= 0)
            {
                DataGridViewRow r = dataGridView2.Rows[i];

                id = Convert.ToInt32(r.Cells[0].Value);

                currec = 0;

                type = "drinks";

                RetrieveFood();
                tb_quantity2.Text = "";
            }
             
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i>=0)
            {
            

            DataGridViewRow r = dataGridView1.Rows[i];

            id = Convert.ToInt32(r.Cells[0].Value);

            currec = 0;

            type = "food";

            RetrieveFood();
            tb_quantity.Text = "";
            }
             
        }

       

        

        

        
    }
}
