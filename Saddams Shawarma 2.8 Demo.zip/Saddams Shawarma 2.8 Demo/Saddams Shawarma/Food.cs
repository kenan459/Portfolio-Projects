﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Saddams_Shawarma
{
    public partial class Food : Form
    {
        int e_id;

        public Food()
        {
            InitializeComponent();

            
        }
        
        private void bttn_add_Click_1(object sender, EventArgs e)
        {
            AddItem add = new AddItem();
            add.Show();
            this.Hide();
        }

        private void bttn_edit_Click_1(object sender, EventArgs e)
        {
            EditItem edit = new EditItem();
            edit.Show();
            this.Hide();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Manage back = new Manage(e_id);
            back.Show();
            this.Hide();
        }

        private void bttn_stock_Click(object sender, EventArgs e)
        {
            Add_Stock add = new Add_Stock();
            add.Show();
            this.Hide();
        }

        private void bttn_history_Click(object sender, EventArgs e)
        {
            New_Product_Log added = new New_Product_Log();
            added.Show();
            this.Hide();
        }

        private void Food_Load(object sender, EventArgs e)
        {

        }

        
    }
}
