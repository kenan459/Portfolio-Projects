﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class RecordsEdit : Form
    {
        int emp_id;
        DataTable datatable;

        int id=0;

        String order_ID;
        String ID;
        String Food;
        String TotalAmount;
        String Quantity;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public RecordsEdit(int e_id, String idPass, String txt_orderID, String txt_Food, String txt_totalAmount, String txt_quantity)
        {
            InitializeComponent();

            emp_id = e_id;

            order_ID = txt_orderID;
            ID = idPass;
            Food = txt_Food;
            TotalAmount = txt_totalAmount;
            Quantity = txt_quantity;

            Retrieve();
            
        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            //MessageBox.Show("You have chosen " +lname);
            string commandString = "Select * from tblRecords where ID = " + ID;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            FillControls();
        }

        private void FillControls()
        {
            txt_id.Text = "ID: " + datatable.Rows[0]["ID"].ToString();
            tb_orderID.Text = datatable.Rows[0]["Order_ID"].ToString();
            tb_Food.Text = datatable.Rows[0]["Product"].ToString();
            tb_quantity.Text = datatable.Rows[0]["Quantity"].ToString();
            tb_totalAmount.Text = datatable.Rows[0]["Total_Amount"].ToString();
        }

        private void RecordsEdit_Load(object sender, EventArgs e)
        {

        }

        private void bttn_cancel_Click(object sender, EventArgs e)
        {
            Records_View back = new Records_View(emp_id);
            back.Show();
            this.Hide();
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "Update tblRecords Set Order_ID = '" + tb_orderID.Text + "', Product= '" + tb_Food.Text + "', Quantity = '" + tb_quantity.Text + "', Total_Amount = '" + tb_totalAmount.Text + "' Where ID = " + ID;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Record Updated");

            conn.Close();

            this.Hide();
            Records_View refresh = new Records_View(emp_id);
            refresh.Show();
        }
    }
}
