﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class User_Profile : Form
    {
        DataTable datatable;

        int emp_id;

        int totalrec;
        int currec;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Users.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);


        public User_Profile(int e_id)
        {
            InitializeComponent();

            emp_id = e_id;
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1(emp_id);
            back.Show();
            this.Hide();
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            Profile_Edit edit = new Profile_Edit(emp_id);
            edit.Show();
            this.Hide();
        }

        private void User_Profile_Load(object sender, EventArgs e)
        {
            getEmployee();
            RetrieveData();
        }

        private void getEmployee()
        {
            string commandString = "Select * from tblUsers where  ID = " + emp_id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            txt_id.Text = datatable.Rows[currec]["ID"].ToString();
            txt_fname.Text = datatable.Rows[currec]["First_Name"].ToString();
            txt_lname.Text = datatable.Rows[currec]["Last_Name"].ToString();
            txt_address.Text = datatable.Rows[currec]["Address"].ToString();
            txt_email.Text =  datatable.Rows[currec]["Email"].ToString();
            txt_contact.Text = datatable.Rows[currec]["Contact_Number"].ToString();
            txt_pos.Text =  datatable.Rows[currec]["Acct_Position"].ToString();
            txt_salary.Text = datatable.Rows[currec]["Salary"].ToString();
            txt_date.Text = datatable.Rows[currec]["Date_Joined"].ToString();
        }

        private void RetrieveData()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblLog where Employee_ID = " +emp_id;
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        

        
    }
}
