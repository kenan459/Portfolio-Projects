﻿namespace Saddams_Shawarma
{
    partial class Add_Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_price = new System.Windows.Forms.Label();
            this.txt_cat = new System.Windows.Forms.Label();
            this.bttn_back = new System.Windows.Forms.Button();
            this.txt_id = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_instock = new System.Windows.Forms.Label();
            this.cb_supplier = new System.Windows.Forms.ComboBox();
            this.bttn_save = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_amount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dp_time = new System.Windows.Forms.DateTimePicker();
            this.dp_date = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.bttn_edited = new System.Windows.Forms.Button();
            this.bttn_added = new System.Windows.Forms.Button();
            this.bttn_stock = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(477, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 35);
            this.label2.TabIndex = 46;
            this.label2.Text = "Add Stock";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.txt_price);
            this.groupBox1.Controls.Add(this.txt_cat);
            this.groupBox1.Controls.Add(this.bttn_back);
            this.groupBox1.Controls.Add(this.txt_id);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label);
            this.groupBox1.Controls.Add(this.txt_name);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(19, 144);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 425);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Fill up";
            // 
            // txt_price
            // 
            this.txt_price.AutoSize = true;
            this.txt_price.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_price.Location = new System.Drawing.Point(60, 84);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(35, 20);
            this.txt_price.TabIndex = 55;
            this.txt_price.Text = "N/A";
            // 
            // txt_cat
            // 
            this.txt_cat.AutoSize = true;
            this.txt_cat.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_cat.Location = new System.Drawing.Point(88, 108);
            this.txt_cat.Name = "txt_cat";
            this.txt_cat.Size = new System.Drawing.Size(41, 20);
            this.txt_cat.TabIndex = 54;
            this.txt_cat.Text = "N/A:";
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(19, 339);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 52;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // txt_id
            // 
            this.txt_id.AutoSize = true;
            this.txt_id.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_id.Location = new System.Drawing.Point(75, 31);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(36, 20);
            this.txt_id.TabIndex = 37;
            this.txt_id.Text = "000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(15, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 36;
            this.label4.Text = "Item ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(15, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 35;
            this.label1.Text = "Category:";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label.Location = new System.Drawing.Point(15, 84);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(51, 20);
            this.label.TabIndex = 33;
            this.label.Text = "Price:";
            // 
            // txt_name
            // 
            this.txt_name.AutoSize = true;
            this.txt_name.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_name.Location = new System.Drawing.Point(64, 58);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(35, 20);
            this.txt_name.TabIndex = 30;
            this.txt_name.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(15, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Name:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txt_instock);
            this.groupBox2.Controls.Add(this.cb_supplier);
            this.groupBox2.Controls.Add(this.bttn_save);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.tb_amount);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(9, 116);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(268, 197);
            this.groupBox2.TabIndex = 58;
            this.groupBox2.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(4, 75);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 22);
            this.label7.TabIndex = 58;
            this.label7.Text = "Supplier:";
            // 
            // txt_instock
            // 
            this.txt_instock.AutoSize = true;
            this.txt_instock.BackColor = System.Drawing.Color.Chartreuse;
            this.txt_instock.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_instock.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_instock.Location = new System.Drawing.Point(66, 21);
            this.txt_instock.Name = "txt_instock";
            this.txt_instock.Size = new System.Drawing.Size(36, 20);
            this.txt_instock.TabIndex = 56;
            this.txt_instock.Text = "000";
            // 
            // cb_supplier
            // 
            this.cb_supplier.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_supplier.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_supplier.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_supplier.FormattingEnabled = true;
            this.cb_supplier.Location = new System.Drawing.Point(104, 75);
            this.cb_supplier.Name = "cb_supplier";
            this.cb_supplier.Size = new System.Drawing.Size(158, 25);
            this.cb_supplier.TabIndex = 2;
            // 
            // bttn_save
            // 
            this.bttn_save.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_save.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_save.Location = new System.Drawing.Point(11, 108);
            this.bttn_save.Name = "bttn_save";
            this.bttn_save.Size = new System.Drawing.Size(91, 36);
            this.bttn_save.TabIndex = 3;
            this.bttn_save.Text = "Confirm";
            this.bttn_save.UseVisualStyleBackColor = false;
            this.bttn_save.Click += new System.EventHandler(this.bttn_save_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(6, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 18);
            this.label6.TabIndex = 57;
            this.label6.Text = "STOCK TO ADD:";
            // 
            // tb_amount
            // 
            this.tb_amount.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_amount.Location = new System.Drawing.Point(100, 46);
            this.tb_amount.Name = "tb_amount";
            this.tb_amount.Size = new System.Drawing.Size(58, 23);
            this.tb_amount.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 18);
            this.label5.TabIndex = 53;
            this.label5.Text = "In Stock:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(350, 85);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(532, 413);
            this.dataGridView1.TabIndex = 44;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // dp_time
            // 
            this.dp_time.Enabled = false;
            this.dp_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dp_time.Location = new System.Drawing.Point(1081, 10);
            this.dp_time.Name = "dp_time";
            this.dp_time.Size = new System.Drawing.Size(82, 20);
            this.dp_time.TabIndex = 48;
            // 
            // dp_date
            // 
            this.dp_date.Enabled = false;
            this.dp_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dp_date.Location = new System.Drawing.Point(1169, 10);
            this.dp_date.Name = "dp_date";
            this.dp_date.Size = new System.Drawing.Size(93, 20);
            this.dp_date.TabIndex = 49;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.ForestGreen;
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(25, 97);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1214, 576);
            this.panel1.TabIndex = 50;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox3.Controls.Add(this.bttn_edited);
            this.groupBox3.Controls.Add(this.bttn_added);
            this.groupBox3.Controls.Add(this.bttn_stock);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox3.Location = new System.Drawing.Point(19, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(295, 126);
            this.groupBox3.TabIndex = 73;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Options";
            // 
            // bttn_edited
            // 
            this.bttn_edited.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_edited.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_edited.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_edited.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_edited.Location = new System.Drawing.Point(101, 34);
            this.bttn_edited.Name = "bttn_edited";
            this.bttn_edited.Size = new System.Drawing.Size(91, 81);
            this.bttn_edited.TabIndex = 72;
            this.bttn_edited.Text = "Edited";
            this.bttn_edited.UseVisualStyleBackColor = false;
            this.bttn_edited.Click += new System.EventHandler(this.bttn_edited_Click);
            // 
            // bttn_added
            // 
            this.bttn_added.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_added.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_added.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_added.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_added.Location = new System.Drawing.Point(6, 33);
            this.bttn_added.Name = "bttn_added";
            this.bttn_added.Size = new System.Drawing.Size(91, 81);
            this.bttn_added.TabIndex = 73;
            this.bttn_added.Text = "Create";
            this.bttn_added.UseVisualStyleBackColor = false;
            this.bttn_added.Click += new System.EventHandler(this.bttn_added_Click);
            // 
            // bttn_stock
            // 
            this.bttn_stock.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_stock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_stock.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_stock.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_stock.Location = new System.Drawing.Point(196, 34);
            this.bttn_stock.Name = "bttn_stock";
            this.bttn_stock.Size = new System.Drawing.Size(91, 81);
            this.bttn_stock.TabIndex = 71;
            this.bttn_stock.Text = "Add Stocks";
            this.bttn_stock.UseVisualStyleBackColor = false;
            this.bttn_stock.Click += new System.EventHandler(this.bttn_stock_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.ForestGreen;
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(445, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(408, 68);
            this.panel2.TabIndex = 72;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Gill Sans MT", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label8.Location = new System.Drawing.Point(55, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(304, 48);
            this.label8.TabIndex = 59;
            this.label8.Text = "Manage Products";
            // 
            // Add_Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1274, 696);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.dp_date);
            this.Controls.Add(this.dp_time);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Add_Stock";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Stock";
            this.Load += new System.EventHandler(this.Add_Stock_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label txt_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label txt_price;
        private System.Windows.Forms.Label txt_cat;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Label txt_name;
        private System.Windows.Forms.TextBox tb_amount;
        private System.Windows.Forms.Button bttn_save;
        private System.Windows.Forms.Label txt_instock;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cb_supplier;
        private System.Windows.Forms.DateTimePicker dp_time;
        private System.Windows.Forms.DateTimePicker dp_date;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button bttn_edited;
        private System.Windows.Forms.Button bttn_added;
        private System.Windows.Forms.Button bttn_stock;
    }
}