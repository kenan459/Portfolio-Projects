﻿namespace Saddams_Shawarma
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_price = new System.Windows.Forms.Label();
            this.acctCreation_txt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.bttn_go = new System.Windows.Forms.Button();
            this.dp_date = new System.Windows.Forms.DateTimePicker();
            this.dp_time = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(44, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 12;
            this.label1.Text = "Saddams Shawarma";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Saddams_Shawarma.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(111, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 153);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.txt_price);
            this.groupBox1.Controls.Add(this.acctCreation_txt);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(47, 198);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(283, 274);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            // 
            // txt_price
            // 
            this.txt_price.AutoSize = true;
            this.txt_price.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_price.Location = new System.Drawing.Point(90, 107);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(79, 20);
            this.txt_price.TabIndex = 33;
            this.txt_price.Text = "Password:";
            // 
            // acctCreation_txt
            // 
            this.acctCreation_txt.AutoSize = true;
            this.acctCreation_txt.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.acctCreation_txt.Location = new System.Drawing.Point(18, 236);
            this.acctCreation_txt.Name = "acctCreation_txt";
            this.acctCreation_txt.Size = new System.Drawing.Size(131, 20);
            this.acctCreation_txt.TabIndex = 30;
            this.acctCreation_txt.Text = "Account Creation";
            this.acctCreation_txt.Click += new System.EventHandler(this.acctCreation_txt_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(90, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Username:";
            // 
            // tb_user
            // 
            this.tb_user.Location = new System.Drawing.Point(139, 283);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(100, 20);
            this.tb_user.TabIndex = 33;
            this.tb_user.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_user_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.ForestGreen;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Honeydew;
            this.label2.Location = new System.Drawing.Point(141, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 35);
            this.label2.TabIndex = 34;
            this.label2.Text = "Login";
            // 
            // tb_pass
            // 
            this.tb_pass.Location = new System.Drawing.Point(139, 328);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.PasswordChar = '*';
            this.tb_pass.Size = new System.Drawing.Size(100, 20);
            this.tb_pass.TabIndex = 35;
            this.tb_pass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_pass_KeyPress);
            // 
            // bttn_go
            // 
            this.bttn_go.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_go.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_go.Location = new System.Drawing.Point(139, 354);
            this.bttn_go.Name = "bttn_go";
            this.bttn_go.Size = new System.Drawing.Size(101, 33);
            this.bttn_go.TabIndex = 42;
            this.bttn_go.Text = "Login";
            this.bttn_go.UseVisualStyleBackColor = true;
            this.bttn_go.Click += new System.EventHandler(this.bttn_go_Click);
            // 
            // dp_date
            // 
            this.dp_date.Enabled = false;
            this.dp_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dp_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dp_date.Location = new System.Drawing.Point(281, 2);
            this.dp_date.Name = "dp_date";
            this.dp_date.Size = new System.Drawing.Size(90, 15);
            this.dp_date.TabIndex = 49;
            // 
            // dp_time
            // 
            this.dp_time.Enabled = false;
            this.dp_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dp_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dp_time.Location = new System.Drawing.Point(281, 23);
            this.dp_time.Name = "dp_time";
            this.dp_time.Size = new System.Drawing.Size(90, 15);
            this.dp_time.TabIndex = 48;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(371, 527);
            this.Controls.Add(this.dp_date);
            this.Controls.Add(this.dp_time);
            this.Controls.Add(this.bttn_go);
            this.Controls.Add(this.tb_pass);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_user);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label txt_price;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.Button bttn_go;
        private System.Windows.Forms.Label acctCreation_txt;
        private System.Windows.Forms.DateTimePicker dp_date;
        private System.Windows.Forms.DateTimePicker dp_time;
    }
}