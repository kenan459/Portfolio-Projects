﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Daily_Report : Form
    {
        DataTable datatable;
        int totalrec = 0;
        int currec = 0;
        int emp_id;

        

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);
        
        public Daily_Report()
        {
            InitializeComponent();
            
        }

        private void Daily_Report_Load(object sender, EventArgs e)
        {
            Retrieve();
            init();

            txt_date.Text = dateTimePicker1.Text;
        }

        private void Retrieve()
        {
            int amt_curr = 0;
            int amt_add = 0;
            
            DataSet ds = new DataSet();

            string commandString = "select * from tblRecords where Date_Purchased like '%" + dateTimePicker1.Text + "%'";
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;

            
            for (int i = 0;  i<totalrec; i++)
            {
                amt_add = Convert.ToInt32(datatable.Rows[i]["Total_Amount"].ToString());
                amt_curr = amt_curr + amt_add;
            }
            txt_total.Text = Convert.ToString(amt_curr);

            dateTimePicker1.Visible = false;
        }

        private void init()
        {
           
            
        }

        

    }
}
