﻿namespace Saddams_Shawarma
{
    partial class Records_View
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_quantity = new System.Windows.Forms.Label();
            this.txt_totalAmount = new System.Windows.Forms.Label();
            this.txt_Food = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.Label();
            this.txt_orderID = new System.Windows.Forms.Label();
            this.bttn_search = new System.Windows.Forms.Button();
            this.bttn_delete = new System.Windows.Forms.Button();
            this.bttn_edit = new System.Windows.Forms.Button();
            this.cb_cat = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_search = new System.Windows.Forms.TextBox();
            this.bttn_back = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SeaGreen;
            this.label2.Location = new System.Drawing.Point(285, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 35);
            this.label2.TabIndex = 13;
            this.label2.Text = "Sales Record";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(240, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 14;
            this.label1.Text = "Saddams Shawarma";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(33, 73);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(680, 297);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(379, 48);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(96, 20);
            this.dateTimePicker1.TabIndex = 17;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.bttn_search);
            this.groupBox1.Controls.Add(this.bttn_delete);
            this.groupBox1.Controls.Add(this.bttn_edit);
            this.groupBox1.Controls.Add(this.cb_cat);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.tb_search);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.bttn_back);
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(753, 516);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel1.Controls.Add(this.txt_quantity);
            this.panel1.Controls.Add(this.txt_totalAmount);
            this.panel1.Controls.Add(this.txt_Food);
            this.panel1.Controls.Add(this.txt_id);
            this.panel1.Controls.Add(this.txt_orderID);
            this.panel1.Location = new System.Drawing.Point(174, 376);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(276, 69);
            this.panel1.TabIndex = 47;
            // 
            // txt_quantity
            // 
            this.txt_quantity.AutoSize = true;
            this.txt_quantity.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_quantity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_quantity.Location = new System.Drawing.Point(110, 22);
            this.txt_quantity.Name = "txt_quantity";
            this.txt_quantity.Size = new System.Drawing.Size(76, 20);
            this.txt_quantity.TabIndex = 52;
            this.txt_quantity.Text = "Quantity:";
            // 
            // txt_totalAmount
            // 
            this.txt_totalAmount.AutoSize = true;
            this.txt_totalAmount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_totalAmount.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_totalAmount.Location = new System.Drawing.Point(110, 2);
            this.txt_totalAmount.Name = "txt_totalAmount";
            this.txt_totalAmount.Size = new System.Drawing.Size(110, 20);
            this.txt_totalAmount.TabIndex = 51;
            this.txt_totalAmount.Text = "Total Amount:";
            // 
            // txt_Food
            // 
            this.txt_Food.AutoSize = true;
            this.txt_Food.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Food.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_Food.Location = new System.Drawing.Point(3, 37);
            this.txt_Food.Name = "txt_Food";
            this.txt_Food.Size = new System.Drawing.Size(49, 20);
            this.txt_Food.TabIndex = 50;
            this.txt_Food.Text = "Food:";
            // 
            // txt_id
            // 
            this.txt_id.AutoSize = true;
            this.txt_id.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_id.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_id.Location = new System.Drawing.Point(3, 0);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(29, 20);
            this.txt_id.TabIndex = 50;
            this.txt_id.Text = "ID:";
            // 
            // txt_orderID
            // 
            this.txt_orderID.AutoSize = true;
            this.txt_orderID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_orderID.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_orderID.Location = new System.Drawing.Point(3, 17);
            this.txt_orderID.Name = "txt_orderID";
            this.txt_orderID.Size = new System.Drawing.Size(75, 20);
            this.txt_orderID.TabIndex = 49;
            this.txt_orderID.Text = "Order ID:";
            // 
            // bttn_search
            // 
            this.bttn_search.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_search.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_search.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_search.Location = new System.Drawing.Point(244, 44);
            this.bttn_search.Name = "bttn_search";
            this.bttn_search.Size = new System.Drawing.Size(70, 26);
            this.bttn_search.TabIndex = 46;
            this.bttn_search.Text = "Search";
            this.bttn_search.UseVisualStyleBackColor = false;
            this.bttn_search.Click += new System.EventHandler(this.bttn_search_Click);
            // 
            // bttn_delete
            // 
            this.bttn_delete.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_delete.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_delete.ForeColor = System.Drawing.Color.Maroon;
            this.bttn_delete.Location = new System.Drawing.Point(288, 451);
            this.bttn_delete.Name = "bttn_delete";
            this.bttn_delete.Size = new System.Drawing.Size(91, 33);
            this.bttn_delete.TabIndex = 45;
            this.bttn_delete.Text = "Delete";
            this.bttn_delete.UseVisualStyleBackColor = false;
            this.bttn_delete.Click += new System.EventHandler(this.bttn_delete_Click);
            // 
            // bttn_edit
            // 
            this.bttn_edit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_edit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_edit.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_edit.Location = new System.Drawing.Point(191, 451);
            this.bttn_edit.Name = "bttn_edit";
            this.bttn_edit.Size = new System.Drawing.Size(91, 33);
            this.bttn_edit.TabIndex = 44;
            this.bttn_edit.Text = "Edit";
            this.bttn_edit.UseVisualStyleBackColor = false;
            this.bttn_edit.Click += new System.EventHandler(this.bttn_edit_Click);
            // 
            // cb_cat
            // 
            this.cb_cat.FormattingEnabled = true;
            this.cb_cat.Items.AddRange(new object[] {
            "All",
            "Order ID",
            "Food",
            "Quantity",
            "ID"});
            this.cb_cat.Location = new System.Drawing.Point(139, 46);
            this.cb_cat.Name = "cb_cat";
            this.cb_cat.Size = new System.Drawing.Size(99, 21);
            this.cb_cat.TabIndex = 21;
            this.cb_cat.Text = "All";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Honeydew;
            this.label4.Location = new System.Drawing.Point(29, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 20);
            this.label4.TabIndex = 20;
            this.label4.Text = "Search:";
            // 
            // tb_search
            // 
            this.tb_search.Location = new System.Drawing.Point(33, 47);
            this.tb_search.Name = "tb_search";
            this.tb_search.Size = new System.Drawing.Size(100, 20);
            this.tb_search.TabIndex = 19;
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(33, 375);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 16;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Honeydew;
            this.label3.Location = new System.Drawing.Point(319, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 18;
            this.label3.Text = "Date:";
            // 
            // Records_View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(790, 677);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Records_View";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sales Records";
            this.Load += new System.EventHandler(this.Records_View_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_search;
        private System.Windows.Forms.ComboBox cb_cat;
        private System.Windows.Forms.Button bttn_delete;
        private System.Windows.Forms.Button bttn_edit;
        private System.Windows.Forms.Button bttn_search;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label txt_id;
        private System.Windows.Forms.Label txt_orderID;
        private System.Windows.Forms.Label txt_Food;
        private System.Windows.Forms.Label txt_quantity;
        private System.Windows.Forms.Label txt_totalAmount;
    }
}