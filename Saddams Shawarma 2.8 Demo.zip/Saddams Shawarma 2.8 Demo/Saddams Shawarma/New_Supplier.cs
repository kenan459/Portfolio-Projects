﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class New_Supplier : Form
    {



        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public New_Supplier()
        {
            InitializeComponent();
        }

        private void bttn_confirm_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure to add:" + System.Environment.NewLine
                    + "Company Name: " + tb_name.Text + System.Environment.NewLine + "Email: " + tb_email.Text + System.Environment.NewLine +
                    "Contact#: " + tb_contact.Text +System.Environment.NewLine + "Address: " + tb_address.Text + System.Environment.NewLine + "To Supplier Database?"
                    , "New Supplier Confirmation"
                    , MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (result == DialogResult.OK)
            {
                save();

            } 
            
        }

        private void save()
        {
            conn.Open();

            string commandString = "insert into tblSuppliers (Company_Name, Email_Address, Contact_Number, Address) "
            + "Values ('" + tb_name.Text + "','" + tb_email.Text + "','" + tb_contact.Text + "','" + tb_address.Text + "')";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            MessageBox.Show("Supplier Added");
            conn.Close();

            Suppliers ok = new Suppliers();
            ok.Show();
            this.Hide();
        }

        private void bttn_cancel_Click(object sender, EventArgs e)
        {
            Suppliers back = new Suppliers();
            back.Show();
            this.Hide();
        }
    }
}
