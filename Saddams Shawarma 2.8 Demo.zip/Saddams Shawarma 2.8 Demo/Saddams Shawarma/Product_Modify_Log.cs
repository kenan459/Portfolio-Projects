﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Product_Modify_Log : Form
    {
        DataTable datatable;

        int id;
        int currec;
        int totalrec;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Product_Modify_Log()
        {
            InitializeComponent();
        }

        private void Product_Modify_Log_Load(object sender, EventArgs e)
        {
            loadTable();
        }

        private void loadTable()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblModifyProducts";
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        private void bttn_edited_Click(object sender, EventArgs e)
        {
            Product_Modify_Log edits = new Product_Modify_Log();
            edits.Show();
            this.Hide();
        }

        private void bttn_added_Click(object sender, EventArgs e)
        {
            New_Product_Log added = new New_Product_Log();
            added.Show();
            this.Hide();
        }

        private void bttn_stock_Click(object sender, EventArgs e)
        {
            this.Hide();
            Stock_Transaction_History stock = new Stock_Transaction_History();
            stock.Show();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Food back = new Food();
            back.Show();
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;

            DataGridViewRow r = dataGridView1.Rows[i];

            id = Convert.ToInt32(r.Cells[0].Value);

            currec = 0;

            RetrieveData();
        }

        private void RetrieveData()
        {
            string commandString = "Select * from tblModifyProducts where  ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            txt_event.Text = datatable.Rows[currec]["Event_Type"].ToString();
            txt_id.Text = datatable.Rows[currec]["ID"].ToString();
            txt_pname.Text = datatable.Rows[currec]["Previous_Name"].ToString();
            txt_nname.Text = datatable.Rows[currec]["New_Name"].ToString();
            txt_pprice.Text = datatable.Rows[currec]["Previous_Price"].ToString();
            txt_nprice.Text = datatable.Rows[currec]["New_Price"].ToString();
            txt_pcat.Text = datatable.Rows[currec]["Previous_Category"].ToString();
            txt_ncat.Text = datatable.Rows[currec]["New_Category"].ToString();
            txt_date.Text = datatable.Rows[currec]["Event_Date"].ToString();
            txt_time.Text = datatable.Rows[currec]["Event_Time"].ToString();

            if (txt_event.Text == "Product Deleted")
            {
                txt_nn.Visible = false;
                txt_nname.Visible = false;
                txt_np.Visible = false;
                txt_nprice.Visible = false;
                txt_nc.Visible = false;
                txt_ncat.Visible = false;
            }
            else
            {
                txt_nn.Visible = true;
                txt_nname.Visible = true;
                txt_np.Visible = true;
                txt_nprice.Visible = true;
                txt_nc.Visible = true;
                txt_ncat.Visible = true;
            }
        }
    }
}
