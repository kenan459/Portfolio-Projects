﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class AddItem : Form
    {
        DataTable datatable;
        int totalrec = 0;
        int currec = 0;



        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public AddItem()
        {
            InitializeComponent();
        }

        private void AddItem_Load(object sender, EventArgs e)
        {
            tb_cat.Text = "Food";
            Retrieve();
            suppliersLoad();

        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblMenu";
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
            
        }

        private void suppliersLoad()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblSuppliers ";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            for (int x = 0; x < totalrec; x++)
            {
                cb_supplier.Items.Add(datatable.Rows[x]["Company_Name"].ToString());
            }

        }


        private void bttn_confirm_Click(object sender, EventArgs e)
        {
            if (tb_name.Text == "")
                MessageBox.Show("Product Name Field is Empty!");
            else if (tb_price.Text == "")
                MessageBox.Show("Price Value Cannot be Empty!");
            else if (tb_cat.Text != "")
            {
                DialogResult result = MessageBox.Show("Are you sure to add:" + System.Environment.NewLine
                    + "Name: " +tb_name.Text + System.Environment.NewLine + "Price: " +tb_price.Text + System.Environment.NewLine +
                    "Category: " + tb_cat.Text
                    , "New Product Confirmation"
                    , MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.OK)
                {
                    ok();
                    
                } 
                
            }
            else
                MessageBox.Show("Please Choose a Product Category");
        }

        private void ok()
        {
            int amount;

            amount = Convert.ToInt32(tb_amount.Text);

            conn.Open();

            string commandString = "insert into tblMenu (Product_Name, Price, Category, In_Stock) "
            + "Values ('" + tb_name.Text + "','" + tb_price.Text + "','" + tb_cat.Text + "','" + amount + "')";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            MessageBox.Show("Product Added");
            conn.Close();


            this.Hide();
            AddItem refresh = new AddItem();
            refresh.Show();

            addTransaction();
        }

        private void addTransaction()
        {
            conn.Open();

            string sql = "Insert Into tblNewProdTransaction (Product, Price, Category, Initial_Stock, Supplier, Date_Added, Time_Added) "
            + "Values ('" + tb_name.Text + "','" + tb_price.Text + "','" + tb_cat.Text + "','" + tb_amount.Text
            + "','" + cb_supplier.Text + "','" + dp_date.Text + "','" + dp_time.Text + "')";

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");

            

            conn.Close();
        }

        private void bttn_back_Click_1(object sender, EventArgs e)
        {
            Food back = new Food();
            back.Show();
            this.Hide();
        }

        private void bttn_added_Click(object sender, EventArgs e)
        {
            AddItem add = new AddItem();
            add.Show();
            this.Hide();
        }

        private void bttn_edited_Click(object sender, EventArgs e)
        {
            EditItem edit = new EditItem();
            edit.Show();
            this.Hide();
        }

        private void bttn_stock_Click(object sender, EventArgs e)
        {
            Add_Stock stock = new Add_Stock();
            stock.Show();
            this.Hide();
        }

        

        

        
        
    }
}
