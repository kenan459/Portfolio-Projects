﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class EditItem : Form
    {
        int emp_id;

        DataTable datatable;
        int totalrec = 0;
        int currec = 0;
        int id = 0;



        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public EditItem()
        {
            InitializeComponent();
            
        }

        private void EditItem_Load(object sender, EventArgs e)
        {
            Retrieve();
        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblMenu";
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Food back = new Food();
            back.Show();
            this.Hide();
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            if (tb_name.Text == "")
                MessageBox.Show("Product Name Cannot be Empty!");
            else if (tb_price.Text == "")
                MessageBox.Show("Price Value Cannot Be Empty!");
            else if (tb_cat.Text != "")
            {
                DialogResult result = MessageBox.Show("Are you sure you want to save changes?", "Save", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (result == DialogResult.OK)
                {
                    getdata();
                    save();
                } 
                
            }
            else
                MessageBox.Show("Category Field Cannot be Empty!");
        }

        private void getdata()
        {
            String prev_name, new_name, prev_price, new_price, prev_cat, new_cat, event_type, event_date, event_time;

            prev_name = datatable.Rows[currec]["Product_Name"].ToString();
            new_name = tb_name.Text;
            prev_price = datatable.Rows[currec]["Price"].ToString();
            new_price = tb_price.Text;
            prev_cat = datatable.Rows[currec]["Category"].ToString();
            new_cat = tb_cat.Text;
            event_type = "Product Modified";
            event_date = dp_date.Text;
            event_time = dp_time.Text;

            conn.Open();

            string sql = "Insert Into tblModifyProducts (Previous_Name, New_Name, Previous_Price, New_Price, Previous_Category, New_Category, Event_Type, Event_Date, Event_Time) "
            + "Values ('" + prev_name + "','" + new_name + "','" + prev_price + "','" + new_price + "','" + prev_cat + "','" + new_cat + "','" +
            event_type + "','" + event_date + "','" + event_time + "')";

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");



            conn.Close();

        }

        private void save()
        {
            conn.Open();
            string sql = "Update tblMenu Set Product_Name = '" + tb_name.Text + "', Price = '" + tb_price.Text + "', Category = '" + tb_cat.Text + "' Where ID = " + txt_id.Text;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Item Updated");

            conn.Close();

            this.Hide();
            EditItem refresh = new EditItem();
            refresh.Show();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i >= 0)
            {
                DataGridViewRow r = dataGridView1.Rows[i];

                id = Convert.ToInt32(r.Cells[0].Value);

                currec = 0;

                RetrieveData();
            }
        }

        private void RetrieveData()
        {
            string commandString = "Select * from tblMenu where  ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            txt_id.Text = datatable.Rows[currec]["ID"].ToString();
            tb_name.Text = datatable.Rows[currec]["Product_Name"].ToString();
            tb_price.Text = datatable.Rows[currec]["Price"].ToString();
            tb_cat.Text = datatable.Rows[currec]["Category"].ToString();
        }

        private void bttn_delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Delete This Product?", "Warning!", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (result == DialogResult.OK)
            {
                deleteinfo();
                delete();
            } 
        }

        private void deleteinfo()
        {
            String prev_name, new_name, prev_price, new_price, prev_cat, new_cat, event_type, event_date, event_time;

            prev_name = datatable.Rows[currec]["Product_Name"].ToString();
            new_name = "";
            prev_price = datatable.Rows[currec]["Price"].ToString();
            new_price = "";
            prev_cat = datatable.Rows[currec]["Category"].ToString();
            new_cat = "";
            event_type = "Product Deleted";
            event_date = dp_date.Text;
            event_time = dp_time.Text;
            
            conn.Open();

            string sql = "Insert Into tblModifyProducts (Previous_Name, New_Name, Previous_Price, New_Price, Previous_Category, New_Category, Event_Type, Event_Date, Event_Time) "
            + "Values ('" + prev_name + "','" + new_name + "','" + prev_price + "','" + new_price + "','" + prev_cat + "','" + new_cat + "','" +
            event_type + "','" + event_date + "','" + event_time + "')";

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");



            conn.Close();
        }

        private void delete()
        {
            conn.Open();
            string sql = "DELETE FROM tblMenu Where ID = " + txt_id.Text;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Item Deleted");

            conn.Close();

            this.Hide();
            EditItem refresh = new EditItem();
            refresh.Show();
        }

        private void bttn_added_Click(object sender, EventArgs e)
        {
            AddItem add = new AddItem();
            add.Show();
            this.Hide();
        }

        private void bttn_edited_Click(object sender, EventArgs e)
        {
            EditItem edit = new EditItem();
            edit.Show();
            this.Hide();
        }

        private void bttn_stock_Click(object sender, EventArgs e)
        {
            Add_Stock stock = new Add_Stock();
            stock.Show();
            this.Hide();
        }

        

        
    }
}
