﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Login : Form
    {
        int emp_id;
        int totalrec = 0;
        int currec = 0;
        String session;
        string pangalan;
        string position;
        string logtype;

        DataTable datatable;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Users.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Login()
        {
            InitializeComponent();
            acctCreation_txt.Visible = false;
        }

        private void attempt()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblUsers where Username ='" + tb_user.Text + "' And Acct_Password = '" + tb_pass.Text + "'";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            String activated;
           // activated = datatable.Rows[totalrec]["Activated"].ToString();

            

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            totalrec = datatable.Rows.Count;


            if (totalrec == 1)
            {
                //MessageBox.Show(Convert.ToString("Welcome Administrator"));
                //session = "Admin";
                
                activated = datatable.Rows[0]["Activated"].ToString();
                //MessageBox.Show(datatable.Rows[0]["Activated"].ToString());
                if (activated == "Yes")
                {
                    
                    emp_id = Convert.ToInt32(datatable.Rows[currec]["ID"].ToString());
                    employeeInfo();
                    inlog();

                    //MessageBox.Show(emp_id);
                    MessageBox.Show("Welcome: " + datatable.Rows[0]["First_Name"].ToString());

                    Form1 menu = new Form1(emp_id);
                    menu.Show();
                    this.Hide();
                }
                else if (activated != ("Yes"))
                {
                    MessageBox.Show("Account is not yet activated Please See The Manager!");
                    tb_pass.Text = "";
                }
            }
            else if (totalrec == 0)
            {
                MessageBox.Show("Wrong Username or Password!");
                tb_pass.Text = "";
            }
        }

        private void employeeInfo()
        {

            DataSet ds = new DataSet();
            //MessageBox.Show("You have chosen " +lname);
            string commandString = "Select * from tblUsers where  ID = " + emp_id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            totalrec = datatable.Rows.Count;

            logtype = "Log-In";
            position = datatable.Rows[0]["Acct_Position"].ToString();
            pangalan = datatable.Rows[0]["First_Name"].ToString() + " " + datatable.Rows[0]["Last_Name"].ToString();
        }

        private void inlog()
        {
            conn.Open();

            string sql = "Insert Into tblLog (Employee_Name, Log_Time, Log_Date, Employee_Position, Employee_ID, Log_Type) "
            + "Values ('" + pangalan + "','" + dp_time.Text + "','" + dp_date.Text + "','" + position + "','" + emp_id + "','" + logtype +"')";

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");



            conn.Close();
        }

        private void bttn_go_Click(object sender, EventArgs e)
        {
            attempt();
        }

        private void tb_pass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                attempt();
        }

        private void tb_user_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
                attempt();
        }

        private void acctCreation_txt_Click(object sender, EventArgs e)
        {
            Account_Creation create = new Account_Creation(emp_id);
            create.Show();
            this.Hide();
        }
    }
}
