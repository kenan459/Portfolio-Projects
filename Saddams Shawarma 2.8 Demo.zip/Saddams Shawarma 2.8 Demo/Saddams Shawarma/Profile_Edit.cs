﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Profile_Edit : Form
    {
        int e_id;
        int totalrec;
        int currec;
        DataTable datatable;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Users.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);



        public Profile_Edit(int emp_id)
        {
            InitializeComponent();
            e_id = emp_id;
        }

        private void bttn_cancel_Click(object sender, EventArgs e)
        {
            User_Profile back = new User_Profile(e_id);
            back.Show();
            this.Hide();
        }

        private void Profile_Edit_Load(object sender, EventArgs e)
        {
            RetreiveData();
        }

        private void RetreiveData()
        {
            string commandString = "Select * from tblUsers where  ID = " + e_id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            
            txt_fname.Text = datatable.Rows[currec]["First_Name"].ToString();
            txt_lname.Text = datatable.Rows[currec]["Last_Name"].ToString();
            txt_address.Text = datatable.Rows[currec]["Address"].ToString();
            txt_email.Text = datatable.Rows[currec]["Email"].ToString();
            txt_contact.Text = datatable.Rows[currec]["Contact_Number"].ToString();

            txt_user.Text = datatable.Rows[currec]["Username"].ToString();
            txt_pass.Text = datatable.Rows[currec]["Acct_Password"].ToString();
            txt_pass2.Text = datatable.Rows[currec]["Acct_Password"].ToString();
            
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            if (txt_pass.Text == txt_pass2.Text)
                save();
            else
                MessageBox.Show("New Passwords Does Not Match");
        }

        private void save()
        {
            conn.Open();
            string sql = "Update tblUsers Set First_Name = '" + txt_fname.Text + "', Last_Name = '" + txt_lname.Text 
                + "', Address = '" + txt_address.Text +"', Email = '" +txt_email.Text + "', Contact_Number = '" +txt_contact.Text
                + "', Username = '" + txt_user.Text + "', Acct_Password = '" + txt_pass2.Text + "' Where ID = " + e_id;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Profile Updated!");

            conn.Close();

            this.Hide();
            User_Profile update = new User_Profile(e_id);
            update.Show();
        }
    }
}
