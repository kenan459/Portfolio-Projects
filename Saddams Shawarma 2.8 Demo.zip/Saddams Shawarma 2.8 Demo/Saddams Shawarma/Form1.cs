﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Form1 : Form
    {
        int e_id;
        DataTable datatable;
        int currec;
        int totalrec;
        string authorized;
        string pangalan;
        string position;
        string logtype;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Users.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);


        public Form1(int emp_id)
        {
            InitializeComponent();
            
            e_id = Convert.ToInt32(emp_id);
            //MessageBox.Show(emp_id);
            txt_name.Text = "Welcome, " + e_id;
            //string yolo = 
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadEmployee();
            inlog();
        }

        private void inlog()
        {
           /* DataSet os = new DataSet();
            string commandString = "Select * from tblLog where  ID = " + e_id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(os, "prog");

            datatable = os.Tables["prog"];

            totalrec = datatable.Rows.Count;*/
            


            
        }

        private void loadEmployee()
        {
            DataSet ds = new DataSet();

            //MessageBox.Show("You have chosen " +lname);
            string commandString = "Select * from tblUsers where  ID = " + e_id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            totalrec = datatable.Rows.Count;

            authorized = datatable.Rows[0]["Authorized"].ToString();
            //MessageBox.Show(authorized);
            position = datatable.Rows[0]["Acct_Position"].ToString();
            pangalan = datatable.Rows[0]["First_Name"].ToString() + " " + datatable.Rows[0]["Last_Name"].ToString();
            
            txt_name.Text = "Welcome: " + datatable.Rows[0]["First_Name"].ToString() + " " + datatable.Rows[0]["Last_Name"].ToString();
        }

        private void bttn_today_Click(object sender, EventArgs e)
        {
            Today today = new Today(e_id);
            today.Show();
            this.Hide();
        }

        private void bttn_manage_Click(object sender, EventArgs e)
        {
            if (authorized == "Yes")
            {
                Manage manage = new Manage(e_id);
                manage.Show();
                //this.Hide();
            }
            else
                MessageBox.Show("You Don't Have The Permission to Access this Feature");
        }

        private void bttn_exit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Log out?", "Logout", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            if (result == DialogResult.OK)
            {

                outlog();
                Login login = new Login();
                login.Show();
                this.Close();

                

            } 
            /*Login login = new Login();
            login.Show();
            this.Close();*/
        }


        private void outlog()
        {

            logtype = "Log-Out";
            conn.Open();

            string sql = "Insert Into tblLog (Employee_Name, Log_Time, Log_Date, Employee_Position, Employee_ID, Log_Type) "
            + "Values ('" + pangalan + "','" + txt_time.Text + "','" + txt_date.Text + "','" + position + "','" + e_id + "','" + logtype + "')";

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");



            conn.Close();
        }
        private void bttn_order_Click(object sender, EventArgs e)
        {
            Order order = new Order(e_id);
            order.Show();
            this.Close();
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 49)//num1 Teacher Info
            {
                Order order = new Order(e_id);
                order.Show();
                this.Close();
            }
            else if (e.KeyChar == 50)//2
            {
                Today today = new Today(e_id);
                today.Show();
                this.Hide();
            }
            else if (e.KeyChar == 51)//3
            {
                Manage manage = new Manage(e_id);
                manage.Show();
                this.Hide();
            }
        }

        private void bttn_profile_Click(object sender, EventArgs e)
        {
            User_Profile profile = new User_Profile(e_id);
            profile.Show();
            this.Hide();

        }
    }
}
