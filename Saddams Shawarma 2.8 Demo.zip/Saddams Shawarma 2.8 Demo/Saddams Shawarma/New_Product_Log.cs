﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class New_Product_Log : Form
    {
        int emp_id;

        DataTable datatable;

        int id;
        int totalrec;
        int currec;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public New_Product_Log()
        {
            InitializeComponent();
        }

        private void New_Product_Log_Load(object sender, EventArgs e)
        {
            loadTable();
        }

        private void loadTable()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblNewProdTransaction";
            //string commandString = "select * from tblRecords";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
            
        }


         private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;

            DataGridViewRow r = dataGridView1.Rows[i];

            id = Convert.ToInt32(r.Cells[0].Value);

            currec = 0;

            RetrieveData();
        }

         private void RetrieveData()
         {
             string commandString = "Select * from tblNewProdTransaction where  ID = " + id;
             OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
             DataSet ds = new DataSet();
             dataAdapter.Fill(ds, "prog");

             datatable = ds.Tables["prog"];
             currec = 0;
             totalrec = datatable.Rows.Count;

             txt_id.Text = datatable.Rows[currec]["ID"].ToString();
             txt_name.Text = datatable.Rows[currec]["Product"].ToString();
             txt_price.Text = datatable.Rows[currec]["Price"].ToString();
             txt_cat.Text = datatable.Rows[currec]["Category"].ToString();
             txt_init.Text = datatable.Rows[currec]["Initial_Stock"].ToString();
             txt_supp.Text = datatable.Rows[currec]["Supplier"].ToString();
             txt_date.Text = datatable.Rows[currec]["Date_Added"].ToString();
             txt_time.Text = datatable.Rows[currec]["Time_Added"].ToString();
         }



        private void bttn_added_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_Product_Log added = new New_Product_Log();
            added.Show();
        }

        private void bttn_stock_Click(object sender, EventArgs e)
        {
            Stock_Transaction_History stock = new Stock_Transaction_History();
            stock.Show();
            this.Hide();

        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Food back = new Food();
            back.Show();
            this.Hide();
        }

        private void bttn_edited_Click(object sender, EventArgs e)
        {
            Product_Modify_Log edits = new Product_Modify_Log();
            edits.Show();
            this.Hide();
        }

       
    }
}
