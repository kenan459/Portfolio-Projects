﻿namespace Saddams_Shawarma
{
    partial class Manage_Members
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_NewUser = new System.Windows.Forms.Button();
            this.txt_author = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_activated = new System.Windows.Forms.Label();
            this.txt_id = new System.Windows.Forms.Label();
            this.txt_I = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.cb_pos = new System.Windows.Forms.ComboBox();
            this.bttn_save = new System.Windows.Forms.Button();
            this.bttn_delete = new System.Windows.Forms.Button();
            this.bttn_back = new System.Windows.Forms.Button();
            this.tb_salary = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(343, 117);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(873, 281);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.Btn_NewUser);
            this.groupBox1.Controls.Add(this.txt_author);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txt_activated);
            this.groupBox1.Controls.Add(this.txt_id);
            this.groupBox1.Controls.Add(this.txt_I);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(22, 89);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(283, 372);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Fill up";
            // 
            // Btn_NewUser
            // 
            this.Btn_NewUser.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_NewUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Btn_NewUser.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_NewUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btn_NewUser.Location = new System.Drawing.Point(162, 311);
            this.Btn_NewUser.Name = "Btn_NewUser";
            this.Btn_NewUser.Size = new System.Drawing.Size(91, 33);
            this.Btn_NewUser.TabIndex = 52;
            this.Btn_NewUser.Text = "New User";
            this.Btn_NewUser.UseVisualStyleBackColor = false;
            this.Btn_NewUser.Click += new System.EventHandler(this.Btn_NewUser_Click);
            // 
            // txt_author
            // 
            this.txt_author.AutoSize = true;
            this.txt_author.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_author.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txt_author.Font = new System.Drawing.Font("Tw Cen MT Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_author.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txt_author.Location = new System.Drawing.Point(113, 169);
            this.txt_author.Name = "txt_author";
            this.txt_author.Size = new System.Drawing.Size(31, 22);
            this.txt_author.TabIndex = 41;
            this.txt_author.Text = "N/A";
            this.txt_author.Click += new System.EventHandler(this.txt_author_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(15, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 20);
            this.label5.TabIndex = 40;
            this.label5.Text = "Authorized:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(15, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 20);
            this.label2.TabIndex = 39;
            this.label2.Text = "Salary:";
            // 
            // txt_activated
            // 
            this.txt_activated.AutoSize = true;
            this.txt_activated.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txt_activated.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.txt_activated.Font = new System.Drawing.Font("Tw Cen MT Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_activated.ForeColor = System.Drawing.SystemColors.ControlText;
            this.txt_activated.Location = new System.Drawing.Point(113, 136);
            this.txt_activated.Name = "txt_activated";
            this.txt_activated.Size = new System.Drawing.Size(31, 22);
            this.txt_activated.TabIndex = 38;
            this.txt_activated.Text = "N/A";
            this.txt_activated.Click += new System.EventHandler(this.txt_status_Click);
            // 
            // txt_id
            // 
            this.txt_id.AutoSize = true;
            this.txt_id.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_id.Location = new System.Drawing.Point(113, 30);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(36, 20);
            this.txt_id.TabIndex = 37;
            this.txt_id.Text = "000";
            // 
            // txt_I
            // 
            this.txt_I.AutoSize = true;
            this.txt_I.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_I.Location = new System.Drawing.Point(15, 30);
            this.txt_I.Name = "txt_I";
            this.txt_I.Size = new System.Drawing.Size(92, 20);
            this.txt_I.TabIndex = 36;
            this.txt_I.Text = "Member ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(15, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 35;
            this.label1.Text = "Activated:";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label.Location = new System.Drawing.Point(15, 84);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(68, 20);
            this.label.TabIndex = 33;
            this.label.Text = "Position:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(15, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Name:";
            // 
            // tb_name
            // 
            this.tb_name.Enabled = false;
            this.tb_name.Location = new System.Drawing.Point(106, 148);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(76, 20);
            this.tb_name.TabIndex = 34;
            // 
            // cb_pos
            // 
            this.cb_pos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_pos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_pos.FormattingEnabled = true;
            this.cb_pos.Items.AddRange(new object[] {
            "Cashier",
            "Cook",
            "Manager",
            "Admin"});
            this.cb_pos.Location = new System.Drawing.Point(106, 174);
            this.cb_pos.Name = "cb_pos";
            this.cb_pos.Size = new System.Drawing.Size(121, 21);
            this.cb_pos.TabIndex = 35;
            // 
            // bttn_save
            // 
            this.bttn_save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_save.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_save.Location = new System.Drawing.Point(38, 298);
            this.bttn_save.Name = "bttn_save";
            this.bttn_save.Size = new System.Drawing.Size(91, 33);
            this.bttn_save.TabIndex = 42;
            this.bttn_save.Text = "Save";
            this.bttn_save.UseVisualStyleBackColor = true;
            this.bttn_save.Click += new System.EventHandler(this.bttn_save_Click);
            // 
            // bttn_delete
            // 
            this.bttn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_delete.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_delete.ForeColor = System.Drawing.Color.Maroon;
            this.bttn_delete.Location = new System.Drawing.Point(139, 298);
            this.bttn_delete.Name = "bttn_delete";
            this.bttn_delete.Size = new System.Drawing.Size(91, 33);
            this.bttn_delete.TabIndex = 44;
            this.bttn_delete.Text = "Delete";
            this.bttn_delete.UseVisualStyleBackColor = true;
            this.bttn_delete.Click += new System.EventHandler(this.bttn_delete_Click);
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(29, 400);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 45;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // tb_salary
            // 
            this.tb_salary.Location = new System.Drawing.Point(106, 198);
            this.tb_salary.Name = "tb_salary";
            this.tb_salary.Size = new System.Drawing.Size(76, 20);
            this.tb_salary.TabIndex = 34;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.ForestGreen;
            this.panel1.Controls.Add(this.label12);
            this.panel1.Location = new System.Drawing.Point(13, 53);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1239, 576);
            this.panel1.TabIndex = 51;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(579, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(203, 35);
            this.label12.TabIndex = 46;
            this.label12.Text = "Member List";
            // 
            // Manage_Members
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1264, 682);
            this.Controls.Add(this.bttn_back);
            this.Controls.Add(this.bttn_delete);
            this.Controls.Add(this.bttn_save);
            this.Controls.Add(this.cb_pos);
            this.Controls.Add(this.tb_salary);
            this.Controls.Add(this.tb_name);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Name = "Manage_Members";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage_Members";
            this.Load += new System.EventHandler(this.Manage_Members_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label txt_activated;
        private System.Windows.Forms.Label txt_id;
        private System.Windows.Forms.Label txt_I;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.ComboBox cb_pos;
        private System.Windows.Forms.Button bttn_save;
        private System.Windows.Forms.Button bttn_delete;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_salary;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label txt_author;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Btn_NewUser;
    }
}