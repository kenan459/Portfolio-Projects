﻿namespace Saddams_Shawarma
{
    partial class Food
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bttn_history = new System.Windows.Forms.Button();
            this.bttn_back = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bttn_add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(77, 155);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 19;
            this.label1.Text = "Saddams Shawarma";
            // 
            // bttn_history
            // 
            this.bttn_history.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_history.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_history.Image = global::Saddams_Shawarma.Properties.Resources.today_xxl;
            this.bttn_history.Location = new System.Drawing.Point(228, 198);
            this.bttn_history.Name = "bttn_history";
            this.bttn_history.Size = new System.Drawing.Size(168, 143);
            this.bttn_history.TabIndex = 22;
            this.bttn_history.Text = "Product History Frame";
            this.bttn_history.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_history.UseVisualStyleBackColor = true;
            this.bttn_history.Click += new System.EventHandler(this.bttn_history_Click);
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(38, 356);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(168, 83);
            this.bttn_back.TabIndex = 20;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Saddams_Shawarma.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(144, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 153);
            this.pictureBox1.TabIndex = 18;
            this.pictureBox1.TabStop = false;
            // 
            // bttn_add
            // 
            this.bttn_add.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_add.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_add.Image = global::Saddams_Shawarma.Properties.Resources.add___Copy;
            this.bttn_add.Location = new System.Drawing.Point(38, 198);
            this.bttn_add.Name = "bttn_add";
            this.bttn_add.Size = new System.Drawing.Size(168, 143);
            this.bttn_add.TabIndex = 16;
            this.bttn_add.Text = "Manage Products";
            this.bttn_add.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_add.UseVisualStyleBackColor = true;
            this.bttn_add.Click += new System.EventHandler(this.bttn_add_Click_1);
            // 
            // Food
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(436, 650);
            this.Controls.Add(this.bttn_history);
            this.Controls.Add(this.bttn_back);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bttn_add);
            this.Name = "Food";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Food";
            this.Load += new System.EventHandler(this.Food_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttn_add;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Button bttn_history;
    }
}