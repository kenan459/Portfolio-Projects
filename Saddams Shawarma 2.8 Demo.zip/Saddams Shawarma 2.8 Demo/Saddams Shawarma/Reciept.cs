﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Reciept : Form
    {
        DataTable datatable;

        int totalrec = 0;

        String OrderID;
        String Total;
        String Cash;
        String Change;

        String Food;
        String Quantity;
        String Amount;
        String Date;

        String Item;
        String Print;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Reciept(String orderID, String txt_total, String tb_cash, String txt_change, String txt_date)
        {
            InitializeComponent();

            OrderID = orderID;
            Total = txt_total;
            Cash = tb_cash;
            Change = txt_change;
            Date = txt_date;
            //MessageBox.Show(OrderID);
            Retrieve();
           
        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            //MessageBox.Show("You have chosen " +lname);
            string commandString = "Select * from tblRecords where  Order_ID like '%" + OrderID + "%'";
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            totalrec = datatable.Rows.Count;

            FillControls();

            //string text = "fkdfdsfdflkdkfk@dfsdfjk72388389@kdkfkdfkkl@jkdjkfjd@jjjk@";

            //text = text.Replace("@", "@" + System.Environment.NewLine);
            //txt_item0.Text = text;
        }

        private void FillControls()
        {
            txt_orderID.Text = "Order ID: " + datatable.Rows[0]["Order_ID"].ToString();
            

            for (int i = 0; i < totalrec; i++)
            {
                Food = datatable.Rows[i]["Product"].ToString();
                Quantity = datatable.Rows[i]["Quantity"].ToString();
                Amount = datatable.Rows[i]["Total_Amount"].ToString();
                Item = Food + " Qty: " + Quantity + " Amt Payable: "+ Amount;
                Print = Print + Item + "|"; 
            }
            Print = Print.Replace("|", " " + System.Environment.NewLine);
            txt_item0.Text = Print;
            txt_cash.Text = "Amount Rendered: "+Cash;
            txt_total.Text = "Total Amount: "+Total;
            txt_change.Text = "Change: "+Change;
            txt_date.Text = "Date Today: " + Date;

        }
        private void Reciept_Load(object sender, EventArgs e)
        {

        }


    }
}
