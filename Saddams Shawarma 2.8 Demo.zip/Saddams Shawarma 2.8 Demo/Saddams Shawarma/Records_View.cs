﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Records_View : Form
    {
        int e_id;

        DataTable datatable;
        int totalrec = 0;
        int currec = 0;
        int id = 0;
        String idPass;




        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Records_View(int emp_id)
        {
            InitializeComponent();

            e_id = emp_id;
        }

        private void Records_View_Load(object sender, EventArgs e)
        {
            
            Retrieve();
        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblRecords";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        private void search()
        {
            if (cb_cat.Text == "All")
            {
                DataSet ds = new DataSet();

                //string commandString = "select * from tblRecords where Order_ID like '%" + tb_search.Text + "%' OR Food like '%"+ tb_search.Text + "%'";
                string commandString = "select * from tblRecords where Product like '%" + tb_search.Text + "%'" + " OR Quantity Like '%" + tb_search.Text + "%'" + " OR Order_ID like '%" + tb_search.Text + "%'" + " OR ID like '%" + tb_search.Text + "%'";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

                dataAdapter.Fill(ds, "prog");

                datatable = ds.Tables["prog"];

                //currec = 0;

                totalrec = datatable.Rows.Count;

                dataGridView1.DataSource = datatable;
            }

            else if (cb_cat.Text == "Food")
            {
                DataSet ds = new DataSet();

                //string commandString = "select * from tblRecords where Order_ID like '%" + tb_search.Text + "%' OR Food like '%"+ tb_search.Text + "%'";
                string commandString = "select * from tblRecords where Product like '%" + tb_search.Text + "%'";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

                dataAdapter.Fill(ds, "prog");

                datatable = ds.Tables["prog"];

                //currec = 0;

                totalrec = datatable.Rows.Count;

                dataGridView1.DataSource = datatable;
            }

            else if (cb_cat.Text == "Order ID")
            {
                DataSet ds = new DataSet();
                
                string commandString = "select * from tblRecords where Order_ID like '%" + tb_search.Text + "%'";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

                dataAdapter.Fill(ds, "prog");

                datatable = ds.Tables["prog"];

                //currec = 0;

                totalrec = datatable.Rows.Count;

                dataGridView1.DataSource = datatable;
            }

            else if (cb_cat.Text == "ID")
            {
                DataSet ds = new DataSet();

                string commandString = "select * from tblRecords where ID like '%" + tb_search.Text + "%'";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

                dataAdapter.Fill(ds, "prog");

                datatable = ds.Tables["prog"];

                //currec = 0;

                totalrec = datatable.Rows.Count;

                dataGridView1.DataSource = datatable;

            }

            else if (cb_cat.Text == "Quantity")
            {
                DataSet ds = new DataSet();

                string commandString = "select * from tblRecords where Quantity like '%" + tb_search.Text + "%'";

                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

                dataAdapter.Fill(ds, "prog");

                datatable = ds.Tables["prog"];

                //currec = 0;

                totalrec = datatable.Rows.Count;

                dataGridView1.DataSource = datatable;
            }

            if (totalrec == 0)
            {
                MessageBox.Show("No Results Found");
            }
        }

        private void recordRetrieve()
        {
            string commandString = "Select * from tblRecords where ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            idPass = datatable.Rows[currec]["ID"].ToString();
            txt_id.Text = "ID: " + datatable.Rows[currec]["ID"].ToString();
            txt_orderID.Text = "Order ID: " + datatable.Rows[currec]["Order_ID"].ToString();
            txt_Food.Text = "Food: " +datatable.Rows[currec]["Product"].ToString();
            txt_quantity.Text = "Quantity: " +datatable.Rows[currec]["Quantity"].ToString();
            txt_totalAmount.Text = "Total Amount: " + datatable.Rows[currec]["Total_Amount"].ToString();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Manage manage = new Manage(e_id);
            manage.Show();
            this.Hide();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblRecords where Date_Purchased like '%" + dateTimePicker1.Text + "%'";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;
        }

        private void bttn_search_Click(object sender, EventArgs e)
        {
            search();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;

            if (i >= 0)
            {

                DataGridViewRow r = dataGridView1.Rows[i];

                id = Convert.ToInt32(r.Cells[5].Value);

                currec = 0;

                recordRetrieve();
            }
        }

        private void bttn_edit_Click(object sender, EventArgs e)
        {
            RecordsEdit edit = new RecordsEdit(e_id, idPass, txt_orderID.Text, txt_Food.Text, txt_totalAmount.Text, txt_quantity.Text);
            edit.Show();
            this.Hide();
        }

        private void bttn_delete_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "DELETE FROM tblRecords Where ID = " + idPass;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            //dataAdapter.Fill(ds, "prog");
            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Item Deleted");

            conn.Close();

            this.Hide();
            Records_View refresh = new Records_View(e_id);
            refresh.Show();
        }

    }
}
