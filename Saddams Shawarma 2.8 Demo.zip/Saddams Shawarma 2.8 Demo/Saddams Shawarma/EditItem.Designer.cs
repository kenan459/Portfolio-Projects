﻿namespace Saddams_Shawarma
{
    partial class EditItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_id = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bttn_delete = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bttn_save = new System.Windows.Forms.Button();
            this.bttn_back = new System.Windows.Forms.Button();
            this.label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_cat = new System.Windows.Forms.ComboBox();
            this.tb_name = new System.Windows.Forms.TextBox();
            this.tb_price = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dp_time = new System.Windows.Forms.DateTimePicker();
            this.dp_date = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bttn_edited = new System.Windows.Forms.Button();
            this.bttn_added = new System.Windows.Forms.Button();
            this.bttn_stock = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(350, 85);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(502, 389);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.txt_id);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.bttn_delete);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.bttn_save);
            this.groupBox1.Controls.Add(this.bttn_back);
            this.groupBox1.Controls.Add(this.label);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.tb_cat);
            this.groupBox1.Controls.Add(this.tb_name);
            this.groupBox1.Controls.Add(this.tb_price);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(19, 144);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(283, 372);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Fill up";
            // 
            // txt_id
            // 
            this.txt_id.AutoSize = true;
            this.txt_id.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_id.Location = new System.Drawing.Point(75, 31);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(36, 20);
            this.txt_id.TabIndex = 37;
            this.txt_id.Text = "000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(15, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 36;
            this.label4.Text = "Item ID:";
            // 
            // bttn_delete
            // 
            this.bttn_delete.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_delete.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_delete.ForeColor = System.Drawing.Color.Maroon;
            this.bttn_delete.Location = new System.Drawing.Point(132, 170);
            this.bttn_delete.Name = "bttn_delete";
            this.bttn_delete.Size = new System.Drawing.Size(91, 33);
            this.bttn_delete.TabIndex = 5;
            this.bttn_delete.Text = "Delete";
            this.bttn_delete.UseVisualStyleBackColor = false;
            this.bttn_delete.Click += new System.EventHandler(this.bttn_delete_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(15, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 20);
            this.label1.TabIndex = 35;
            this.label1.Text = "Category:";
            // 
            // bttn_save
            // 
            this.bttn_save.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_save.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_save.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_save.Location = new System.Drawing.Point(20, 170);
            this.bttn_save.Name = "bttn_save";
            this.bttn_save.Size = new System.Drawing.Size(91, 33);
            this.bttn_save.TabIndex = 4;
            this.bttn_save.Text = "Save";
            this.bttn_save.UseVisualStyleBackColor = false;
            this.bttn_save.Click += new System.EventHandler(this.bttn_save_Click);
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(19, 290);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 6;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label.Location = new System.Drawing.Point(15, 86);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(51, 20);
            this.label.TabIndex = 33;
            this.label.Text = "Price:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(15, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 20);
            this.label3.TabIndex = 30;
            this.label3.Text = "Name:";
            // 
            // tb_cat
            // 
            this.tb_cat.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.tb_cat.FormattingEnabled = true;
            this.tb_cat.Items.AddRange(new object[] {
            "Food",
            "Drinks"});
            this.tb_cat.Location = new System.Drawing.Point(92, 118);
            this.tb_cat.Name = "tb_cat";
            this.tb_cat.Size = new System.Drawing.Size(91, 25);
            this.tb_cat.TabIndex = 3;
            // 
            // tb_name
            // 
            this.tb_name.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.tb_name.Location = new System.Drawing.Point(70, 57);
            this.tb_name.Name = "tb_name";
            this.tb_name.Size = new System.Drawing.Size(113, 24);
            this.tb_name.TabIndex = 1;
            // 
            // tb_price
            // 
            this.tb_price.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.tb_price.Location = new System.Drawing.Point(70, 86);
            this.tb_price.Name = "tb_price";
            this.tb_price.Size = new System.Drawing.Size(113, 24);
            this.tb_price.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(477, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(202, 35);
            this.label2.TabIndex = 33;
            this.label2.Text = "Edit Product";
            // 
            // dp_time
            // 
            this.dp_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dp_time.Location = new System.Drawing.Point(1053, 10);
            this.dp_time.Name = "dp_time";
            this.dp_time.Size = new System.Drawing.Size(118, 20);
            this.dp_time.TabIndex = 44;
            // 
            // dp_date
            // 
            this.dp_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dp_date.Location = new System.Drawing.Point(1177, 10);
            this.dp_date.Name = "dp_date";
            this.dp_date.Size = new System.Drawing.Size(85, 20);
            this.dp_date.TabIndex = 45;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.ForestGreen;
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(25, 97);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1214, 576);
            this.panel1.TabIndex = 46;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox2.Controls.Add(this.bttn_edited);
            this.groupBox2.Controls.Add(this.bttn_added);
            this.groupBox2.Controls.Add(this.bttn_stock);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Location = new System.Drawing.Point(19, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(295, 126);
            this.groupBox2.TabIndex = 60;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Options";
            // 
            // bttn_edited
            // 
            this.bttn_edited.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_edited.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_edited.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_edited.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_edited.Location = new System.Drawing.Point(101, 34);
            this.bttn_edited.Name = "bttn_edited";
            this.bttn_edited.Size = new System.Drawing.Size(91, 81);
            this.bttn_edited.TabIndex = 72;
            this.bttn_edited.Text = "Edited";
            this.bttn_edited.UseVisualStyleBackColor = false;
            this.bttn_edited.Click += new System.EventHandler(this.bttn_edited_Click);
            // 
            // bttn_added
            // 
            this.bttn_added.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_added.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_added.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_added.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_added.Location = new System.Drawing.Point(6, 33);
            this.bttn_added.Name = "bttn_added";
            this.bttn_added.Size = new System.Drawing.Size(91, 81);
            this.bttn_added.TabIndex = 73;
            this.bttn_added.Text = "Create";
            this.bttn_added.UseVisualStyleBackColor = false;
            this.bttn_added.Click += new System.EventHandler(this.bttn_added_Click);
            // 
            // bttn_stock
            // 
            this.bttn_stock.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_stock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_stock.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_stock.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_stock.Location = new System.Drawing.Point(196, 34);
            this.bttn_stock.Name = "bttn_stock";
            this.bttn_stock.Size = new System.Drawing.Size(91, 81);
            this.bttn_stock.TabIndex = 71;
            this.bttn_stock.Text = "Add Stocks";
            this.bttn_stock.UseVisualStyleBackColor = false;
            this.bttn_stock.Click += new System.EventHandler(this.bttn_stock_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.ForestGreen;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(445, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(408, 68);
            this.panel2.TabIndex = 71;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Gill Sans MT", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(55, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(304, 48);
            this.label5.TabIndex = 59;
            this.label5.Text = "Manage Products";
            // 
            // EditItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1274, 696);
            this.ControlBox = false;
            this.Controls.Add(this.dp_time);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dp_date);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EditItem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Product";
            this.Load += new System.EventHandler(this.EditItem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox tb_cat;
        private System.Windows.Forms.TextBox tb_price;
        private System.Windows.Forms.TextBox tb_name;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Button bttn_save;
        private System.Windows.Forms.Button bttn_delete;
        private System.Windows.Forms.Label txt_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dp_time;
        private System.Windows.Forms.DateTimePicker dp_date;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button bttn_edited;
        private System.Windows.Forms.Button bttn_added;
        private System.Windows.Forms.Button bttn_stock;
    }
}