﻿namespace Saddams_Shawarma
{
    partial class Product_Modify_Log
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.bttn_edited = new System.Windows.Forms.Button();
            this.bttn_stock = new System.Windows.Forms.Button();
            this.txt_id = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.bttn_added = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txt_pname = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bttn_back = new System.Windows.Forms.Button();
            this.txt_event = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_time = new System.Windows.Forms.Label();
            this.txt_date = new System.Windows.Forms.Label();
            this.txt_ncat = new System.Windows.Forms.Label();
            this.txt_pcat = new System.Windows.Forms.Label();
            this.txt_nprice = new System.Windows.Forms.Label();
            this.txt_pprice = new System.Windows.Forms.Label();
            this.txt_nname = new System.Windows.Forms.Label();
            this.txt_nn = new System.Windows.Forms.Label();
            this.txt_np = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txt_nc = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.ForestGreen;
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(445, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(408, 68);
            this.panel2.TabIndex = 69;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Gill Sans MT", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(7, 8);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(403, 48);
            this.label7.TabIndex = 59;
            this.label7.Text = "Product History Frame";
            // 
            // bttn_edited
            // 
            this.bttn_edited.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_edited.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_edited.Location = new System.Drawing.Point(136, 131);
            this.bttn_edited.Name = "bttn_edited";
            this.bttn_edited.Size = new System.Drawing.Size(91, 81);
            this.bttn_edited.TabIndex = 67;
            this.bttn_edited.Text = "Edits";
            this.bttn_edited.UseVisualStyleBackColor = true;
            this.bttn_edited.Click += new System.EventHandler(this.bttn_edited_Click);
            // 
            // bttn_stock
            // 
            this.bttn_stock.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_stock.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_stock.Location = new System.Drawing.Point(231, 131);
            this.bttn_stock.Name = "bttn_stock";
            this.bttn_stock.Size = new System.Drawing.Size(91, 81);
            this.bttn_stock.TabIndex = 66;
            this.bttn_stock.Text = "Stocks";
            this.bttn_stock.UseVisualStyleBackColor = true;
            this.bttn_stock.Click += new System.EventHandler(this.bttn_stock_Click);
            // 
            // txt_id
            // 
            this.txt_id.AutoSize = true;
            this.txt_id.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id.Location = new System.Drawing.Point(114, 74);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(32, 18);
            this.txt_id.TabIndex = 37;
            this.txt_id.Text = "000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(15, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 18);
            this.label4.TabIndex = 36;
            this.label4.Text = "Modification ID:";
            // 
            // bttn_added
            // 
            this.bttn_added.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_added.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_added.Location = new System.Drawing.Point(41, 130);
            this.bttn_added.Name = "bttn_added";
            this.bttn_added.Size = new System.Drawing.Size(91, 81);
            this.bttn_added.TabIndex = 68;
            this.bttn_added.Text = "Added";
            this.bttn_added.UseVisualStyleBackColor = true;
            this.bttn_added.Click += new System.EventHandler(this.bttn_added_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox2.Location = new System.Drawing.Point(8, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(295, 126);
            this.groupBox2.TabIndex = 58;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Product Logs";
            // 
            // txt_pname
            // 
            this.txt_pname.AutoSize = true;
            this.txt_pname.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pname.Location = new System.Drawing.Point(114, 92);
            this.txt_pname.Name = "txt_pname";
            this.txt_pname.Size = new System.Drawing.Size(30, 18);
            this.txt_pname.TabIndex = 30;
            this.txt_pname.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(15, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 18);
            this.label3.TabIndex = 30;
            this.label3.Text = "Previous Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(527, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(357, 35);
            this.label2.TabIndex = 47;
            this.label2.Text = "Stock Transaction Log";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.bttn_back);
            this.groupBox1.Controls.Add(this.txt_id);
            this.groupBox1.Controls.Add(this.txt_event);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txt_time);
            this.groupBox1.Controls.Add(this.txt_date);
            this.groupBox1.Controls.Add(this.txt_ncat);
            this.groupBox1.Controls.Add(this.txt_pcat);
            this.groupBox1.Controls.Add(this.txt_nprice);
            this.groupBox1.Controls.Add(this.txt_pprice);
            this.groupBox1.Controls.Add(this.txt_nname);
            this.groupBox1.Controls.Add(this.txt_pname);
            this.groupBox1.Controls.Add(this.txt_nn);
            this.groupBox1.Controls.Add(this.txt_np);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txt_nc);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(8, 132);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(307, 390);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Product Info";
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(18, 266);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 52;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // txt_event
            // 
            this.txt_event.AutoSize = true;
            this.txt_event.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_event.Location = new System.Drawing.Point(130, 40);
            this.txt_event.Name = "txt_event";
            this.txt_event.Size = new System.Drawing.Size(42, 24);
            this.txt_event.TabIndex = 36;
            this.txt_event.Text = "N/A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(119, 24);
            this.label6.TabIndex = 36;
            this.label6.Text = "Event Type:";
            // 
            // txt_time
            // 
            this.txt_time.AutoSize = true;
            this.txt_time.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_time.Location = new System.Drawing.Point(55, 218);
            this.txt_time.Name = "txt_time";
            this.txt_time.Size = new System.Drawing.Size(30, 18);
            this.txt_time.TabIndex = 30;
            this.txt_time.Text = "N/A";
            // 
            // txt_date
            // 
            this.txt_date.AutoSize = true;
            this.txt_date.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_date.Location = new System.Drawing.Point(49, 200);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(30, 18);
            this.txt_date.TabIndex = 30;
            this.txt_date.Text = "N/A";
            // 
            // txt_ncat
            // 
            this.txt_ncat.AutoSize = true;
            this.txt_ncat.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ncat.Location = new System.Drawing.Point(109, 182);
            this.txt_ncat.Name = "txt_ncat";
            this.txt_ncat.Size = new System.Drawing.Size(30, 18);
            this.txt_ncat.TabIndex = 30;
            this.txt_ncat.Text = "N/A";
            // 
            // txt_pcat
            // 
            this.txt_pcat.AutoSize = true;
            this.txt_pcat.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pcat.Location = new System.Drawing.Point(133, 164);
            this.txt_pcat.Name = "txt_pcat";
            this.txt_pcat.Size = new System.Drawing.Size(30, 18);
            this.txt_pcat.TabIndex = 30;
            this.txt_pcat.Text = "N/A";
            // 
            // txt_nprice
            // 
            this.txt_nprice.AutoSize = true;
            this.txt_nprice.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nprice.Location = new System.Drawing.Point(87, 146);
            this.txt_nprice.Name = "txt_nprice";
            this.txt_nprice.Size = new System.Drawing.Size(30, 18);
            this.txt_nprice.TabIndex = 30;
            this.txt_nprice.Text = "N/A";
            // 
            // txt_pprice
            // 
            this.txt_pprice.AutoSize = true;
            this.txt_pprice.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pprice.Location = new System.Drawing.Point(114, 128);
            this.txt_pprice.Name = "txt_pprice";
            this.txt_pprice.Size = new System.Drawing.Size(30, 18);
            this.txt_pprice.TabIndex = 30;
            this.txt_pprice.Text = "N/A";
            // 
            // txt_nname
            // 
            this.txt_nname.AutoSize = true;
            this.txt_nname.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nname.Location = new System.Drawing.Point(89, 110);
            this.txt_nname.Name = "txt_nname";
            this.txt_nname.Size = new System.Drawing.Size(30, 18);
            this.txt_nname.TabIndex = 30;
            this.txt_nname.Text = "N/A";
            // 
            // txt_nn
            // 
            this.txt_nn.AutoSize = true;
            this.txt_nn.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nn.Location = new System.Drawing.Point(16, 109);
            this.txt_nn.Name = "txt_nn";
            this.txt_nn.Size = new System.Drawing.Size(77, 18);
            this.txt_nn.TabIndex = 30;
            this.txt_nn.Text = "New Name:";
            // 
            // txt_np
            // 
            this.txt_np.AutoSize = true;
            this.txt_np.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_np.Location = new System.Drawing.Point(15, 146);
            this.txt_np.Name = "txt_np";
            this.txt_np.Size = new System.Drawing.Size(75, 18);
            this.txt_np.TabIndex = 30;
            this.txt_np.Text = "New Price:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 218);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 18);
            this.label13.TabIndex = 30;
            this.label13.Text = "Time:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 200);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(40, 18);
            this.label12.TabIndex = 30;
            this.label12.Text = "Date:";
            // 
            // txt_nc
            // 
            this.txt_nc.AutoSize = true;
            this.txt_nc.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_nc.Location = new System.Drawing.Point(15, 182);
            this.txt_nc.Name = "txt_nc";
            this.txt_nc.Size = new System.Drawing.Size(97, 18);
            this.txt_nc.TabIndex = 30;
            this.txt_nc.Text = "New Category:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 18);
            this.label10.TabIndex = 30;
            this.label10.Text = "Previous Category:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(15, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(102, 18);
            this.label8.TabIndex = 30;
            this.label8.Text = "Previous Price:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.ForestGreen;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(25, 97);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1214, 576);
            this.panel1.TabIndex = 65;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(329, 132);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(861, 421);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // Product_Modify_Log
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1274, 696);
            this.ControlBox = false;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.bttn_edited);
            this.Controls.Add(this.bttn_stock);
            this.Controls.Add(this.bttn_added);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Product_Modify_Log";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product_Modify_Log";
            this.Load += new System.EventHandler(this.Product_Modify_Log_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button bttn_edited;
        private System.Windows.Forms.Button bttn_stock;
        private System.Windows.Forms.Label txt_id;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bttn_added;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label txt_pname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label txt_nname;
        private System.Windows.Forms.Label txt_nn;
        private System.Windows.Forms.Label txt_event;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label txt_np;
        private System.Windows.Forms.Label txt_nc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label txt_time;
        private System.Windows.Forms.Label txt_date;
        private System.Windows.Forms.Label txt_ncat;
        private System.Windows.Forms.Label txt_pcat;
        private System.Windows.Forms.Label txt_nprice;
        private System.Windows.Forms.Label txt_pprice;
    }
}