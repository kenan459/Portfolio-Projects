﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Today : Form
    {
        DataTable datatable;
        int totalrec = 0;
        int currec = 0;
        int emp_id;
        
       

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        public Today(int e_id)
        {
            InitializeComponent();
            emp_id = e_id;
        }

        private void Today_Load(object sender, EventArgs e)
        {
            txt_date.Text = dateTimePicker1.Text;
            Retrieve();
            
        }

        private void Retrieve()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblRecords where Date_Purchased like '%" + dateTimePicker1.Text + "%'";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;

            dateTimePicker1.Visible = false;
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Form1 back = new Form1(emp_id);
            back.Show();
            this.Hide();
        }

        private void bttn_print_Click(object sender, EventArgs e)
        {
            Daily_Report report = new Daily_Report();
            report.Show();
            
        }
    }
}
