﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Saddams_Shawarma
{
    public partial class Add_Stock : Form
    {

        int emp_id;

        static string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Records.accdb";
        OleDbConnection conn = new OleDbConnection(connectionString);

        DataTable datatable;

        int currec = 0;
        int totalrec = 0;

        int amt_get;
        int amt_new;

        int id = 0;

        public Add_Stock()
        {
            InitializeComponent();
        }

        private void Add_Stock_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblMenu ";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            dataGridView1.DataSource = datatable;

            suppliersLoad();
        }

        private void suppliersLoad()
        {
            DataSet ds = new DataSet();

            string commandString = "select * from tblSuppliers ";

            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);

            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];

            currec = 0;

            totalrec = datatable.Rows.Count;

            for (int x = 0; x < totalrec; x++)
            {
                cb_supplier.Items.Add(datatable.Rows[x]["Company_Name"].ToString());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            if (i >= 0)
            {
                DataGridViewRow r = dataGridView1.Rows[i];

                id = Convert.ToInt32(r.Cells[0].Value);

                currec = 0;

                RetrieveData();
            }
        }

        private void RetrieveData()
        {
            string commandString = "Select * from tblMenu where  ID = " + id;
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(commandString, conn);
            DataSet ds = new DataSet();
            dataAdapter.Fill(ds, "prog");

            datatable = ds.Tables["prog"];
            currec = 0;
            totalrec = datatable.Rows.Count;

            txt_id.Text = datatable.Rows[currec]["ID"].ToString();
            txt_name.Text = datatable.Rows[currec]["Product_Name"].ToString();
            txt_price.Text = datatable.Rows[currec]["Price"].ToString();
            txt_cat.Text = datatable.Rows[currec]["Category"].ToString();
            txt_instock.Text = datatable.Rows[currec]["In_Stock"].ToString();
            //tb_amount.Text = datatable.Rows[currec]["In_Stock"].ToString();

            bttn_save.Enabled = true;
        }

        private void bttn_save_Click(object sender, EventArgs e)
        {
            if (tb_amount.Text != "")
            {
                if (Convert.ToInt32(tb_amount.Text)<1)
                    MessageBox.Show("Invalid Input!");
                else
                {
                    DialogResult result = MessageBox.Show("Add: " + tb_amount.Text + " stocks to " + txt_name.Text + "?", "Add Stock", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                    if (result == DialogResult.OK)
                    {
                        amt_get = Convert.ToInt32(txt_instock.Text);
                        amt_new = amt_get + Convert.ToInt32(tb_amount.Text);

                        Update();
                        addTransaction();

                    } 

                }
            }
            else
                MessageBox.Show("Input Box is Empty!");

            
        }

        private void Update()
        {
            conn.Open();

            string sql = "Update tblMenu set In_Stock = " + amt_new + " where ID = " + txt_id.Text;

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Item Updated");

            conn.Close();

            this.Hide();
            Add_Stock refresh = new Add_Stock();
            refresh.Show();
        }

        private void addTransaction()
        {
            conn.Open();
                                      
            string sql = "Insert Into tblStockTransaction (Product, Price, Category, Quantity, Supplier, Transaction_Date, Transaction_Time) "
            + "Values ('" + txt_name.Text + "','" + txt_price.Text + "','" + txt_cat.Text + "','" + tb_amount.Text
            + "','" + cb_supplier.Text + "','" + dp_date.Text + "','" + dp_time.Text + "')";

            OleDbDataAdapter updateAdapter = new OleDbDataAdapter(sql, conn);
            DataSet ds = new DataSet();

            updateAdapter.Fill(ds, "prog");

            MessageBox.Show("Item Updated");

            conn.Close();
        }

        private void bttn_back_Click(object sender, EventArgs e)
        {
            Food back = new Food();
            back.Show();
            this.Hide();
        }

        private void bttn_added_Click(object sender, EventArgs e)
        {
            AddItem add = new AddItem();
            add.Show();
            this.Hide();
        }

        private void bttn_edited_Click(object sender, EventArgs e)
        {
            EditItem edit = new EditItem();
            edit.Show();
            this.Hide();
        }

        private void bttn_stock_Click(object sender, EventArgs e)
        {
            Add_Stock stock = new Add_Stock();
            stock.Show();
            this.Hide();
        }
    }
}
