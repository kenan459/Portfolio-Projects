﻿namespace Saddams_Shawarma
{
    partial class Account_Creation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bttn_submit = new System.Windows.Forms.Button();
            this.cb_pos = new System.Windows.Forms.ComboBox();
            this.tb_lname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_fname = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.Label();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.acctCreation_txt = new System.Windows.Forms.Label();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bttn_back = new System.Windows.Forms.Button();
            this.activated_txt = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_address = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tb_contact = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dp_time = new System.Windows.Forms.DateTimePicker();
            this.dp_date = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.ForestGreen;
            this.groupBox1.Controls.Add(this.acctCreation_txt);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(12, 67);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(572, 434);
            this.groupBox1.TabIndex = 33;
            this.groupBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(10, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 39;
            this.label4.Text = "Position:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(247, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 20);
            this.label5.TabIndex = 39;
            this.label5.Text = "Last Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(247, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 20);
            this.label2.TabIndex = 39;
            this.label2.Text = "First Name:";
            // 
            // bttn_submit
            // 
            this.bttn_submit.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_submit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_submit.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_submit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_submit.Location = new System.Drawing.Point(108, 162);
            this.bttn_submit.Name = "bttn_submit";
            this.bttn_submit.Size = new System.Drawing.Size(141, 54);
            this.bttn_submit.TabIndex = 9;
            this.bttn_submit.Text = "Submit";
            this.bttn_submit.UseVisualStyleBackColor = false;
            this.bttn_submit.Click += new System.EventHandler(this.bttn_submit_Click);
            // 
            // cb_pos
            // 
            this.cb_pos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_pos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_pos.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_pos.FormattingEnabled = true;
            this.cb_pos.Items.AddRange(new object[] {
            "Cashier",
            "Cook",
            "Manager",
            "Admin"});
            this.cb_pos.Location = new System.Drawing.Point(108, 114);
            this.cb_pos.Name = "cb_pos";
            this.cb_pos.Size = new System.Drawing.Size(131, 25);
            this.cb_pos.TabIndex = 4;
            // 
            // tb_lname
            // 
            this.tb_lname.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_lname.Location = new System.Drawing.Point(346, 56);
            this.tb_lname.Name = "tb_lname";
            this.tb_lname.Size = new System.Drawing.Size(132, 24);
            this.tb_lname.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(10, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "Username:";
            // 
            // tb_fname
            // 
            this.tb_fname.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_fname.Location = new System.Drawing.Point(346, 25);
            this.tb_fname.Name = "tb_fname";
            this.tb_fname.Size = new System.Drawing.Size(132, 24);
            this.tb_fname.TabIndex = 5;
            // 
            // txt_price
            // 
            this.txt_price.AutoSize = true;
            this.txt_price.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_price.Location = new System.Drawing.Point(10, 52);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(79, 20);
            this.txt_price.TabIndex = 38;
            this.txt_price.Text = "Password:";
            // 
            // tb_pass
            // 
            this.tb_pass.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_pass.Location = new System.Drawing.Point(108, 54);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.PasswordChar = '*';
            this.tb_pass.Size = new System.Drawing.Size(133, 24);
            this.tb_pass.TabIndex = 2;
            // 
            // acctCreation_txt
            // 
            this.acctCreation_txt.AutoSize = true;
            this.acctCreation_txt.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.acctCreation_txt.Location = new System.Drawing.Point(179, 24);
            this.acctCreation_txt.Name = "acctCreation_txt";
            this.acctCreation_txt.Size = new System.Drawing.Size(166, 24);
            this.acctCreation_txt.TabIndex = 30;
            this.acctCreation_txt.Text = "Account Creation";
            // 
            // tb_user
            // 
            this.tb_user.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_user.Location = new System.Drawing.Point(107, 23);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(134, 24);
            this.tb_user.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(129, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 34;
            this.label1.Text = "Saddams Shawarma";
            // 
            // bttn_back
            // 
            this.bttn_back.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_back.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_back.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bttn_back.Image = global::Saddams_Shawarma.Properties.Resources.back;
            this.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bttn_back.Location = new System.Drawing.Point(14, 280);
            this.bttn_back.Name = "bttn_back";
            this.bttn_back.Size = new System.Drawing.Size(118, 54);
            this.bttn_back.TabIndex = 10;
            this.bttn_back.Text = "Back";
            this.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bttn_back.UseVisualStyleBackColor = false;
            this.bttn_back.Click += new System.EventHandler(this.bttn_back_Click);
            // 
            // activated_txt
            // 
            this.activated_txt.AutoSize = true;
            this.activated_txt.Location = new System.Drawing.Point(372, 49);
            this.activated_txt.Name = "activated_txt";
            this.activated_txt.Size = new System.Drawing.Size(21, 13);
            this.activated_txt.TabIndex = 40;
            this.activated_txt.Text = "No";
            this.activated_txt.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkGreen;
            this.panel1.Controls.Add(this.bttn_back);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.bttn_submit);
            this.panel1.Controls.Add(this.tb_email);
            this.panel1.Controls.Add(this.tb_contact);
            this.panel1.Controls.Add(this.tb_address);
            this.panel1.Controls.Add(this.cb_pos);
            this.panel1.Controls.Add(this.tb_lname);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tb_fname);
            this.panel1.Controls.Add(this.txt_price);
            this.panel1.Controls.Add(this.tb_pass);
            this.panel1.Controls.Add(this.tb_user);
            this.panel1.Location = new System.Drawing.Point(17, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(533, 365);
            this.panel1.TabIndex = 44;
            // 
            // tb_address
            // 
            this.tb_address.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_address.Location = new System.Drawing.Point(346, 87);
            this.tb_address.Name = "tb_address";
            this.tb_address.Size = new System.Drawing.Size(132, 24);
            this.tb_address.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(247, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 20);
            this.label6.TabIndex = 39;
            this.label6.Text = "Address:";
            // 
            // tb_contact
            // 
            this.tb_contact.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_contact.Location = new System.Drawing.Point(346, 117);
            this.tb_contact.Name = "tb_contact";
            this.tb_contact.Size = new System.Drawing.Size(132, 24);
            this.tb_contact.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(245, 117);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 20);
            this.label7.TabIndex = 39;
            this.label7.Text = "Contact #:";
            // 
            // tb_email
            // 
            this.tb_email.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_email.Location = new System.Drawing.Point(108, 84);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(132, 24);
            this.tb_email.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(10, 84);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 20);
            this.label8.TabIndex = 39;
            this.label8.Text = "Email:";
            // 
            // dp_time
            // 
            this.dp_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dp_time.Location = new System.Drawing.Point(448, 12);
            this.dp_time.Name = "dp_time";
            this.dp_time.Size = new System.Drawing.Size(89, 20);
            this.dp_time.TabIndex = 41;
            // 
            // dp_date
            // 
            this.dp_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dp_date.Location = new System.Drawing.Point(448, 38);
            this.dp_date.Name = "dp_date";
            this.dp_date.Size = new System.Drawing.Size(89, 20);
            this.dp_date.TabIndex = 42;
            // 
            // Account_Creation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(597, 514);
            this.ControlBox = false;
            this.Controls.Add(this.dp_date);
            this.Controls.Add(this.dp_time);
            this.Controls.Add(this.activated_txt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Account_Creation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Account Creation ";
            this.Load += new System.EventHandler(this.Account_Creation_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label acctCreation_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label txt_price;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_fname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_pos;
        private System.Windows.Forms.Button bttn_submit;
        private System.Windows.Forms.Button bttn_back;
        private System.Windows.Forms.Label activated_txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_lname;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tb_address;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_contact;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.DateTimePicker dp_time;
        private System.Windows.Forms.DateTimePicker dp_date;
    }
}