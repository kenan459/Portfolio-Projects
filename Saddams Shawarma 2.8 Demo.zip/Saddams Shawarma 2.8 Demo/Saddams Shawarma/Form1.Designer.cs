﻿namespace Saddams_Shawarma
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bttn_manage = new System.Windows.Forms.Button();
            this.bttn_exit = new System.Windows.Forms.Button();
            this.bttn_today = new System.Windows.Forms.Button();
            this.bttn_order = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt_name = new System.Windows.Forms.Label();
            this.bttn_profile = new System.Windows.Forms.Button();
            this.txt_time = new System.Windows.Forms.DateTimePicker();
            this.txt_date = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkGreen;
            this.label1.Location = new System.Drawing.Point(202, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 40);
            this.label1.TabIndex = 10;
            this.label1.Text = "Saddams Shawarma";
            // 
            // bttn_manage
            // 
            this.bttn_manage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_manage.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_manage.Image = global::Saddams_Shawarma.Properties.Resources.manage___Copy;
            this.bttn_manage.Location = new System.Drawing.Point(166, 382);
            this.bttn_manage.Name = "bttn_manage";
            this.bttn_manage.Size = new System.Drawing.Size(168, 143);
            this.bttn_manage.TabIndex = 11;
            this.bttn_manage.Text = "Manage";
            this.bttn_manage.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_manage.UseVisualStyleBackColor = true;
            this.bttn_manage.Click += new System.EventHandler(this.bttn_manage_Click);
            // 
            // bttn_exit
            // 
            this.bttn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_exit.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_exit.Image = global::Saddams_Shawarma.Properties.Resources.exit_button_md;
            this.bttn_exit.Location = new System.Drawing.Point(357, 382);
            this.bttn_exit.Name = "bttn_exit";
            this.bttn_exit.Size = new System.Drawing.Size(168, 143);
            this.bttn_exit.TabIndex = 9;
            this.bttn_exit.Text = "Log out";
            this.bttn_exit.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_exit.UseVisualStyleBackColor = true;
            this.bttn_exit.Click += new System.EventHandler(this.bttn_exit_Click);
            // 
            // bttn_today
            // 
            this.bttn_today.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_today.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_today.Image = global::Saddams_Shawarma.Properties.Resources.today_xxl;
            this.bttn_today.Location = new System.Drawing.Point(357, 220);
            this.bttn_today.Name = "bttn_today";
            this.bttn_today.Size = new System.Drawing.Size(168, 143);
            this.bttn_today.TabIndex = 8;
            this.bttn_today.Text = "Today\'s Record";
            this.bttn_today.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_today.UseVisualStyleBackColor = true;
            this.bttn_today.Click += new System.EventHandler(this.bttn_today_Click);
            // 
            // bttn_order
            // 
            this.bttn_order.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bttn_order.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_order.Image = global::Saddams_Shawarma.Properties.Resources.Order;
            this.bttn_order.Location = new System.Drawing.Point(166, 220);
            this.bttn_order.Name = "bttn_order";
            this.bttn_order.Size = new System.Drawing.Size(168, 143);
            this.bttn_order.TabIndex = 7;
            this.bttn_order.Text = "New Order";
            this.bttn_order.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.bttn_order.UseVisualStyleBackColor = true;
            this.bttn_order.Click += new System.EventHandler(this.bttn_order_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.pictureBox1.Image = global::Saddams_Shawarma.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(269, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(154, 153);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // txt_name
            // 
            this.txt_name.AutoSize = true;
            this.txt_name.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.txt_name.Location = new System.Drawing.Point(12, 44);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(79, 20);
            this.txt_name.TabIndex = 44;
            this.txt_name.Text = "Welcome,";
            // 
            // bttn_profile
            // 
            this.bttn_profile.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bttn_profile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bttn_profile.Font = new System.Drawing.Font("Tahoma", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bttn_profile.Location = new System.Drawing.Point(12, 20);
            this.bttn_profile.Name = "bttn_profile";
            this.bttn_profile.Size = new System.Drawing.Size(66, 21);
            this.bttn_profile.TabIndex = 45;
            this.bttn_profile.Text = "User Profile";
            this.bttn_profile.UseVisualStyleBackColor = false;
            this.bttn_profile.Click += new System.EventHandler(this.bttn_profile_Click);
            // 
            // txt_time
            // 
            this.txt_time.Enabled = false;
            this.txt_time.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.txt_time.Location = new System.Drawing.Point(451, 31);
            this.txt_time.Name = "txt_time";
            this.txt_time.Size = new System.Drawing.Size(100, 20);
            this.txt_time.TabIndex = 46;
            // 
            // txt_date
            // 
            this.txt_date.Enabled = false;
            this.txt_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_date.Location = new System.Drawing.Point(557, 31);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(95, 20);
            this.txt_date.TabIndex = 47;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(691, 556);
            this.ControlBox = false;
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.txt_time);
            this.Controls.Add(this.bttn_profile);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.bttn_manage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bttn_exit);
            this.Controls.Add(this.bttn_today);
            this.Controls.Add(this.bttn_order);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bttn_manage;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bttn_exit;
        private System.Windows.Forms.Button bttn_today;
        private System.Windows.Forms.Button bttn_order;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label txt_name;
        private System.Windows.Forms.Button bttn_profile;
        private System.Windows.Forms.DateTimePicker txt_time;
        private System.Windows.Forms.DateTimePicker txt_date;

    }
}

