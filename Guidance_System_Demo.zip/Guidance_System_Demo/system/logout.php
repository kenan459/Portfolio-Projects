<?php
	require '../config/config.php';
	unset($_SESSION['login']);
	session_destroy();
	$message = "Logged out Successfully";
        echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script type='text/javascript'>window.location.href ='../index.php'; </script>";

?>