<?php
  $module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
  $sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';
    $id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';
?>

<style>


#icontainer {
    font-family: Arial, Helvetica, sans-serif;
    padding: 5%;
    margin-top: -2%;
    margin-left: 1%;
    margin-bottom: -22%;
    text-align: left;
    width: 85%;
    height: 0%;
    color: white;
}

#icontainer p.titlePage{
    margin-left: 3%;
    margin-bottom: 2%;
    font-size: 30px;
    font-weight: bold;
    

}

#icontainer p.subInfo{
    margin-top: 60px;
    font-size: 20px;
    font-weight: bold;
    margin-top: 0;
    margin-bottom: 15px;
  }
    
 #field1 form {
    left: 30%;
    float: left;
    
}

#field1 label {
    margin-left: 15px;
}

#field1 input {
    
    height: 40px;
    width: 300px;
    padding: 10px 20px;
    padding-left: 5px;
    margin: 5px 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
    font-size: 20px;
}

.buttonSubmit {
    color: white;
    background-color: #333;
    border: none;
    font-size: 1px;

    cursor: pointer;

}

#field1 input[type="submit" ] {
    font-size: 36px;
    height: 10%;
    width: 105%;
    padding: 29px 0px;
    padding-left: 0px;
    padding-bottom: 35px;
    margin: 10px 0px;
    margin-left: 15px;
    text-align: center;
    box-sizing: border-box;
    display: block;
}


#field1 select{
    height: 40px;
    color: black;
    padding: 3px 135px;
    padding-left: 5px;
    margin-top: 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}
    

.cid-r1y0ay8sxw img {
    width: 25%;
    margin-left: 5%;
}

    .description{
        margin-left: 4%;
        padding: 3%;
    }


</style>

<body>

        <div id="icontainer">
        
        <?php $checkStudent = new Students();
        $check = $checkStudent->getnumViolations($id);
        ?>
        
		<p class="titlePage">Add New Violation to Student ID: <?php echo $id ?></p>
		

		<div id="field1">
           
		<form method="POST" action="../Violations/process.php?action=violationNew&id=<?php echo $id ?>">
			<p class="subInfo">Violation Details</p>
            
            <input type="hidden" name="id" value="<?php echo $id ?> ">
			<label>Violation Title: </label>
			<input type="text" name="cName" placeholder="Enter Violation Title" required>

			<label for="lname">Case Description: </label>
			<br>
            <textarea class="description" type="text" name="cDescrip" rows="6" cols="30" placeholder="Enter Case Description" required></textarea>
			
            <br>
            <br>
			<label for="cnumber">Counselor Remarks</label>
			<input type="text" name="cRemarks" placeholder="Enter Remarks Here" required>

			
			<br>

			<input type="submit" class="buttonSubmit" name="Submit" value="Add Violation">

		</form>
		
      
		</div>
    </div>

</body>