<?php
include '../config/config.php';
include '../classes/class_users.php';
include '../classes/class_students.php';
include '../classes/class_Violations.php';

$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($action){
	case 'violationNew': 
		newViolation();
			break;
}

function newViolation(){
	$cName = ucfirst($_POST['cName']);
	$cDescrip = ucfirst($_POST['cDescrip']);
	$cRemarks = $_POST['cRemarks'];
    $studentID = $_POST['id'];
    
    $checkStudent = new Students();
    $check = $checkStudent->getnumViolations($studentID);
    $update = $check + 1;
    
    $violationDetails = new Violations();
		$violationDetails->new_violation($studentID,$cName,$cDescrip,$cRemarks);
    
    $updateRecords = new Students();
        $updateRecords->updateViolations($update,$studentID);
    
    
    $message = "Violation Created";
        echo "<script type='text/javascript'>alert('$message');</script>";
        //echo "<script type='text/javascript'>alert('$update');</script>";
		echo "<script type='text/javascript'>window.location.href ='../UserManagement/index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
    /*$message = "Violation Updated";
    echo "<script type='text/javascript'>alert('$message');</script>";
    echo "<script type='text/javascript'>window.location.href ='index.php;</script>";
    exit;*/
}



?>
