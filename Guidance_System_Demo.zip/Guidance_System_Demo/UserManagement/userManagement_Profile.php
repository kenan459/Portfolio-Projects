<?php
  $module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
  $sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';
  $id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

?>

<style>
#submenuContainer {
    background-color: #36588e;
    margin-top: 0px;
    margin-left: 0px;
    height: 999px;
}

#icontainer {

    font-family: Arial, Helvetica, sans-serif;
    padding: 5%;
    margin-left: 5%;
    margin-bottom: -25%;
    text-align: left;
    width: 90%;
    height: 50%;
    color: white;

}
    
    #icontainer .profileInfo{
        font-size: 43px;
        margin-left: 1%;
    }

#icontainer p.titlePage{
    margin-top: -5%;
    margin-left: -0.5%;
    font-size: 29px;
    font-weight: bold;
    margin-bottom: 0px;

}

#icontainer p.subInfo{
    margin-top: 60px;
    font-size: 20px;
    font-weight: bold;
    margin-top: 0;
    margin-bottom: 15px;
  }

    #field1 {
        margin-left: 13%;
    }
    
 #field1 form {

    padding: 15px;
    margin-left: 15px;
    float: left;
    height: 500px;
    
}

#field1 label {
    margin-left: 15px;
}

#field1 input {
    
    height: 5px;
    width: 200px;
    padding: 10px 20px;
    padding-left: 5px;
    margin: 5px 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}

.buttonSubmit {
    color: white;
    background-color: #333;
    border: none;
    font-size: 16px;
    margin: 15px 15px;
    padding: 10px;
    width: 200px;
    height: 100px;
    cursor: pointer;

}

#field1 input[type="submit" ] {
    
    height: 5px;
    width: 200px;
    padding: 20px 0px;
    padding-left: 0px;
    padding-bottom: 35px;
    margin: 15px 0px;
    margin-left: 15px;
    text-align: center;
    box-sizing: border-box;
    display: block;
}


#field1 select{
    
    color: black;
    padding: 3px 135px;
    padding-left: 5px;
    margin-top: 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}

.icon {
    position: absolute;
    top: 150px;
    left: 100px;
	margin: auto;
}

.cid-r1y0ay8sxw img {
    width: 13%;
    height: 13%
}

</style>
<body>
<div id='icontainer'>

		<p class="titlePage">Profile</p>
        <br>

        <?php
    
    $myUser = new Users();

    {
    ?>
		

		<div id="field1">
		
			<p class="subInfo">User Information</p>


			<input type="hidden" name="id" value="<?php echo $id ?> ">
            
            <h2>First Name:</h2> <p class="profileInfo"> <?php echo $myUser->getFirst($id);?></p>
            
            <h2>Last name:</h2> <p class="profileInfo"> <?php echo $myUser->getLast($id);?></p>

           <h2> Username:</h2> <p class="profileInfo"> <?php echo $myUser->get_Email($id);?></p>
            
            <h2>Access:</h2> <p class="profileInfo"> <?php echo $myUser->getAccess($id);?></p>
               
               <br>
            
		</div>
		<img src="user.png" alt="security icon" class="icon" width="200" height="200">
        
		
	</div>

<?php
}
?>

</body>