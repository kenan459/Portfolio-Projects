<?php
include '../config/config.php';
include '../classes/class_users.php';
include '../classes/class_students.php';
include '../classes/class_grades.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';
$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';


switch($action){
	case 'usernew': 
		usernew();
			break;
    case 'studentnew': 
		studentnew();
			break;
    case 'studentInit': 
		initStudent();
			break;
	case 'modify':
		modifyUsers();
			break;
	case 'delete':
		deleteStudent();
			break;
    case 'api': 
		api_new();
			break;
	}

function api_new(){

	$fname = ucfirst($_POST['fname']);
    $userObj = new Users();
    $list=$userObj->new_api($fname);
    $userObj->new_api($fname);
	
		header("location: ../index.php?mod=userManagement&sub=listUser");
	exit;
	
		
	
}

function usernew(){

	$fname = ucfirst($_POST['fname']);
	$lname = ucfirst($_POST['lname']);
	$contactN = $_POST['contactN'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$cpassword = $_POST['cpassword'];
	$access = ucfirst($_POST['access']);

	
	
	if($password == $cpassword){
		$userObj = new Users();
        $list=$userObj->new_user($fname,$lname,$contactN,$email,$password,$cpassword,$access);
		$userObj->new_user($fname,$lname,$contactN,$email,$password,$cpassword,$access);

        $message = "Account Creation Successful!";
        echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script type='text/javascript'>window.location.href ='index.php?mod=userManagement&sub=listUsers'; </script>";
		exit;
	}else{
		$message = "Passwords did not match!";
        echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script type='text/javascript'>window.location.href ='index.php?mod=userManagement&sub=newUser'; </script>";
		exit;

		//header("location: ../index.php?mod=settings&sub=users&pro=new&error");
		//exit;
		
	}
}

function studentnew(){

	$fname = ucfirst($_POST['fname']);
	$lname = ucfirst($_POST['lname']);
	$contactN = $_POST['contactN'];
    $gContactN = $_POST['gContactN'];
    $address = $_POST['address'];
    
    $userObj = new Students();
        $list=$userObj->new_student($fname,$lname,$contactN, $gContactN, $address);
		$userObj->new_student($fname,$lname,$contactN, $gContactN, $address);
    
    $message = "Student Creation Successful!";
        echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script type='text/javascript'>window.location.href ='index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
}

function initStudent(){
    	
    $id = $_POST['id'];
    $init = new Students();
    $init->initialize_student($id);
    
    $initg = new Grades();
    $initg->initialize_Grades($id);
    
    
    $message = "Student Ready for Grading";
        echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script type='text/javascript'>window.location.href ='index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
}

	function modifyUsers(){
	
	$id = $_POST['id'];
	$email = $_POST['email'];
	$fname = ucfirst($_POST['fname']);
	$lname = ucfirst($_POST['lname']);
	$access = ucfirst($_POST['access']);
	
	$myEdit = new Users();
	
	$result=$myEdit->modify_users($id,$email,$fname,$lname,$access);
		if($result){
		header("location: ../index.php?mod=userManagement&sub=accountsUser");
		}else{
		$message = "Passwords did not match!";
        echo "<script type='text/javascript'>alert('$message');</script>";
		echo "<script type='text/javascript'>window.location.href ='../index.php?mod=userManagement&sub=newUser'; </script>";		
	}
}

	function deleteStudent(){

	$id = $_GET['id'];
        
	$myDel = new Students();
	
	$result=$myDel->delete_student($id);
		if($result){
		header("location: ../index.php?mod=userManagement&sub=ViewStudents");
		}else{
			header("location: index.php");
	}
}


?>
