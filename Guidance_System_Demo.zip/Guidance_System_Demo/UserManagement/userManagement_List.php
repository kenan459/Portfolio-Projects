<?php
$module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
$sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';

  


?>

<style>

  .green {
background-color: #2ECC71;
color:white;
}

th, td {
    border: none;
    text-align: left;
    padding: 10px;
   
}

    td a {
    color: blue;
    }

tr:nth-child(even){background-color: dimgray}

    #icontainer p.titlePage{
    margin-left: 3%;
    margin-bottom: 2%;
    margin-top: -27%;
    font-size: 30px;
    font-weight: bold;
    color: white;

}
    
  #icontainer {
    
     margin-top: 15%;
      margin-left: 5%;
      margin-bottom: -10%;
}

table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 95%;
    border: 1px solid black;
    margin-top: 3%;
    font-family: Arial;
    background-color: white;
}




</style>

<body>
    <div id="icontainer">

    <p class="titlePage">Account List</p>
    
    <table>


        <tr class="green">
          <th>Username</th>
          <th>First Name</th>
          <th>Last Name</th>
          
          <th>Date Added</th>
          <th>Time Added</th>
          <th> </th>
          <th> </th>
          <th> </th>
         
          
        </tr>
        <tr>
        <?php

        
        $Users = new Users();
        foreach($Users->getUsers() as $val){
          ?>

          <?php if ($val['user_status'] == 0){?>
         
            <td><a href=" index.php?mod=userManagement&sub=profileUser&id=<?php echo $val['user_id'];?>"><?php echo $val['user_email'];?></a></td>
            <td><?php echo $val['user_fname'];?></td>
            <td><?php echo $val['user_lname'];?></td>

            <td><?php echo $val['user_date_added'];?> </td>
            <td><?php echo $val['user_time_added'];?> </td>
            
            <td></td>
            <td></td>
         
        <td> </td>
          
        </tr>
        
        <?php
        }
      }
        ?>
    
        </table>
        </div>
        
        
        

    