<?php
  $module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
  $sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';
  $id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

?>

<style>
#submenuContainer {
    background-color: #36588e;
    margin-top: 0px;
    margin-left: 0px;
    height: 999px;
}

#icontainer {

    font-family: Arial, Helvetica, sans-serif;
    padding: 5%;
    margin-top: -15%;
    margin-left: 5%;
    margin-bottom: -25%;
    text-align: left;
    width: 90%;
    height: 50%;
    color: white;

}
    
    #icontainer .profileInfo{
        font-size: 22px;
        margin-left: 1%;
    }

#icontainer p.titlePage{
    margin-top: 15%;
    text-align: center;
    font-size: 35px;
    font-weight: bold;
    margin-bottom: 12%;

}

#icontainer p.subInfo{
    margin-top: -10%;
    font-size: 23px;
    margin-bottom: 2%;
  }

    #field1 {
        margin-left: 0%;
        margin-top: -10%;
        margin-bottom: 50%;
    }
    
 #field1 form {

    padding: 15px;
    margin-left: 15px;
    float: left;
    height: 500px;
    
}

#field1 label {
    margin-left: 15px;
}

#field1 input {
    
    height: 5px;
    width: 200px;
    padding: 10px 20px;
    padding-left: 5px;
    margin: 5px 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}

.buttonSubmit {
    color: white;
    background-color: #333;
    border: none;
    font-size: 16px;
    margin: 15px 15px;
    padding: 10px;
    width: 200px;
    height: 100px;
    cursor: pointer;

}

#field1 input[type="submit" ] {
    
    height: 5px;
    width: 200px;
    padding: 20px 0px;
    padding-left: 0px;
    padding-bottom: 35px;
    margin: 15px 0px;
    margin-left: 15px;
    text-align: center;
    box-sizing: border-box;
    display: block;
}


#field1 select{
    
    color: black;
    padding: 3px 135px;
    padding-left: 5px;
    margin-top: 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}
    
    

.icon {
	margin-left: -5%;
	margin-top: 0%;
    opacity: 0;
}

.cid-r1y0ay8sxw img {
    width: 13%;
    height: 13%
}
    
  .green {
      background-color: #2ECC71;
      color:white;
}

th, td {
    border: none;
    text-align: left;
    padding: 0.5%;
    margin-left: 2%;
    font-size: 13px;
   
}
    

    td a {
    color: blue;
    }
    
    h3 {
        font-size: 16px;
    }

tr:nth-child(even){background-color: dimgray}


/* Style the tab */


/* Style the buttons inside the tab */
.tab button {
  
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
}

#Violations{
    margin-left: 0%;
    }

.violationsTable2{

    }
    
.violationsTable2 td{
       color: white;
    top:5%;
    }
    
    .tab {
    position: absolute;
    top: 16.5%;
    left: 41%;
  
}
    
    .pageHeader {
        color: white;
        margin-left: 0%;
        font-size: 200%;;
    }
    
    .likeNavA{
        font-size: 80%;
        color:white;
        margin-top: 50%;
        font-size: 16px;
    }
    
    #likeNav {
        position: absolute;
        top: 13%;
        left: 41%;
    }
    
    .descrip{
        padding: 2%;
        font-size: 12px;
    }
    
    .address{
    }

</style>
<body>
<div id='icontainer'>
        <?php
        $checkStudent = new Students();
        $checkStudentC = new Violations();
        $check = $checkStudent->getnumViolations($id);
        $checkCounselRecords = $checkStudent->getCounselRecords($id);
        $hasGrades = $checkStudent->hasBeenGraded($id);
        ?>    
    
		<p class="titlePage">Student Profile</p>
        
        <div id="likeNav">
        <p class="pageHeader">
            Student Violations: <?php echo $check ?><br>
            <!--<a class="likeNavA"href="index.php?mod=userManagement&sub=newViolation&id=<?php echo $id ?>">+new violation</a> 
                <a class="likeNavA"href="index.php?mod=userManagement&sub=newCounseling&id=<?php echo $id ?>">+schedule for counseling</a>-->
                    </p>
            </div>
        <?php
    
    $fetchStudent = new Students();

    {
    ?>
		
        
		<div id="field1">
		
			<p class="subInfo">Student Information:</p>
            

			<input type="hidden" name="id" value="<?php echo $id ?> ">
            
            <h3>Student ID:<?php echo $id ?></h3>
            <h3>Student Name:</h3> <p class="profileInfo"><?php echo $fetchStudent->getLast($id);?>, <?php echo $fetchStudent->getFirst($id);?></p>
            <h3>Contact Number:</h3> <p class="profileInfo"> <?php echo $fetchStudent->getContact($id);?></p>
            <h3>Guardian Contact Number:</h3> <p class="profileInfo"> <?php echo $fetchStudent->getGcontact($id);?></p>
            <h3>Address:</h3> <textarea class="address" type="text" name="cDescrip" rows="6" cols="30" placeholder="Enter Case Description" readonly><?php echo $fetchStudent->getAddress($id);?>
            </textarea><p class="profileInfo"> </p>
          
		</div>
    
	</div>

<?php
}
?>

    
    <div class="tab">
        
        
        <!--Buttons-->
        <button class="tablinks" onclick="counselHelp()">Help</button>
        <button class="tablinks" onclick="tabs(event, 'Violations')">Violations</button>
        <button class="tablinks" onclick="tabs(event, 'Counseling')">Counseling</button>
        <?php if ($hasGrades == 1){ ?>
        <?php if ($_SESSION["access"] == "Counselor"){ ?> 
        <button class="tablinks" onclick="tabs(event, 'Grades')">Grades</button>
        <?php }
      
   
                                  }
          else { ?>
          <button class="tablinks">No Grades</button>
           <?php } ?>
          
        
            <div id="Violations" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                <?php if ($_SESSION["access"] == "Counselor"){ ?>    
                <a class="likeNavA"href="index.php?mod=userManagement&sub=newViolation&id=<?php echo $id ?>">+new violation</a>
                <?php }; ?>
                <br>
                <br>
                <p class="pageHeader">Violation Records:</p>
                <?php if ($check > 0){ ?>
            <tr class="green">
              <th>Case ID</th>
              <th>Case Name</th>
                <th>Case Remarks</th>
                <th>Case Description</th>

              <th>Date Added</th>
              <th>Time Added</th>

            </tr>
            <tr>
            <?php

            
            $getViolations = new Violations();
            foreach($getViolations->loadViolationss($id) as $val){
              ?>    

              <?php if ($val['case_status'] ==  0){?>

                <td><?php echo $val['case_id'];?></td>
                <td><?php echo $val['case_name'];?></td>
                <td><?php echo $val['case_remarks'];?></td>
                <td class="descrip"><?php echo $val['case_description'];?></td>
                <td><?php echo $val['case_date_added'];?></td>
                <td><?php echo $val['case_time_added'];?></td>

                <td></td>
                <td></td>

                <td></td>

            </tr>

            <?php
            }
                }
          }
            else{
                ?><p class="pageHeader"><?php echo "None";?></p>
            <?php } ?>
            </table>
            </div>
            <div id="Counseling" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                <?php if ($_SESSION["access"] == "Counselor"){ ?>
                <a class="likeNavA" href="index.php?mod=userManagement&sub=newCounseling&id=<?php echo $id ?>">+schedule student for counseling</a>
                <?php } ?>
                
                <br>
                <br>
                <p class="pageHeader">Counseling Records:</p>
            <?php if ($checkCounselRecords > 0){ ?>
            <tr class="green">
              <th>Counceling ID</th>
              <th>Counseling Title</th>
                <th>Counseling Description</th>
                <th>Counseling Date</th>
                <th>Counseling Time</th>

              <th>Date Added</th>
              <th>Time Added</th>

            </tr>
            <tr>
            <?php

            $getCounselingSched = new Counseling();
            foreach($getCounselingSched->loadCounselingSched($id) as $val){
              ?>    

              <?php if ($val['counsel_status'] ==  0){?>

                <td><?php echo $val['counsel_id'];?></td>
                <td><?php echo $val['counsel_title'];?></td>
                <td class="descrip"><?php echo $val['counsel_description'];?></td>
                <td><?php echo $val['counsel_date'];?></td>
                <td><?php echo $val['counsel_time'];?></td>
                
                <td><?php echo $val['counsel_date_added'];?></td>
                <td><?php echo $val['counsel_time_added'];?></td>

                <td></td>
                <td></td>

                <td></td>

            </tr>

            <?php
                }
            }
            }
                   else{
            ?>
          
                <p class="pageHeader"><?php echo "None";?></p>
            <?php } ?>
            </table>
            </div>
            <div id="Grades" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                
            <tr class="green">
              <th>Subject Name</th>
              <th>1st Grading</th>
              <th>2nd Grading</th>
              <th>3rd Grading</th>
              <th>4th Grading</th>

            </tr>
            <tr>
            <?php

             
            $getGrades = new Grades();
            foreach($getGrades->loadStudentGrades($id) as $val){
              ?>    

                <td><?php echo $val['subject_name'];?></td>
                <td><?php echo $val['grades_1st'];?></td>
                <td><?php echo $val['grades_2nd'];?></td>
                <td><?php echo $val['grades_3rd'];?></td>
                <td><?php echo $val['grades_4th'];?></td>
                

                <td></td>
                <td></td>

                <td></td>

            </tr>

            <?php
                }
            ?>
          
            </table>
            </div>
            </div>
    

    

            

    

            <script>

            function counselHelp() {
              alert("To create a new report about student violation, Press the Violations Tab and click on '+new violation' button \n for counseling press '+new counseling' and enter details for the next counseling schedule \n Counselor can also view student's grades. if theres no grades option, seek registrar for assistance");
            }

            function tabs(evt, cityName) {
              var i, tabcontent, tablinks;
              tabcontent = document.getElementsByClassName("tabcontent");
              for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
              }
              tablinks = document.getElementsByClassName("tablinks");
              for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
              }
              document.getElementById(cityName).style.display = "block";
              evt.currentTarget.className += " active";
            }
            </script>

</body>