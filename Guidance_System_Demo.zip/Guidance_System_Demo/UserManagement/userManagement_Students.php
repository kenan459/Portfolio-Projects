<?php
$module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
$sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';

  


?>

<style>

  .green {
background-color: #2ECC71;
color:white;
}

th, td {
    border: none;
    text-align: left;
    padding: 10px;
   
}

    td a {
    color: blue;
    }

tr:nth-child(even){background-color: dimgray}

    #icontainer p.titlePage{
    margin-left: 3%;
    margin-bottom: 2%;
    margin-top: -27%;
    font-size: 30px;
    font-weight: bold;
    color: white;

}
    
  #icontainer {
    
     margin-top: 15%;
      margin-left: 5%;
      margin-bottom: -10%;
}

table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 95%;
    border: 1px solid black;
    margin-top: 3%;
    font-family: Arial;
    background-color: white;
}

    .addStudent {
        font-size: 16px;
        color: lightgreen;
        
    }


</style>

<body>
    <div id="icontainer">

    <p class="titlePage">Student List <?php if ($_SESSION["access"] == "Registrar"){ ?><a class="addStudent" href="index.php?mod=userManagement&sub=newStudent">
        
        +New Student</a></p>
        <?php } ?>
    
    <table>


        <tr class="green">
            
        <th>Last Name</th>
        <th>First Name</th>
          
          <?php if ($_SESSION["access"] != "Registrar"){ ?><th>Violations</th> <?php } ?>
            
          <th>Date Added</th>
          <th>Time Added</th>
          <?php if ($_SESSION["access"] == "Registrar"){ ?><th>Actions </th> <?php } ?>
          <th> </th>
          <th> </th>
         
          
        </tr>
        <tr>
        <?php

        
        $loadStudents = new Students();
        foreach($loadStudents->getStudents() as $val){
          ?>    

          <?php if ($val['stud_status'] ==  0){?>
         
            <td>
                <?php if ($_SESSION["access"] == "Counselor" or $_SESSION["access"] == "Assistant"){ ?>
                <a href="index.php?mod=userManagement&sub=studentProfile&id=<?php echo $val['stud_id'];?>"> <?php echo $val['stud_lname'];?> </a><?php } ?>
                
                <?php if ($_SESSION["access"] == "Registrar"){ ?>
                <a href="index.php?mod=userManagement&sub=studentGrades&id=<?php echo $val['stud_id'];?>"> <?php echo $val['stud_lname'];?> </a><?php } ?>
                
            </td>
            <td><?php echo $val['stud_fname'];?></td>
            
            <?php if ($_SESSION["access"] != "Registrar"){ ?> <td><?php echo $val['stud_violations'];?></td> <?php } ?>

            <td><?php echo $val['stud_date_added'];?> </td>
            <td><?php echo $val['stud_time_added'];?> </td>
            <?php if ($_SESSION["access"] == "Registrar"){ ?> <td><a href="process.php?action=delete&id=<?php echo $val['stud_id'];?>" onclick = "return confirm('Are you Sure To Delete this Account: <?php echo $val['stud_fname'];?>?');">Delete</a></td> <?php } ?>
            
            <td></td>
            <td></td>
         
        <td> </td>
          
        </tr>
        
        <?php
        }
      }
        ?>
    
        </table>
        </div>
        
        
        

    