<?php
  $module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
  $sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';

?>

<style>


#icontainer {
    font-family: Arial, Helvetica, sans-serif;
    padding: 5%;
    margin-top: -2%;
    margin-left: 1%;
    margin-bottom: -22%;
    text-align: left;
    width: 85%;
    height: 0%;
    color: white;
}

#icontainer p.titlePage{
    margin-left: 3%;
    margin-bottom: 2%;
    font-size: 30px;
    font-weight: bold;
    

}

#icontainer p.subInfo{
    margin-top: 60px;
    font-size: 20px;
    font-weight: bold;
    margin-top: 0;
    margin-bottom: 15px;
  }
    
 #field1 form {
    left: 30%;
    float: left;
    
}

#field1 label {
    margin-left: 15px;
}

#field1 input {
    
    height: 40px;
    width: 300px;
    padding: 10px 20px;
    padding-left: 5px;
    margin: 5px 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
    font-size: 20px;
}

.buttonSubmit {
    color: white;
    background-color: #333;
    border: none;
    font-size: 1px;

    cursor: pointer;

}

#field1 input[type="submit" ] {
    font-size: 36px;
    height: 10%;
    width: 105%;
    padding: 29px 0px;
    padding-left: 0px;
    padding-bottom: 35px;
    margin: 10px 0px;
    margin-left: 15px;
    text-align: center;
    box-sizing: border-box;
    display: block;
}


#field1 select{
    height: 40px;
    color: black;
    padding: 3px 135px;
    padding-left: 5px;
    margin-top: 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}
    

.cid-r1y0ay8sxw img {
    width: 25%;
    margin-left: 5%;
}
    


</style>

<body>

        <div id="icontainer">
            
		<p class="titlePage">Account Creation</p>
		

		<div id="field1">
            <img src="user.png" alt="security icon" class="icona" width="200" height="300">
		<form method="POST" action="process.php?action=usernew">
			<p class="subInfo">User Information</p>

			<label>First Name: </label>
			<input type="text" name="fname" placeholder="Enter First Name" required>

			<label for="lname">Last Name: </label>
			<input type="text" name="lname" placeholder="Enter Last Name" required>

			

			<label for="cnumber">Contact Number</label>
			<input type="text" name="contactN" placeholder="Enter Contact Number" required>

			<br>

			<p class="subInfo">User Credentials</p>

			<label for="email">Username: </label>
			<input type="text" name="email" placeholder="Enter Username" required>

			<label for="password">Password: </label>
			<input class="wordypass" type="password" id="password" name="password" placeholder="Enter Password" required>

			<label for="cpassword">Confirm Password: </label>
			<input type="password" id="cpassword" name="cpassword" placeholder="Confirm Password" required>

			<!--<label>Access Level: </label>
			<select name="access">
  				<option value="user">User</option>
  				<option value="admin">Admin</option>
			</select>-->
            
         
        <label>Access Level: </label>
        <select name="access">
        <?php 

        $AccessList = new Access();
        foreach($AccessList->getAccessList() as $val){
        ?>
  				<option value="<?php echo $val['access_name'];?>"><?php echo $val['access_name'] ?></option>
  		<?php } ?>
            </select>
            
            

			<br>

			<input type="submit" class="buttonSubmit" name="Submit" value="Create User">

		</form>
		
      
		</div>
    </div>

</body>