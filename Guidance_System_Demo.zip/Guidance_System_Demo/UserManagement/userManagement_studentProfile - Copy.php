<?php
  $module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
  $sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';
  $id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

?>

<style>
#submenuContainer {
    background-color: #36588e;
    margin-top: 0px;
    margin-left: 0px;
    height: 999px;
}

#icontainer {

    font-family: Arial, Helvetica, sans-serif;
    padding: 5%;
    margin-top: -15%;
    margin-left: 5%;
    margin-bottom: -25%;
    text-align: left;
    width: 90%;
    height: 50%;
    color: white;

}
    
    #icontainer .profileInfo{
        font-size: 22px;
        margin-left: 1%;
    }

#icontainer p.titlePage{
    margin-top: 15%;
    text-align: center;
    font-size: 35px;
    font-weight: bold;
    margin-bottom: 12%;

}

#icontainer p.subInfo{
    margin-top: -10%;
    font-size: 23px;
    margin-bottom: 2%;
  }

    #field1 {
        margin-left: 3%;
        margin-top: -24%;
        margin-bottom: 50%;
    }
    
 #field1 form {

    padding: 15px;
    margin-left: 15px;
    float: left;
    height: 500px;
    
}

#field1 label {
    margin-left: 15px;
}

#field1 input {
    
    height: 5px;
    width: 200px;
    padding: 10px 20px;
    padding-left: 5px;
    margin: 5px 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}

.buttonSubmit {
    color: white;
    background-color: #333;
    border: none;
    font-size: 16px;
    margin: 15px 15px;
    padding: 10px;
    width: 200px;
    height: 100px;
    cursor: pointer;

}

#field1 input[type="submit" ] {
    
    height: 5px;
    width: 200px;
    padding: 20px 0px;
    padding-left: 0px;
    padding-bottom: 35px;
    margin: 15px 0px;
    margin-left: 15px;
    text-align: center;
    box-sizing: border-box;
    display: block;
}


#field1 select{
    
    color: black;
    padding: 3px 135px;
    padding-left: 5px;
    margin-top: 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}
    
    

.icon {
	margin-left: -5%;
	margin-top: 0%;
    opacity: 0;
}

.cid-r1y0ay8sxw img {
    width: 13%;
    height: 13%
}
    
  .green {
      background-color: #2ECC71;
      color:white;
}

th, td {
    border: none;
    text-align: left;
    padding: 0.5%;
    margin-left: 2%;
    font-size: 13px;
   
}
    

    td a {
    color: blue;
    }
    
    h3 {
        font-size: 16px;
    }

tr:nth-child(even){background-color: dimgray}
    
/* Style the tab */
.tab {
  margin-left: 20%;
  
}

/* Style the buttons inside the tab */
.tab button {
  
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
  

}

.violationsTable{
        position: absolute;
        left: 30%;
        top: 20%;
        margin-bottom: 10%;
    }
    
.violationsTable2{
       margin-left: -24%;
    }
    
.violationsTable2 td{
       color: white;
    }
    
    .pageHeader {
        position: absolute;
        font-size: 30px;
        left: 47%;
        top: 15.5%;
        
    }
    
    .newViolation{
        font-size: 12px;
        color:white;
        margin-right: 0%;
    }
    
    .descrip{
        padding: 2%;
        font-size: 12px;
    }
    
    .address{
    }

</style>
<body>
<div id='icontainer'>
        <?php
        $checkStudent = new Students();
        $check = $checkStudent->getnumViolations($id);
        ?>    
    
		<p class="titlePage">Student Profile</p>
        <p class="pageHeader"><a class="newViolation"href="index.php?mod=userManagement&sub=newViolation&id=<?php echo $id ?>">+new violation</a>Violations: <?php echo $check ?></p>
        
    <table class="violationsTable">

        <tr class="green">
          <th>Case ID</th>
            <th>Student ID</th>
          <th>Case Name</th>
            <th>Case Remarks</th>
            <th>Case Description</th>
          
          <th>Date Added</th>
          <th>Time Added</th>
         
        </tr>
        <tr>
        <?php
        
        if ($check > 0){
        $getViolations = new Violations();
        foreach($getViolations->loadViolationss($id) as $val){
          ?>    

          <?php if ($val['case_status'] ==  0){?>
         
            <td><?php echo $val['case_id'];?></td>
            <td><?php echo $val['stud_id'];?></td>
            <td><?php echo $val['case_name'];?></td>
            <td><?php echo $val['case_remarks'];?></td>
            <td class="descrip"><?php echo $val['case_description'];?></td>
            <td><?php echo $val['case_date_added'];?></td>
            <td><?php echo $val['case_time_added'];?></td>
            
            <td></td>
            <td></td>
         
            <td></td>
          
        </tr>
        
        <?php
        }
            }
      }
        ?>
    
        </table>
        
        <?php
    
    $fetchStudent = new Students();

    {
    ?>
		<img src="user.png" alt="security icon" class="icon" width="200" height="200">

		<div id="field1">
		
			<p class="subInfo">Student Information:</p>


			<input type="hidden" name="id" value="<?php echo $id ?> ">
            
            <h3>Student ID:<?php echo $id ?></h3>
            <h3>Student Name:</h3> <p class="profileInfo"><?php echo $fetchStudent->getLast($id);?>, <?php echo $fetchStudent->getFirst($id);?></p>
            <h3>Contact Number:</h3> <p class="profileInfo"> <?php echo $fetchStudent->getContact($id);?></p>
            <h3>Guardian Contact Number:</h3> <p class="profileInfo"> <?php echo $fetchStudent->getGcontact($id);?></p>
            <h3>Address:</h3> <textarea class="address" type="text" name="cDescrip" rows="6" cols="30" placeholder="Enter Case Description" readonly><?php echo $fetchStudent->getAddress($id);?>
            </textarea><p class="profileInfo"> </p>
            <br>
            <br>
            
		</div>
    
	</div>

<?php
}
?>


    <div class="tab">
              <button class="tablinks" onclick="tabs(event, 'London')">London</button>
              <button class="tablinks" onclick="tabs(event, 'Paris')">Paris</button>
              
            </div>

    <div id="London" class="tabcontent">
                <br>
                <br>
                <br>
        <table class="violationsTable2">

        <tr class="green">
          <th>Case ID</th>
            <th>Student ID</th>
          <th>Case Name</th>
            <th>Case Remarks</th>
            <th>Case Description</th>
          
          <th>Date Added</th>
          <th>Time Added</th>
         
        </tr>
        <tr>
        <?php
        
        if ($check > 0){
        $getViolations = new Violations();
        foreach($getViolations->loadViolationss($id) as $val){
          ?>    

          <?php if ($val['case_status'] ==  0){?>
         
            <td><?php echo $val['case_id'];?></td>
            <td><?php echo $val['stud_id'];?></td>
            <td><?php echo $val['case_name'];?></td>
            <td><?php echo $val['case_remarks'];?></td>
            <td class="descrip"><?php echo $val['case_description'];?></td>
            <td><?php echo $val['case_date_added'];?></td>
            <td><?php echo $val['case_time_added'];?></td>
            
            <td></td>
            <td></td>
         
            <td></td>
          
        </tr>
        
        <?php
        }
            }
      }
        ?>
    
        </table>
            </div>

         

            <script>
            function tabs(evt, cityName) {
              var i, tabcontent, tablinks;
              tabcontent = document.getElementsByClassName("tabcontent");
              for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
              }
              tablinks = document.getElementsByClassName("tablinks");
              for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
              }
              document.getElementById(cityName).style.display = "block";
              evt.currentTarget.className += " active";
            }
            </script>

</body>