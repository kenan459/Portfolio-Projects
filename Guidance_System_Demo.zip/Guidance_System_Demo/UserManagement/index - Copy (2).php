<?php
$module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
$sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';

  

include '../config/config.php';
include '../classes/class_users.php';
include '../classes/class_access.php';

$user = new Users();
  if(!$user->get_session()){
    header("location: ../index.php");
  }

?>



<!DOCTYPE html>
<!-- saved from url=(0059)https://mobirise.com/extensions/educationm4/university.html -->
<html class="desktop mbr-site-loaded"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><script async="" src="./University Demo_files/fbevents.js.download"></script><script type="text/javascript" async="" src="./University Demo_files/f.txt"></script><script type="text/javascript" async="" src="./University Demo_files/analytics.js.download"></script><script type="text/javascript" id="www-widgetapi-script" src="./University Demo_files/www-widgetapi.js.download" async=""></script><script src="./University Demo_files/iframe_api" id="YTAPI"></script>
  <!-- Site made with Mobirise Website Builder v4.8.2, https://mobirise.com -->
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.8.2, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="./University Demo_files/logo.png" type="image/x-icon">
  <meta name="description" content="New EducationM4 HTML Template - Download Now">
  <title>University Demo</title>
  <link rel="stylesheet" href="./University Demo_files/mobirise-icons.css">
  <link rel="stylesheet" href="./University Demo_files/tether.min.css">
  <link rel="stylesheet" href="./University Demo_files/style.css">
  <link rel="stylesheet" href="./University Demo_files/bootstrap.min.css">
  <link rel="stylesheet" href="./University Demo_files/bootstrap-grid.min.css">
  <link rel="stylesheet" href="./University Demo_files/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="./University Demo_files/style(1).css">
  <link rel="stylesheet" href="./University Demo_files/styles.css">
  <link rel="stylesheet" href="./University Demo_files/data-tables.bootstrap4.min.css">
  <link rel="stylesheet" href="./University Demo_files/style(2).css">
  <link rel="stylesheet" href="./University Demo_files/style(3).css">
  <link rel="stylesheet" href="./University Demo_files/mbr-additional.css" type="text/css">
  
  
  
<script src="./University Demo_files/f(1).txt"></script></head>
<body><section id="top-1" class="engine"><a href="https://mobirise.info/">Mobirise Website Builder</a> v4.8.2</section>

    
    <style>
        
    .loginheader{
            font-size: 25px;
            text-align: center;
            margin-top: 1%;
            margin-bottom: 15%;
            width: 100%;
        }
        
        .row {
            
        }
        
    #innercont{
        background-color: red;
    font-family: Arial, Helvetica, sans-serif;
    padding: 10%;
    margin-left: 0%;
    text-align: left;
    width: 100%;
    height: 20%;
    color: black;
	}
        
    .btnDash {
        position: absolute;
        top: 33%;
        left: 5%;
        background-color: #4CAF50;
        color: white;
        padding: 16px;
        font-size: 16px;
        border: none;
        cursor: pointer;
    }
        
    .btnDash a {
        color: white;
        }

   .dropdown1 {
        position: absolute;
        top: 36%;
        left: 11%;
    }

        
    .dropbtn1 {
      background-color: #4CAF50;
      color: white;
      padding: 16px;
      font-size: 16px;
      border: none;
      cursor: pointer;
    }
        
    .btnDash:hover {
      background-color: #3e8e41;
    }

 
    .dropdown-content1 {
      display: none;
      position: absolute;
      background-color: #f9f9f9;
      min-width: 160px;
      box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
      z-index: 1;
    }

    .dropdown-content1 a {
      color: black;
      padding: 12px 16px;
      text-decoration: none;
      display: block;
    }

    .dropdown-content1 a:hover {background-color: #f1f1f1}

    .dropdown1:hover .dropdown-content1 {
      display: block;
    }

    .dropdown1:hover .dropbtn1 {
      background-color: #3e8e41;
    }
        
    #container {
        background-color: blue;
        width: 40%;
        margin-top: -10%;
        margin-left: 20%;
    }
   

        
        


</style>
    
    
<!-- Google Analytics -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-PFK425"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script src="./University Demo_files/iframe_api(1)"></script><script async="" src="./University Demo_files/gtm.js.download"></script><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PFK425');</script>
<!-- /Google Analytics -->


  <section class="menu cid-r1xJbFr6TJ" once="menu" id="menu1-1l">

    

    <nav class="navbar navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        
        <div class="menu-bottom">


            <div class="menu-logo">
                <div class="navbar-brand">
                    <span class="navbar-logo">
                        <a href="https://mobirise.com/">
                            <img src="./University Demo_files/logo.png" alt="Mobirise" style="height: 4rem;">
                        </a>
                    </span>
                    <span class="navbar-caption-wrap"><a href="https://mobirise.com/extensions/educationm4/index.html" class="brand-link mbr-black text-black mbr-bold display-5">EducationM4</a></span>
                </div>
            </div>



            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav nav-dropdown js-float-line" data-app-modern-menu="true"><li class="nav-item">
                        <a class="nav-link link mbr-black text-black display-4" href="https://mobirise.com/extensions/educationm4/index.html">
                            Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link link mbr-black dropdown-toggle text-black display-4" href="https://mobirise.com/" data-toggle="dropdown-submenu" aria-expanded="false">Live Demo</a>
                        <div class="dropdown-menu">
                            <a class="mbr-black dropdown-item text-black display-4" href="https://mobirise.com/extensions/educationm4/courses.html">Training Courses Demo</a>
                            <a class="mbr-black dropdown-item text-black display-4" href="https://mobirise.com/extensions/educationm4/university.html" aria-expanded="false">University Demo</a>
                            
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link link mbr-black dropdown-toggle text-black display-4" href="https://mobirise.com/" data-toggle="dropdown-submenu" aria-expanded="false">Demo Blocks</a>
                        <div class="dropdown-menu">
                            <a class="mbr-black dropdown-item text-black display-4" href="https://mobirise.com/extensions/educationm4/headers.html">Headers &amp; Features</a>
                            <a class="mbr-black dropdown-item text-black display-4" href="https://mobirise.com/extensions/educationm4/info.html" aria-expanded="false">Info &amp; Progress Bars</a>
                            <a class="mbr-black dropdown-item text-black display-4" href="https://mobirise.com/extensions/educationm4/table.html" aria-expanded="false">Table &amp; Gallery</a><a class="mbr-black text-black dropdown-item display-4" href="https://mobirise.com/extensions/educationm4/team.html" aria-expanded="false">Team &amp; Countdowns</a><a class="mbr-black text-black dropdown-item display-4" href="https://mobirise.com/extensions/educationm4/testimonials.html" aria-expanded="false">Testimonials &amp; Timeline</a><a class="mbr-black text-black dropdown-item display-4" href="https://mobirise.com/extensions/educationm4/forms.html" aria-expanded="false">Forms &amp; Maps &amp; Footers</a>
                        </div>
                    </li></ul>
                
                 <p class = "user"><?php echo $_SESSION["access"];echo $_SESSION["userdata"] ?>
                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-md btn-primary-outline display-4" href="../system/logout.php" onclick = "return confirm('Are You Sure You Want to Log-out?')">Logout</a>
               

            </div>
            <button class="navbar-toggler " type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </button>







        </div>
    </nav>
</section>

<section class="header3 cid-r1y0ay8sxw" id="header3-1m">

    

    

    <div class="container-fluid align-center">
        <div class="row">
            
            <div id="innercont">
                <header><div class="loginheader">Dashboard</div></header>
                
                <button class="btnDash"><a href="index.php?mod=userManagement&sub=listUsers">Dashboard</a></button>
                
                <div class="dropdown1">
                <button class="dropbtn1">Manage Accounts</button>
                <div class="dropdown-content1">
                <a href="index.php?mod=userManagement&sub=newUser">Create Account</a>
                <a href="#">Link 2</a>
                <a href="#">Link 3</a>
                </div>
                </div>
                
                <div id="container">
               
                  <?php
                    switch($sub){
                        case 'newUser':
                            require_once 'userManagement_add.php';
                        break;
                        case 'listUsers':
                            require_once 'userManagement_List.php';
                        break;
                        case 'userAccounts':
                            require_once 'userManagement_Accounts.php';
                        break;
                        case 'editUser':
                            require_once 'userManagement_Edit.php';
                        break;
                        case 'profileUser':
                            require_once 'userManagement_Profile.php';
                        break;
        }
            ?>
            </div>

                
     
                
		
        
                

		</div>
            
    </div>
    
</section>

<section class="features2 counters cid-r1y0jKdhCl visible full-visible" id="features2-1o">

    

    
   

<section class="footer2 cid-r1y0JN4ioW" id="footer2-1z">

    

    

    

        <div class="row">
            <div class="col-sm-12">
                <p class="mbr-text links mbr-fonts-style display-4">
                    Copyright (c) 2018
                    <a href="https://mobirise.com/" class="text-white">Mobirise</a>
                </p>
            </div>
        </div>
    
</section>


  <script src="./University Demo_files/jquery.min.js.download"></script>
  <script src="./University Demo_files/popper.min.js.download"></script>
  <script src="./University Demo_files/tether.min.js.download"></script>
  <script src="./University Demo_files/bootstrap.min.js.download"></script>
  <script src="./University Demo_files/jquery.mb.ytplayer.min.js.download"></script>
  <script src="./University Demo_files/script.min.js.download"></script>
  <script src="./University Demo_files/jquery.touch-swipe.min.js.download"></script>
  <script src="./University Demo_files/jquery.viewportchecker.js.download"></script>
  <script src="./University Demo_files/jquery.mb.vimeo_player.js.download"></script>
  <script src="./University Demo_files/masonry.pkgd.min.js.download"></script>
  <script src="./University Demo_files/imagesloaded.pkgd.min.js.download"></script>
  <script src="./University Demo_files/bootstrap-carousel-swipe.js.download"></script>
  <script src="./University Demo_files/smooth-scroll.js.download"></script>
  <script src="./University Demo_files/jquery.data-tables.min.js.download"></script>
  <script src="./University Demo_files/data-tables.bootstrap4.min.js.download"></script>
  <script src="./University Demo_files/mbr-testimonials-slider.js.download"></script>
  <script src="./University Demo_files/script.js.download"></script>
  <script src="./University Demo_files/script.js(1).download"></script>
  <script src="./University Demo_files/player.min.js.download"></script>
  <script src="./University Demo_files/script.js(2).download"></script>
  <script src="./University Demo_files/formoid.min.js.download"></script>
  
  


<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","1123285727682531");fbq("set","agent","tmgoogletagmanager","1123285727682531");fbq("track","PageView");</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1123285727682531&amp;ev=PageView&amp;noscript=1"></noscript>
</body></html>