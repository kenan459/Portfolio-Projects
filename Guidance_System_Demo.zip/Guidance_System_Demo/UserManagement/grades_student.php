<?php
  $module = (isset($_GET['mod']) && $_GET['mod'] != '') ? $_GET['mod'] : '';
  $sub = (isset($_GET['sub']) && $_GET['sub'] != '') ? $_GET['sub'] : '';
  $id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

?>

<style>

#submenuContainer {
    background-color: #36588e;
    margin-top: 0px;
    margin-left: 0px;
    height: 999px;
}

#icontainer {

    font-family: Arial, Helvetica, sans-serif;
    padding: 5%;
    margin-top: -15%;
    margin-left: 5%;
    margin-bottom: -25%;
    text-align: left;
    width: 90%;
    height: 50%;
    color: white;

}
    
    #icontainer .profileInfo{
        font-size: 22px;
        margin-left: 1%;
    }

#icontainer p.titlePage{
    margin-top: 12%;
    text-align: center;
    font-size: 35px;
    font-weight: bold;
    margin-bottom: 12%;

}

#icontainer p.subInfo{
    margin-top: -10%;
    font-size: 23px;
    margin-bottom: 2%;
  }

    #field1 {
        margin-left: 0%;
        margin-top: -10%;
        margin-bottom: 50%;
    }
    
 #field1 form {

    padding: 15px;
    margin-left: 15px;
    float: left;
    height: 500px;
    
}

#field1 label {
    margin-left: 15px;
}

#field1 input {
    
    height: 5px;
    width: 200px;
    padding: 10px 20px;
    padding-left: 5px;
    margin: 5px 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}

.buttonSubmit {
    color: white;
    background-color: #333;
    border: none;
    font-size: 16px;
    margin: 15px 15px;
    padding: 10px;
    width: 200px;
    height: 100px;
    cursor: pointer;

}

#field1 input[type="submit" ] {
    
    height: 5px;
    width: 200px;
    padding: 20px 0px;
    padding-left: 0px;
    padding-bottom: 35px;
    margin: 15px 0px;
    margin-left: 15px;
    text-align: center;
    box-sizing: border-box;
    display: block;
}


#field1 select{
    
    color: black;
    padding: 3px 135px;
    padding-left: 5px;
    margin-top: 5px;
    margin-left: 15px;
    box-sizing: border-box;
    display: block;
}
    
    

.icon {
	margin-left: -5%;
	margin-top: 0%;
    opacity: 0;
}

.cid-r1y0ay8sxw img {
    width: 13%;
    height: 13%
}
    
  .green {
      background-color: #2ECC71;
      color:white;
}

th, td {
    border: none;
    text-align: left;
    padding: 0.5%;
    margin-left: 6%;
    font-size: 15px;
    width: 0%;
}
    

    td a {
    color: blue;
    }
    
    h3 {
        font-size: 16px;
    }

tr:nth-child(even){background-color: dimgray}


/* Style the tab */
    .tab {
        margin-top: 0%;
        margin-left: -10%;
    }

/* Style the buttons inside the tab */
.tab button {
  
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  display: none;
}

#Violations{
    margin-left: 0%;
    }

.violationsTable2{
width: 100%;
    }
    
.violationsTable2 td{
    color: white;
    top:5%;
    
    }
    
    .tab {
    position: absolute;
    top: 16.5%;
    left: 41%;
  
}
    
    .pageHeader {
        color: white;
        margin-top: 8%;
        margin-left: 0%;
        font-size: 200%;
    }
    
    .likeNavA{
        font-size: 80%;
        color:white;
        margin-top: 50%;
    }
    
    #likeNav {
        position: absolute;
        top: 13%;
        left: 41%;
    }
    
    .descrip{
        padding: 2%;
        font-size: 12px;
    }
    
    .val{
        width: 25%;
        font-size: 100%;
        text-align: center;
    }
    
    #warning {

        font-weight: bold;
        margin-top: 15%;
        margin-left: 45%;

    }

</style>
<body>
<div id='icontainer'>
        <?php
        $checkStudent = new Students();
        $checkStudentC = new Violations();
        $check = $checkStudent->getnumViolations($id);
        $checkCounselRecords = $checkStudent->getCounselRecords($id);
        $hasGrades = $checkStudent->hasBeenGraded($id);
        
        ?>    
    
		<p class="titlePage">Student Grades</p>
        
        <div id="likeNav">
        <p class="pageHeader">
             </p>
            </div>
        <?php
    
    $fetchStudent = new Students();

    {
    ?>
		
        
		<div id="field1">
		
			<p class="subInfo">Student Information:</p>
            

			<input type="hidden" name="id" value="<?php echo $id ?> ">
            
            <h3>Student ID:<?php echo $id ?></h3>
            <h3>Student Name:</h3> <p class="profileInfo"><?php echo $fetchStudent->getLast($id);?>, <?php echo $fetchStudent->getFirst($id);?></p>
            
          
		</div>
    
	</div>

<?php
}
?>

    
    <div class="tab">
        
        
        <!--Buttons-->
        <input type="hidden" name="id" value="<?php echo $id ?> ">
        <?php $thisID = $id; ?>
        <?php if ($hasGrades == 1){ ?>
        <button class="tablinks" onclick="gradingHelp()">Help</button>
        <button class="tablinks" onclick="tabs(event, 'Overview')">Overview</button>
        <button class="tablinks" onclick="tabs(event, '1st Grading')">1st Grading</button>
        <button class="tablinks" onclick="tabs(event, '2nd Grading')">2nd Grading</button>
        <button class="tablinks" onclick="tabs(event, '3rd Grading')">3rd Grading</button>
        <button class="tablinks" onclick="tabs(event, '4th Grading')">4th Grading</button>
        
            <div id="Overview" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                
            <tr class="green">
              <th>Subject Name</th>
              <th>1st Grading</th>
              <th>2nd Grading</th>
              <th>3rd Grading</th>
              <th>4th Grading</th>

            </tr>
            <tr>
            <?php

             
            $getGrades = new Grades();
            foreach($getGrades->loadStudentGrades($id) as $val){
              ?>    

                <td><?php echo $val['subject_name'];?></td>
                <td><?php echo $val['grades_1st'];?></td>
                <td><?php echo $val['grades_2nd'];?></td>
                <td><?php echo $val['grades_3rd'];?></td>
                <td><?php echo $val['grades_4th'];?></td>
                

                <td></td>
                <td></td>

                <td></td>

            </tr>

            <?php
                }
            }
            else { ?>   <form method="POST" action="process.php?action=studentInit&id=<?php $id ?>"> 
                <?php $thisID = $id;?>
                <input type="hidden" name="id" value="<?php echo $id ?> ">
                <div id="warning"><input type="submit" class="buttonSubmit" name="Submit" value="Start Grading"> </div> </form>
                <?php } ?>
          
            </table>
            </div>
            <div id="1st Grading" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                 <form method="POST" action="../Grades/process.php?action=grades1st&id=<?php echo $id ?>">
                     <input type="hidden" name="id" value="<?php echo $id ?> ">
            <tr class="green">
              <th>Subject Name</th>
              <th>1st Grading</th>
            </tr>
            
               
                    <tr>
                <td>English</td>
                <td><input class="val" type="text" name="english" placeholder="input Grade" required></td>
                    </tr>
                     
                     <tr>
                <td>Filipino</td>
                <td><input class="val" type="text" name="filipino" placeholder="input Grade" required></td>
                     </tr>
                     
                    <tr>
                <td>Math</td>
                <td><input class="val" type="text" name="math" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>Social Studies</td>
                <td><input class="val" type="text" name="social" placeholder="input Grade" required></td>
                     </tr>
                <tr>
                <td>TLE</td>
                <td><input class="val" type="text" name="tle" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>PE</td>
                <td><input class="val" type="text" name="pe" placeholder="input Grade" required></td>
                     </tr>

                <input type="submit" class="buttonSubmit" name="Submit" value="Update Student Grades">
                </form>
          
          
            </table>
            </div>
            <div id="2nd Grading" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                 <form method="POST" action="../Grades/process.php?action=grades2nd&id=<?php echo $id ?>">
                     <input type="hidden" name="id" value="<?php echo $id ?> ">
            <tr class="green">
              <th>Subject Name</th>
              <th>2nd Grading</th>
            </tr>
            
               
                    <tr>
                <td>English</td>
                <td><input class="val" type="text" name="english" placeholder="input Grade" required></td>
                    </tr>
                     
                     <tr>
                <td>Filipino</td>
                <td><input class="val" type="text" name="filipino" placeholder="input Grade" required></td>
                     </tr>
                     
                    <tr>
                <td>Math</td>
                <td><input class="val" type="text" name="math" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>Social Studies</td>
                <td><input class="val" type="text" name="social" placeholder="input Grade" required></td>
                     </tr>
                <tr>
                <td>TLE</td>
                <td><input class="val" type="text" name="tle" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>PE</td>
                <td><input class="val" type="text" name="pe" placeholder="input Grade" required></td>
                     </tr>

                <input type="submit" class="buttonSubmit" name="Submit" value="Update Student Grades">
                </form>
          
          
            </table>
            </div>
            <div id="3rd Grading" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                 <form method="POST" action="../Grades/process.php?action=grades3rd&id=<?php echo $id ?>">
                     <input type="hidden" name="id" value="<?php echo $id ?> ">
            <tr class="green">
              <th>Subject Name</th>
              <th>3rd Grading</th>
            </tr>
            
               
                    <tr>
                <td>English</td>
                <td><input class="val" type="text" name="english" placeholder="input Grade" required></td>
                    </tr>
                     
                     <tr>
                <td>Filipino</td>
                <td><input class="val" type="text" name="filipino" placeholder="input Grade" required></td>
                     </tr>
                     
                    <tr>
                <td>Math</td>
                <td><input class="val" type="text" name="math" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>Social Studies</td>
                <td><input class="val" type="text" name="social" placeholder="input Grade" required></td>
                     </tr>
                <tr>
                <td>TLE</td>
                <td><input class="val" type="text" name="tle" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>PE</td>
                <td><input class="val" type="text" name="pe" placeholder="input Grade" required></td>
                     </tr>

                <input type="submit" class="buttonSubmit" name="Submit" value="Update Student Grades">
                </form>
          
          
            </table>
            </div>
            <div id="4th Grading" class="tabcontent">
                    <br>
                    <br>
                    <br>
            
            <table class="violationsTable2">
                
                 <form method="POST" action="../Grades/process.php?action=grades4th&id=<?php echo $id ?>">
                     <input type="hidden" name="id" value="<?php echo $id ?> ">
            <tr class="green">
              <th>Subject Name</th>
              <th>4th Grading</th>
            </tr>
            
               
                    <tr>
                <td>English</td>
                <td><input class="val" type="text" name="english" placeholder="input Grade" required></td>
                    </tr>
                     
                     <tr>
                <td>Filipino</td>
                <td><input class="val" type="text" name="filipino" placeholder="input Grade" required></td>
                     </tr>
                     
                    <tr>
                <td>Math</td>
                <td><input class="val" type="text" name="math" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>Social Studies</td>
                <td><input class="val" type="text" name="social" placeholder="input Grade" required></td>
                     </tr>
                <tr>
                <td>TLE</td>
                <td><input class="val" type="text" name="tle" placeholder="input Grade" required></td>
                     </tr>
                    <tr>
                <td>PE</td>
                <td><input class="val" type="text" name="pe" placeholder="input Grade" required></td>
                     </tr>

                <input type="submit" class="buttonSubmit" name="Submit" value="Update Student Grades">
                </form>
          
          
            </table>
            </div>
        
            </div>
    

    

            



            <script>

            function gradingHelp() {
                alert("To update a student's grade, simply click on the which grading period tab you want to update \n then input desired grades and press the `Update Student Grades` Button");
            }

            function tabs(evt, cityName) {
              var i, tabcontent, tablinks;
              tabcontent = document.getElementsByClassName("tabcontent");
              for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
              }
              tablinks = document.getElementsByClassName("tablinks");
              for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
              }
              document.getElementById(cityName).style.display = "block";
              evt.currentTarget.className += " active";
            }
            </script>

</body>