<?php
include '../config/config.php';
include '../classes/class_users.php';
include '../classes/class_grades.php';
include '../classes/class_subjects.php';

$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';
$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($action){
	case 'grades1st': 
		firstGrading();
			break;
    case 'grades2nd': 
		secondGrading();
			break;
    case 'grades3rd': 
		thirdGrading();
			break;
    case 'grades4th': 
		fourthGrading();
			break;
}

function firstGrading(){
	$engl = ($_POST['english']);
	$fili = ($_POST['filipino']);
	$math = $_POST['math'];
    $soc = $_POST['social'];
    $tle = $_POST['tle'];
    $pe = $_POST['pe'];
    $studentID = $_POST['id'];
    
    $updateRecords = new Grades();
        $updateRecords->update1st($studentID, $engl, $fili, $math, $soc, $tle, $pe);
    
    $message = "Grades Updated.";
        echo "<script type='text/javascript'>alert('$message');</script>";
        //echo "<script type='text/javascript'>alert('$update');</script>";
		echo "<script type='text/javascript'>window.location.href ='../UserManagement/index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
}

function secondGrading(){
	$engl = ($_POST['english']);
	$fili = ($_POST['filipino']);
	$math = $_POST['math'];
    $soc = $_POST['social'];
    $tle = $_POST['tle'];
    $pe = $_POST['pe'];
    $studentID = $_POST['id'];
    
    $updateRecords = new Grades();
        $updateRecords->update2nd($studentID, $engl, $fili, $math, $soc, $tle, $pe);
    
    $message = "Grades Updated.";
        echo "<script type='text/javascript'>alert('$message');</script>";
        //echo "<script type='text/javascript'>alert('$update');</script>";
		echo "<script type='text/javascript'>window.location.href ='../UserManagement/index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
}

function thirdGrading(){
	$engl = ($_POST['english']);
	$fili = ($_POST['filipino']);
	$math = $_POST['math'];
    $soc = $_POST['social'];
    $tle = $_POST['tle'];
    $pe = $_POST['pe'];
    $studentID = $_POST['id'];
    
    $updateRecords = new Grades();
        $updateRecords->update3rd($studentID, $engl, $fili, $math, $soc, $tle, $pe);
    
    $message = "Grades Updated.";
        echo "<script type='text/javascript'>alert('$message');</script>";
        //echo "<script type='text/javascript'>alert('$update');</script>";
		echo "<script type='text/javascript'>window.location.href ='../UserManagement/index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
}

function fourthGrading(){
	$engl = ($_POST['english']);
	$fili = ($_POST['filipino']);
	$math = $_POST['math'];
    $soc = $_POST['social'];
    $tle = $_POST['tle'];
    $pe = $_POST['pe'];
    $studentID = $_POST['id'];
    
    $updateRecords = new Grades();
        $updateRecords->update4th($studentID, $engl, $fili, $math, $soc, $tle, $pe);
    
    $message = "Grades Updated.";
        echo "<script type='text/javascript'>alert('$message');</script>";
        //echo "<script type='text/javascript'>alert('$update');</script>";
		echo "<script type='text/javascript'>window.location.href ='../UserManagement/index.php?mod=userManagement&sub=viewStudents'; </script>";
		exit;
}



?>
