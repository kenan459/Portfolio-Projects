<?php
class Violations{
	public $db;

	public function __construct(){
		$this->db = new mysqli(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if(mysqli_connect_errno()){
			echo "Database connection error.";
			exit;
		}
	}
    
    public function new_student($fname,$lname,$contactN){
	$sql = "SELECT * FROM tbl_students WHERE stud_lname='$lname'";
	$check=$this->db->query($sql);
	$count_row=$check->num_rows;
		if($count_row== 0){
			$sql = "INSERT INTO tbl_students(stud_fname,stud_lname,stud_contactN,stud_date_added,stud_time_added) 
			VALUES('$fname','$lname','$contactN',NOW(),NOW())";
			
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
			return $result;
		}
		else{
		
		return false;
		}

	}
    
    public function new_violation($studentID,$cName,$cDescrip,$cRemarks){
        $sql = "INSERT INTO tbl_violations(stud_id,case_name,case_description,case_remarks,case_date_added,case_time_added) 
			VALUES('$studentID','$cName','$cDescrip','$cRemarks',NOW(),NOW())";
			
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
			return $result;
		}
		

	
	
    
    public function loadViolations(){
	$sql="SELECT * FROM tbl_violations";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}
    
    public function loadViolationss($id){
	$sql="SELECT * FROM tbl_violations WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}

	public function getStatus($id){
		$sql="SELECT user_status FROM tbl_users WHERE user_id = 'id'";

		$restult=mysqli_query($this->db,$sql);
		$row=mysqli_fetch_assoc($result);
		$users_status = $row ['user_status'];
		return $user_status;
	}


}
?>
