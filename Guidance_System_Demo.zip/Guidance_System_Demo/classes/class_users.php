<?php
class Users{
	public $db;

	public function __construct(){
		$this->db = new mysqli(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if(mysqli_connect_errno()){
			echo "Database connection error.";
			exit;
		}
	}

	public function get_session(){
		if(isset($_SESSION['login']) && $_SESSION['login'] == true){
			return true;
		}
		else{
			return false;
		}
	}


	public function check_login($email,$password){
		$sql = "SELECT user_fname, user_lname, user_access FROM tbl_users WHERE 
		user_email = '$email' AND user_password = '$password'";
		$result=mysqli_query($this->db,$sql);
		$userdata=mysqli_fetch_array($result);
		$count = $result->num_rows;
		if($count == 1){
			$_SESSION['login']=true;
			$_SESSION['access'] = $userdata[user_access];
			$_SESSION['userdata']= ' '.$userdata[user_lname].', '.$userdata[user_fname];
			//$_SESSION['registerdate'] = $userdata['usr_date_added'];
			return true;
		}
		else{
			return false;
		}
	}

    public function api_new_user($fname){
	$sql = "SELECT * FROM tbl_users WHERE user_email='$fname'";
	$check=$this->db->query($sql);
	$count_row=$check->num_rows;
		if($count_row== 0){
			
			//$newpassword = $password;
			$sql = "INSERT INTO tbl_users(user_fname,user_date_added,user_time_added) 
			VALUES('$fname',NOW(),NOW())";
			
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
			return $result;
		}
		else{
		
		return false;
		}
    }
    
	public function new_user($fname,$lname,$contactN,$email,$password,$cpassword,$access){
	$sql = "SELECT * FROM tbl_users WHERE user_email='$email'";
	$check=$this->db->query($sql);
	$count_row=$check->num_rows;
		if($count_row== 0){
			$newpassword = md5($password);
			//$newpassword = $password;
			$sql = "INSERT INTO tbl_users(user_fname,user_lname,user_contactN,user_email,user_password,user_access,user_date_added,user_time_added) 
			VALUES('$fname','$lname','$contactN','$email','$newpassword','$access',NOW(),NOW())";
			
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
			return $result;
		}
		else{
		
		return false;
		}

	}

		//Update 
	public function modify_users($id,$email,$fname,$lname,$access){
		$sql = "UPDATE tbl_users SET user_email='$email', user_fname = '$fname', user_lname = '$lname', user_access = '$access' WHERE user_id ='$id'
		";
		
		$result=mysqli_query($this->db,$sql) or
		die(mysqli_error(). " - Data cannot be inserted.");
		return $result;
	}

    public function getStudents(){
	$sql="SELECT * FROM tbl_students";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}
    
    
	// Delete
	/*public function delete_users($id){
		$sql = "DELETE FROM tbl_users WHERE user_id ='$id'";
		
		$result=mysqli_query($this->db,$sql) or
		die(mysqli_error(). " - Data cannot be inserted.");
		return $result;
	}*/

	public function delete_users($id){
		$sql = "UPDATE tbl_users SET user_status=1, 
							user_updated_date=NOW(),
		user_updated_time=NOW() WHERE user_id ='$id'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
			return $result;	

	}

		//Function that creates a list of all records
	public function getUsers(){
	$sql="SELECT * FROM tbl_users";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}
    
    public function getUser($id){
	$sql="SELECT * FROM tbl_users WHERE user_id = '$id'";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}

	public function get_Email($id){
	$sql="SELECT user_email FROM tbl_users WHERE user_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$email = $row ['user_email'];
	return $email;
	}
	
	public function getFirst($id){
	$sql="SELECT user_fname FROM tbl_users WHERE user_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['user_fname'];
	return $title;
	}
	
	public function getLast($id){
	$sql="SELECT user_lname FROM tbl_users WHERE user_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$year = $row ['user_lname'];
	return $year;
	}

	public function getAccess($id){
	$sql="SELECT user_access FROM tbl_users WHERE user_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$acessories = $row ['user_access'];
	return $acessories;
	
	}

	public function getStatus($id){
		$sql="SELECT user_status FROM tbl_users WHERE user_id = 'id'";

		$restult=mysqli_query($this->db,$sql);
		$row=mysqli_fetch_assoc($result);
		$users_status = $row ['user_status'];
		return $user_status;
	}


}
?>
