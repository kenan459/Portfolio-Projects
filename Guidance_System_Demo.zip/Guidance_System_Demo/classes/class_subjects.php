<?php
class Subjects{
	public $db;

	public function __construct(){
		$this->db = new mysqli(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if(mysqli_connect_errno()){
			echo "Database connection error.";
			exit;
		}
	}
    
    

	
    
    public function new_student($studentID,$cTitle,$cDescrip,$cTime,$cDate){
        $sql = "INSERT INTO tbl_counseling(stud_id,counsel_title,counsel_description,counsel_time,counsel_date,counsel_date_added,counsel_time_added) 
			VALUES('$studentID','$cTitle','$cDescrip','$cTime', '$cDate' ,NOW(),NOW())";
			
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
			return $result;
		}
		

	
	
    
    public function loadSubjects(){
	$sql="SELECT * FROM tbl_subjects";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}
    
    public function loadStudentGrades($id){
	$sql="SELECT * FROM tbl_grades WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}

	public function getStatus($id){
		$sql="SELECT user_status FROM tbl_users WHERE user_id = 'id'";

		$restult=mysqli_query($this->db,$sql);
		$row=mysqli_fetch_assoc($result);
		$users_status = $row ['user_status'];
		return $user_status;
	}


}
?>
