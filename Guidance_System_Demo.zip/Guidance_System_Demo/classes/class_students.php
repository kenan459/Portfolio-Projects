<?php
class Students{
	public $db;

	public function __construct(){
		$this->db = new mysqli(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if(mysqli_connect_errno()){
			echo "Database connection error.";
			exit;
		}
	}

	
    public function getStudents(){
	$sql="SELECT * FROM tbl_students";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}
    
    public function new_student($fname,$lname,$contactN, $gContactN, $address){
	$sql = "SELECT * FROM tbl_students WHERE stud_lname='$lname'";
	$check=$this->db->query($sql);
	$count_row=$check->num_rows;
		if($count_row== 0){
			$sql = "INSERT INTO tbl_students(stud_fname,stud_lname,stud_contactN,stud_guardian_contactN,stud_address,stud_date_added,stud_time_added) 
			VALUES('$fname','$lname','$contactN','$gContactN','$address',NOW(),NOW())";
			
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
			return $result;
		}
		else{
		
		return false;
		}

	}
    
//    public function countStudents(){
//	$sql="SELECT * FROM tbl_students";
//	$check=$this->db->query($sql);
//	$count_row=$check->num_rows;
//		if($count_row== 0){
//			number = $row ['stud_contactN'];
//	       return $title;
//		}
//		else{
//		
//		return false;
//		}
//
//	}
    
    public function initialize_student($studentID){
			$sql = "UPDATE tbl_students SET stud_hasGrades = '1' WHERE stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
			return $result;	

	}
    
	// Delete
	/*public function delete_users($id){
		$sql = "DELETE FROM tbl_users WHERE user_id ='$id'";
		
		$result=mysqli_query($this->db,$sql) or
		die(mysqli_error(). " - Data cannot be inserted.");
		return $result;
	}*/

	public function delete_student($id){
		$sql = "UPDATE tbl_students SET stud_status=1, 
							stud_updated_date=NOW(),
		stud_updated_time=NOW() WHERE stud_id ='$id'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
			return $result;	
	}
    
    public function updateViolations($update,$studentID){
		$sql = "UPDATE tbl_students SET stud_violations = '$update' WHERE stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
			return $result;	
	}
    
    public function updateCounselRecords($update,$studentID){
		$sql = "UPDATE tbl_students SET stud_counselRecords = '$update' WHERE stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
			return $result;	
	}

    public function getUser($id){
	$sql="SELECT * FROM tbl_users WHERE user_id = '$id'";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}

	
	
	public function getFirst($id){
	$sql="SELECT stud_fname FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_fname'];
	return $title;
	}
	
	public function getLast($id){
	$sql="SELECT stud_lname FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_lname'];
	return $title;
	}
    
   public function getContact($id){
	$sql="SELECT stud_contactN FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_contactN'];
	return $title;
	}
    
    public function getGcontact($id){
	$sql="SELECT stud_guardian_contactN FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_guardian_contactN'];
	return $title;
	}
    
    public function getAddress($id){
	$sql="SELECT stud_address FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_address'];
	return $title;
	}
    
    public function getnumViolations($id){
	$sql="SELECT stud_Violations FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_Violations'];
	return $title;
	}
    
    public function getcounselRecords($id){
	$sql="SELECT stud_counselRecords FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_counselRecords'];
	return $title;
	}
    
    public function hasBeenGraded($id){
	$sql="SELECT stud_hasGrades FROM tbl_students WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql);
	$row=mysqli_fetch_assoc($result);
	$title = $row ['stud_hasGrades'];
	return $title;
	}

	public function getStatus($id){
		$sql="SELECT user_status FROM tbl_users WHERE user_id = 'id'";
        
		$restult=mysqli_query($this->db,$sql);
		$row=mysqli_fetch_assoc($result);
		$users_status = $row ['user_status'];
		return $user_status;
	}


}
?>
