<?php
class Grades{
	public $db;

	public function __construct(){
		$this->db = new mysqli(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
		if(mysqli_connect_errno()){
			echo "Database connection error.";
			exit;
		}
	}
		
    public function update1st($studentID, $engl, $fili, $math, $soc, $tle, $pe){
		$sql = "UPDATE tbl_grades SET grades_1st = '$engl' WHERE subject_name = 'English' AND stud_id ='$studentID'";
        $result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_1st = '$fili' WHERE subject_name = 'Filipino' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_1st = '$math' WHERE subject_name = 'Math' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_1st = '$soc' WHERE subject_name = 'Social Studies' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_1st = '$tle' WHERE subject_name = 'TLE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_1st = '$pe' WHERE subject_name = 'PE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        
			return $result;	
	}
    
    public function update2nd($studentID, $engl, $fili, $math, $soc, $tle, $pe){
		$sql = "UPDATE tbl_grades SET grades_2nd = '$engl' WHERE subject_name = 'English' AND stud_id ='$studentID'";
        $result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_2nd = '$fili' WHERE subject_name = 'Filipino' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_2nd = '$math' WHERE subject_name = 'Math' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_2nd = '$soc' WHERE subject_name = 'Social Studies' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_2nd = '$tle' WHERE subject_name = 'TLE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_2nd = '$pe' WHERE subject_name = 'PE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        
			return $result;	
	}
    
    public function update3rd($studentID, $engl, $fili, $math, $soc, $tle, $pe){
		$sql = "UPDATE tbl_grades SET grades_3rd = '$engl' WHERE subject_name = 'English' AND stud_id ='$studentID'";
        $result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_3rd = '$fili' WHERE subject_name = 'Filipino' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_3rd = '$math' WHERE subject_name = 'Math' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_3rd = '$soc' WHERE subject_name = 'Social Studies' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_3rd = '$tle' WHERE subject_name = 'TLE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_3rd = '$pe' WHERE subject_name = 'PE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        
			return $result;	
	}
    
    public function update4th($studentID, $engl, $fili, $math, $soc, $tle, $pe){
		$sql = "UPDATE tbl_grades SET grades_4th = '$engl' WHERE subject_name = 'English' AND stud_id ='$studentID'";
        $result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_4th = '$fili' WHERE subject_name = 'Filipino' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_4th = '$math' WHERE subject_name = 'Math' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_4th = '$soc' WHERE subject_name = 'Social Studies' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_4th = '$tle' WHERE subject_name = 'TLE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        $sql = "UPDATE tbl_grades SET grades_4th = '$pe' WHERE subject_name = 'PE' AND stud_id ='$studentID'";
		$result=mysqli_query ($this->db,$sql) or
			die (mysqli_error() . " - Data cannot be inserted.");
        
        
			return $result;	
	}
    
    public function initialize_Grades($id){
		$sql = "INSERT INTO tbl_grades(stud_id,subject_name) 
                                        VALUES('$id','English')";
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
        
        $sql = "INSERT INTO tbl_grades(stud_id,subject_name) 
                                        VALUES('$id','Filipino')";
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
        
        $sql = "INSERT INTO tbl_grades(stud_id,subject_name) 
                                        VALUES('$id','Math')";
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
        
        $sql = "INSERT INTO tbl_grades(stud_id,subject_name) 
                                        VALUES('$id','Social Studies')";
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
        
        $sql = "INSERT INTO tbl_grades(stud_id,subject_name) 
                                        VALUES('$id','TLE')";
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
        
        $sql = "INSERT INTO tbl_grades(stud_id,subject_name) 
                                        VALUES('$id','PE')";
			$result = mysqli_query($this->db,$sql) or die(mysqli_error() . "Cannot Insert Data");
        
        
        
        
			return $result;	
	}
    
    
    
    public function loadStudentGrades($id){
	$sql="SELECT * FROM tbl_grades WHERE stud_id = '$id'";
	$result=mysqli_query($this->db,$sql); 
	while($row=mysqli_fetch_assoc($result)){
		$list[] = $row;
	}
	return $list;
	}

	public function getStatus($id){
		$sql="SELECT user_status FROM tbl_users WHERE user_id = 'id'";

		$restult=mysqli_query($this->db,$sql);
		$row=mysqli_fetch_assoc($result);
		$users_status = $row ['user_status'];
		return $user_status;
	}


}
?>
